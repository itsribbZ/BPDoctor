BP DOCTOR — RELEASE PACKAGE
===========================

Animation Blueprint & Blueprint diagnostic tool for Unreal Engine 5.7.

PACKAGE CONTENTS
----------------

01_TUTORIAL/           Complete user guide. Open BP_Doctor_User_Guide.html
                       in any web browser. Covers all 26 checks, auto-fix
                       behavior, settings, custom rules, and the commandlet.

02_PLUGIN/             The UE5 Editor Plugin. Drop BPDoctor/ into
                       YourProject/Plugins/ and recompile. 26 checks,
                       6 auto-fixes. Compiles clean on UE 5.7.

QUICK START
-----------

1. Open 01_TUTORIAL/BP_Doctor_User_Guide.html in a web browser.
2. Copy 02_PLUGIN/BPDoctor/ into YourUEProject/Plugins/ (create Plugins
   folder if it doesn't exist).
3. Open your .uproject, confirm "Compile?" when prompted.
4. Inside the editor: Window -> BP Doctor (or Tools -> BP Doctor).
5. Click "Scan Project" and you're off.

BUILD INFO
----------

Plugin version : 1.0
Target engine  : UE 5.7
Check count    : 26
Auto-fix count : 6

