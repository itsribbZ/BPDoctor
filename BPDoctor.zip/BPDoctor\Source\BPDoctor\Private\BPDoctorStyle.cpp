// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#include "BPDoctorStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Interfaces/IPluginManager.h"

#define RootToContentDir Style->RootToContentDir

TSharedPtr<FSlateStyleSet> FBPDoctorStyle::StyleInstance = nullptr;

void FBPDoctorStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FBPDoctorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FBPDoctorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("BPDoctorStyle"));
	return StyleSetName;
}

void FBPDoctorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FBPDoctorStyle::Get()
{
	return *StyleInstance;
}

TSharedRef<FSlateStyleSet> FBPDoctorStyle::Create()
{
	TSharedRef<FSlateStyleSet> Style = MakeShareable(new FSlateStyleSet("BPDoctorStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("BPDoctor")->GetBaseDir() / TEXT("Resources"));

	Style->Set("BPDoctor.OpenBPDoctor", new FSlateImageBrush(
		RootToContentDir(TEXT("Icon128"), TEXT(".png")), FVector2D(40.0f, 40.0f)));

	Style->Set("BPDoctor.TabIcon", new FSlateImageBrush(
		RootToContentDir(TEXT("Icon128"), TEXT(".png")), FVector2D(16.0f, 16.0f)));

	return Style;
}

#undef RootToContentDir
