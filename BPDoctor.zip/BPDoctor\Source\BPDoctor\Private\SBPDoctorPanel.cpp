// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#include "SBPDoctorPanel.h"
#include "BPDoctorChecks.h"
#include "BPDoctorFixes.h"

#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/SHeaderRow.h"
#include "Widgets/SBoxPanel.h"

#include "Styling/AppStyle.h"
#include "Styling/CoreStyle.h"
#include "Misc/FileHelper.h"
#include "DesktopPlatformModule.h"
#include "Framework/Application/SlateApplication.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Engine/Blueprint.h"
#include "Editor.h"
#include "ScopedTransaction.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/STextComboBox.h"
#include "Editor/TransBuffer.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "UObject/LinkerLoad.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/Paths.h"

#define LOCTEXT_NAMESPACE "BPDoctor"

void SBPDoctorPanel::Construct(const FArguments& InArgs)
{
	Scanner = MakeShareable(new FBPDoctorScanner());
	Scanner->OnComplete.BindSP(this, &SBPDoctorPanel::OnScanComplete);

	ExperienceModeOptions.Add(MakeShareable(new FString(TEXT("Beginner"))));
	ExperienceModeOptions.Add(MakeShareable(new FString(TEXT("Intermediate"))));
	ExperienceModeOptions.Add(MakeShareable(new FString(TEXT("Expert"))));

	LoadSettings();

	ChildSlot
	[
		SNew(SVerticalBox)

		// ── Title Bar ──
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(8)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Title", "BP Doctor"))
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 18))
				.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(12, 6, 0, 0)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Version", "v1.0 — Blueprint Diagnostics & Auto-Fix"))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
				.ColorAndOpacity(FLinearColor(0.533f, 0.533f, 0.667f))
			]
		]

		// ── Toolbar ──
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(8, 0, 8, 4)
		[
			SNew(SHorizontalBox)

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("ScanProject", "Scan Project"))
				.ToolTipText(LOCTEXT("ScanTip", "Scan all Blueprints in /Game for issues"))
				.OnClicked(this, &SBPDoctorPanel::OnScanProject)
				.IsEnabled_Lambda([this]() { return !bScanRunning; })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("FixAll", "Fix All"))
				.ToolTipText(LOCTEXT("FixAllTip", "Auto-fix all fixable issues"))
				.OnClicked(this, &SBPDoctorPanel::OnFixAll)
				.IsEnabled_Lambda([this]() { return TotalAutoFixable > 0; })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("UndoFix", "Undo Fix"))
				.ToolTipText_Lambda([this]() -> FText {
					for (int32 i = FixHistory.Num() - 1; i >= 0; --i)
					{
						if (!FixHistory[i].bReverted)
						{
							return FText::FromString(FString::Printf(
								TEXT("Undo: %s in %s"), *FixHistory[i].CheckCode, *FixHistory[i].AssetName));
						}
					}
					return LOCTEXT("NoUndo", "No fixes to undo");
				})
				.OnClicked(this, &SBPDoctorPanel::OnUndoLastFix)
				.IsEnabled_Lambda([this]() {
					for (int32 i = FixHistory.Num() - 1; i >= 0; --i)
					{
						if (!FixHistory[i].bReverted) return true;
					}
					return false;
				})
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("Export", "Export Report"))
				.ToolTipText(LOCTEXT("ExportTip", "Export scan results to a text file"))
				.OnClicked(this, &SBPDoctorPanel::OnExportReport)
				.IsEnabled_Lambda([this]() { return FilteredIssues.Num() > 0; })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("ExportHTML", "HTML"))
				.ToolTipText(LOCTEXT("ExportHTMLTip", "Export styled HTML report"))
				.OnClicked(this, &SBPDoctorPanel::OnExportHTMLReport)
				.IsEnabled_Lambda([this]() { return FilteredIssues.Num() > 0; })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("Checks", "Checks"))
				.ToolTipText(LOCTEXT("ChecksTip", "View all 26 checks — enable/disable individual checks"))
				.OnClicked_Lambda([this]() { ShowChecksDialog(); return FReply::Handled(); })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(0, 0, 4, 0)
			[
				SNew(SButton)
				.Text(LOCTEXT("Settings", "Settings"))
				.ToolTipText(LOCTEXT("SettingsTip", "Configure BP Doctor preferences"))
				.OnClicked_Lambda([this]() { ShowSettingsDialog(); return FReply::Handled(); })
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.Text(LOCTEXT("Clear", "Clear"))
				.OnClicked(this, &SBPDoctorPanel::OnClear)
			]

			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			[
				SNew(SSpacer)
			]

			// Search filter
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(4, 0)
			[
				SNew(SBox)
				.WidthOverride(180)
				[
					SNew(SEditableTextBox)
					.HintText(LOCTEXT("SearchHint", "Filter checks/assets..."))
					.OnTextChanged_Lambda([this](const FText& NewText)
					{
						SearchFilter = NewText.ToString();
						RefreshFilteredList();
					})
				]
			]

			// Experience mode
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(4, 0)
			[
				SNew(SBox)
				.WidthOverride(130)
				[
					SNew(STextComboBox)
					.OptionsSource(&ExperienceModeOptions)
					.InitiallySelectedItem(ExperienceModeOptions[1])
					.OnSelectionChanged_Lambda([this](TSharedPtr<FString> NewValue, ESelectInfo::Type)
					{
						if (NewValue.IsValid())
						{
							if (*NewValue == TEXT("Beginner")) ExperienceMode = EBPDoctorExperienceMode::Beginner;
							else if (*NewValue == TEXT("Expert")) ExperienceMode = EBPDoctorExperienceMode::Expert;
							else ExperienceMode = EBPDoctorExperienceMode::Intermediate;
							SaveSettings();
							if (SelectedIssue.IsValid())
								OnSelectionChanged(SelectedIssue, ESelectInfo::Direct);
						}
					})
				]
			]

			// Severity filters
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(4, 0)
			[
				SNew(SCheckBox)
				.IsChecked_Lambda([this]() { return bShowErrors ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
				.OnCheckStateChanged_Lambda([this](ECheckBoxState State)
				{
					bShowErrors = (State == ECheckBoxState::Checked);
					RefreshFilteredList();
				})
				[
					SNew(STextBlock)
					.Text(LOCTEXT("Errors", "Errors"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
					.ColorAndOpacity(FLinearColor(1.0f, 0.09f, 0.27f))
				]
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(4, 0)
			[
				SNew(SCheckBox)
				.IsChecked_Lambda([this]() { return bShowWarnings ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
				.OnCheckStateChanged_Lambda([this](ECheckBoxState State)
				{
					bShowWarnings = (State == ECheckBoxState::Checked);
					RefreshFilteredList();
				})
				[
					SNew(STextBlock)
					.Text(LOCTEXT("Warnings", "Warnings"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
					.ColorAndOpacity(FLinearColor(1.0f, 0.843f, 0.251f))
				]
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(4, 0)
			[
				SNew(SCheckBox)
				.IsChecked_Lambda([this]() { return bShowInfo ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
				.OnCheckStateChanged_Lambda([this](ECheckBoxState State)
				{
					bShowInfo = (State == ECheckBoxState::Checked);
					RefreshFilteredList();
				})
				[
					SNew(STextBlock)
					.Text(LOCTEXT("Info", "Info"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(8, 0, 0, 0)
			[
				SNew(SCheckBox)
				.IsChecked_Lambda([this]() { return bShowSuppressed ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
				.OnCheckStateChanged_Lambda([this](ECheckBoxState State)
				{
					bShowSuppressed = (State == ECheckBoxState::Checked);
					RefreshFilteredList();
				})
				[
					SNew(STextBlock)
					.Text_Lambda([this]() -> FText {
						if (SuppressedIssueKeys.Num() > 0)
							return FText::FromString(FString::Printf(TEXT("Suppressed (%d)"), SuppressedIssueKeys.Num()));
						return LOCTEXT("Suppressed", "Suppressed");
					})
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.ColorAndOpacity(FLinearColor(0.533f, 0.533f, 0.667f))
				]
			]
		]

		// ── Stats Bar ──
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(8, 4)
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
			.Padding(8)
			[
				SNew(SHorizontalBox)

				// Health Grade
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(0, 0, 20, 0)
				[
					SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight()
					[
						SNew(STextBlock)
						.Text(LOCTEXT("GradeLabel", "HEALTH"))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
						.ColorAndOpacity(FLinearColor(0.533f, 0.533f, 0.667f))
					]
					+ SVerticalBox::Slot().AutoHeight()
					[
						SNew(STextBlock)
						.Text(this, &SBPDoctorPanel::GetHealthGradeText)
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 28))
						.ColorAndOpacity(this, &SBPDoctorPanel::GetHealthGradeColor)
					]
				]

				// Stats text
				+ SHorizontalBox::Slot()
				.FillWidth(1.f)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(this, &SBPDoctorPanel::GetStatsText)
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 11))
				]
			]
		]

		// ── Progress Bar ──
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(8, 0, 8, 4)
		[
			SNew(SProgressBar)
			.Percent(this, &SBPDoctorPanel::GetProgressPercent)
			.FillColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
		]

		// ── Main Content: Results List + Detail Panel ──
		+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		.Padding(8)
		[
			SNew(SSplitter)
			.Orientation(Orient_Horizontal)

			// Left: Results list with column headers
			+ SSplitter::Slot()
			.Value(0.6f)
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
				[
					SAssignNew(IssueListView, SListView<TSharedPtr<FBPDoctorResult>>)
					.ListItemsSource(&FilteredIssues)
					.OnGenerateRow(this, &SBPDoctorPanel::OnGenerateRow)
					.OnSelectionChanged(this, &SBPDoctorPanel::OnSelectionChanged)
					.SelectionMode(ESelectionMode::Single)
					.HeaderRow(
						SNew(SHeaderRow)
						+ SHeaderRow::Column("Severity")
							.DefaultLabel(LOCTEXT("ColSev", "Sev"))
							.FixedWidth(50)
						+ SHeaderRow::Column("Confidence")
							.DefaultLabel(LOCTEXT("ColConf", "Conf"))
							.FixedWidth(45)
						+ SHeaderRow::Column("Code")
							.DefaultLabel(LOCTEXT("ColCode", "Check"))
							.FixedWidth(120)
						+ SHeaderRow::Column("Type")
							.DefaultLabel(LOCTEXT("ColType", "Type"))
							.FixedWidth(45)
						+ SHeaderRow::Column("Asset")
							.DefaultLabel(LOCTEXT("ColAsset", "Asset"))
							.FillWidth(0.3f)
						+ SHeaderRow::Column("Description")
							.DefaultLabel(LOCTEXT("ColDesc", "Description"))
							.FillWidth(0.5f)
						+ SHeaderRow::Column("AutoFix")
							.DefaultLabel(LOCTEXT("ColFix", "Fix"))
							.FixedWidth(50)
					)
				]
			]

			// Right: Detail panel
			+ SSplitter::Slot()
			.Value(0.4f)
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
				.Padding(10.0f)
				[
					SNew(SScrollBox)
					+ SScrollBox::Slot()
					[
						SNew(SVerticalBox)

						+ SVerticalBox::Slot()
						.AutoHeight()
						[
							SAssignNew(DetailText, STextBlock)
							.AutoWrapText(true)
							.Font(FCoreStyle::GetDefaultFontStyle("Regular", 11))
							.Text(LOCTEXT("SelectIssue", "Welcome to BP Doctor\n\nClick 'Scan Project' to analyze all Blueprints in your project.\n\n26 BUILT-IN CHECKS:\n  Errors    — T-pose fallbacks, broken refs, skeleton mismatches\n  Warnings  — Missing slots, debug nodes, tick performance, circular deps\n  Info      — Unused variables, orphaned nodes, complexity\n\nFEATURES:\n  Navigate  — Click any issue to jump to the exact node in the editor\n  Fix       — Auto-fix supported issues with preview + revert\n  Suppress  — Hide known issues you want to ignore\n  Export    — Text and HTML reports for your team\n  Custom    — Add your own rules via Saved/BPDoctor/CustomRules.json\n  CI/CD     — Run headless: UnrealEditor-Cmd -run=BPDoctor -output=report.json\n\nTIP: Use the Experience Mode dropdown to control detail level.\n  Beginner = full guidance  |  Expert = compact one-liners"))
						]

						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 16, 0, 0)
						[
							SAssignNew(FixButtonsRow, SHorizontalBox)
							.Visibility(EVisibility::Collapsed)
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.Padding(0, 0, 4, 0)
							[
								SAssignNew(FixButton, SButton)
								.Text(LOCTEXT("FixThis", "Fix This Issue"))
								.ToolTipText(LOCTEXT("FixThisTip", "Preview and apply fix — shows what will change before applying"))
								.IsEnabled(false)
								.OnClicked(this, &SBPDoctorPanel::OnFixSelected)
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.Padding(0, 0, 8, 0)
							[
								SAssignNew(RevertButton, SButton)
								.Text(LOCTEXT("Revert", "Revert"))
								.ToolTipText(LOCTEXT("RevertTip", "Revert this fix — reload Blueprint from disk"))
								.IsEnabled(false)
								.OnClicked(this, &SBPDoctorPanel::OnRevertSelected)
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							[
								SAssignNew(OpenEditorButton, SButton)
								.Text(LOCTEXT("Navigate", "Navigate"))
								.ToolTipText(LOCTEXT("NavigateTip", "Open Blueprint editor and zoom to the problematic node"))
								.IsEnabled(false)
								.OnClicked_Lambda([this]() {
									if (SelectedIssue.IsValid())
										NavigateToIssue(*SelectedIssue);
									return FReply::Handled();
								})
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.Padding(8, 0, 4, 0)
							[
								SAssignNew(CopyButton, SButton)
								.Text(LOCTEXT("Copy", "Copy"))
								.ToolTipText(LOCTEXT("CopyTip", "Copy issue details to clipboard"))
								.IsEnabled(false)
								.OnClicked(this, &SBPDoctorPanel::OnCopyDetails)
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							[
								SAssignNew(SuppressButton, SButton)
								.Text_Lambda([this]() -> FText {
									if (SelectedIssue.IsValid() && SuppressedIssueKeys.Contains(
										SelectedIssue->CheckCode + TEXT("|") + SelectedIssue->AssetPath))
										return LOCTEXT("Unsuppress", "Unsuppress");
									return LOCTEXT("Suppress", "Suppress");
								})
								.ToolTipText_Lambda([this]() -> FText {
									if (SelectedIssue.IsValid() && SuppressedIssueKeys.Contains(
										SelectedIssue->CheckCode + TEXT("|") + SelectedIssue->AssetPath))
										return LOCTEXT("UnsuppressTip", "Restore this issue to normal results");
									return LOCTEXT("SuppressTip2", "Hide this issue — use Suppressed filter to view later");
								})
								.IsEnabled(false)
								.OnClicked(this, &SBPDoctorPanel::OnSuppressSelected)
							]
						]
					]
				]
			]
		]
	];
}

// ─────────────────────────────────────────────────────────────────
//  ACTIONS
// ─────────────────────────────────────────────────────────────────

FReply SBPDoctorPanel::OnScanProject()
{
	bScanRunning = true;
	CurrentProgress = 0.f;
	AllResults.Empty();
	FilteredIssues.Empty();
	SelectedIssue.Reset();

	Scanner->OnProgress.BindLambda([Weak = TWeakPtr<SBPDoctorPanel>(SharedThis(this))](int32 Current, int32 Total)
	{
		if (TSharedPtr<SBPDoctorPanel> Pin = Weak.Pin())
		{
			Pin->CurrentProgress = (Total > 0) ? static_cast<float>(Current) / static_cast<float>(Total) : 0.f;
		}
	});

	FBPDoctorChecks::SetDisabledChecks(DisabledChecks);
	Scanner->ScanProject();

	return FReply::Handled();
}

FReply SBPDoctorPanel::OnClear()
{
	AllResults.Empty();
	FilteredIssues.Empty();
	SelectedIssue.Reset();
	if (FixButton.IsValid()) FixButton->SetEnabled(false);
	if (RevertButton.IsValid()) RevertButton->SetEnabled(false);
	if (OpenEditorButton.IsValid()) OpenEditorButton->SetEnabled(false);
	if (CopyButton.IsValid()) CopyButton->SetEnabled(false);
	if (SuppressButton.IsValid()) SuppressButton->SetEnabled(false);
	if (FixButtonsRow.IsValid()) FixButtonsRow->SetVisibility(EVisibility::Collapsed);
	SuppressedIssueKeys.Empty();
	TotalScanned = 0;
	TotalErrors = 0;
	TotalWarnings = 0;
	TotalInfos = 0;
	TotalAutoFixable = 0;
	HealthGrade = TEXT("-");
	CurrentProgress = 0.f;
	if (IssueListView.IsValid()) IssueListView->RequestListRefresh();
	DetailText->SetText(LOCTEXT("Cleared", "Results cleared. Click Scan Project to begin."));
	return FReply::Handled();
}

FReply SBPDoctorPanel::OnFixSelected()
{
	if (!SelectedIssue.IsValid() || SelectedIssue->bFixed)
		return FReply::Handled();

	ShowFixConfirmDialog(SelectedIssue);
	return FReply::Handled();
}

FReply SBPDoctorPanel::OnFixAll()
{
	ShowFixAllDialog();
	return FReply::Handled();
}

FReply SBPDoctorPanel::OnExportReport()
{
	FString Report;
	Report += TEXT("BP Doctor Scan Report\n");
	Report += FString::Printf(TEXT("Generated: %s\n"), *FDateTime::Now().ToString());
	Report += TEXT("=============================================\n\n");

	Report += FString::Printf(TEXT("Scanned: %d assets | Health: %s\n"),
		TotalScanned, *HealthGrade);
	Report += FString::Printf(TEXT("Errors: %d | Warnings: %d | Info: %d\n\n"),
		TotalErrors, TotalWarnings, TotalInfos);

	for (const FBPDoctorAssetInfo& Info : AllResults)
	{
		if (Info.Issues.Num() == 0) continue;

		Report += FString::Printf(TEXT("--- %s [%s] ---\n"), *Info.Name, *Info.Grade);
		for (const FBPDoctorResult& Issue : Info.Issues)
		{
			FString SevStr = (Issue.Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
				(Issue.Severity == EBPDoctorSeverity::Warning) ? TEXT("WARN") : TEXT("INFO");
			FString FixStr = Issue.bFixed ? TEXT(" [FIXED]") : (Issue.bAutoFixable ? TEXT(" [fixable]") : TEXT(""));
			Report += FString::Printf(TEXT("  [%s] %s: %s%s\n"),
				*SevStr, *Issue.CheckCode, *Issue.Description, *FixStr);
			if (!Issue.NodeHint.IsEmpty())
			{
				Report += FString::Printf(TEXT("         > %s\n"), *Issue.NodeHint);
			}
		}
		Report += TEXT("\n");
	}

	TArray<FString> OutFiles;
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (DesktopPlatform)
	{
		DesktopPlatform->SaveFileDialog(
			FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
			TEXT("Export BP Doctor Report"),
			FPaths::ProjectDir(),
			TEXT("BPDoctor_Report.txt"),
			TEXT("Text Files (*.txt)|*.txt"),
			0, OutFiles);

		if (OutFiles.Num() > 0)
		{
			FFileHelper::SaveStringToFile(Report, *OutFiles[0]);
		}
	}

	return FReply::Handled();
}

// ─────────────────────────────────────────────────────────────────
//  SCANNER CALLBACK
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::OnScanComplete(const TArray<FBPDoctorAssetInfo>& Results)
{
	AllResults = Results;
	bScanRunning = false;
	CurrentProgress = 1.f;
	UpdateStats();
	RefreshFilteredList();
	// Only show fix buttons if there are actual issues
	if (FixButtonsRow.IsValid())
	{
		bool bHasIssues = FilteredIssues.Num() > 0;
		FixButtonsRow->SetVisibility(bHasIssues ? EVisibility::Visible : EVisibility::Collapsed);
	}
}

// ─────────────────────────────────────────────────────────────────
//  LIST VIEW
// ─────────────────────────────────────────────────────────────────

TSharedRef<ITableRow> SBPDoctorPanel::OnGenerateRow(TSharedPtr<FBPDoctorResult> Item,
	const TSharedRef<STableViewBase>& OwnerTable)
{
	// Severity
	FLinearColor SevColor;
	FString SevText;
	switch (Item->Severity)
	{
		case EBPDoctorSeverity::Error:
			SevColor = FLinearColor(1.f, 0.09f, 0.27f);
			SevText = TEXT("ERR");
			break;
		case EBPDoctorSeverity::Warning:
			SevColor = FLinearColor(1.f, 0.843f, 0.251f);
			SevText = TEXT("WRN");
			break;
		default:
			SevColor = FLinearColor(0.f, 0.898f, 1.f);
			SevText = TEXT("INF");
			break;
	}

	// Confidence from check definition
	const FBPDoctorCheckDef* CheckDef = FBPDoctorChecks::FindCheck(Item->CheckCode);
	FString ConfText = TEXT("MED");
	FLinearColor ConfColor(1.f, 0.843f, 0.251f);
	if (CheckDef)
	{
		switch (CheckDef->Confidence)
		{
			case EBPDoctorConfidence::High:
				ConfText = TEXT("HI");
				ConfColor = FLinearColor(0.f, 0.902f, 0.463f);
				break;
			case EBPDoctorConfidence::Medium:
				ConfText = TEXT("MED");
				ConfColor = FLinearColor(1.f, 0.843f, 0.251f);
				break;
			case EBPDoctorConfidence::Low:
				ConfText = TEXT("LO");
				ConfColor = FLinearColor(1.f, 0.549f, 0.f);
				break;
		}
	}

	// Type badge
	FString TypeText = (Item->AssetType == EBPDoctorAssetType::AnimBP) ? TEXT("Anim") : TEXT("BP");
	FLinearColor TypeColor = (Item->AssetType == EBPDoctorAssetType::AnimBP)
		? FLinearColor(0.f, 0.898f, 1.f) : FLinearColor(0.533f, 0.745f, 0.533f);

	// Fix indicator
	FString FixText = Item->bFixed ? TEXT("DONE") : (Item->bAutoFixable ? TEXT("YES") : TEXT("-"));
	FLinearColor FixColor = Item->bFixed ? FLinearColor(0.f, 0.902f, 0.463f)
		: (Item->bAutoFixable ? FLinearColor(1.f, 0.843f, 0.251f)
		: FLinearColor(0.533f, 0.533f, 0.667f));

	// Severity-tinted row background
	FLinearColor RowBg;
	if (Item->bFixed)
	{
		RowBg = FLinearColor(0.02f, 0.07f, 0.03f, 1.f);
	}
	else
	{
		switch (Item->Severity)
		{
			case EBPDoctorSeverity::Error:   RowBg = FLinearColor(0.12f, 0.015f, 0.03f, 1.f); break;
			case EBPDoctorSeverity::Warning: RowBg = FLinearColor(0.09f, 0.07f, 0.01f, 1.f); break;
			default:                          RowBg = FLinearColor(0.02f, 0.04f, 0.07f, 1.f); break;
		}
	}

	return SNew(STableRow<TSharedPtr<FBPDoctorResult>>, OwnerTable)
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("NoBorder"))
			.BorderBackgroundColor(RowBg)
			.Padding(FMargin(0, 1))
			[
				SNew(SHorizontalBox)

			+ SHorizontalBox::Slot().AutoWidth().Padding(4, 2)
			[
				SNew(SBox).WidthOverride(50)
				[ SNew(STextBlock).Text(FText::FromString(SevText))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9)).ColorAndOpacity(SevColor) ]
			]

			+ SHorizontalBox::Slot().AutoWidth().Padding(2, 2)
			[
				SNew(SBox).WidthOverride(45)
				.ToolTipText(FText::FromString(CheckDef && !CheckDef->DetectionMethod.IsEmpty() ? CheckDef->DetectionMethod : TEXT("Hover for detection method")))
				[ SNew(STextBlock).Text(FText::FromString(ConfText))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 8)).ColorAndOpacity(ConfColor) ]
			]

			+ SHorizontalBox::Slot().AutoWidth().Padding(4, 2)
			[
				SNew(SBox).WidthOverride(120)
				[ SNew(STextBlock).Text(FText::FromString(Item->CheckCode))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)).ColorAndOpacity(SevColor) ]
			]

			+ SHorizontalBox::Slot().AutoWidth().Padding(2, 2)
			[
				SNew(SBox).WidthOverride(45)
				[ SNew(STextBlock).Text(FText::FromString(TypeText))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 8)).ColorAndOpacity(TypeColor) ]
			]

			+ SHorizontalBox::Slot().FillWidth(0.3f).Padding(4, 2)
			[ SNew(STextBlock).Text(FText::FromString(Item->AssetName))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)) ]

			+ SHorizontalBox::Slot().FillWidth(0.5f).Padding(4, 2)
			[ SNew(STextBlock).Text(FText::FromString(Item->Description))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)) ]

			+ SHorizontalBox::Slot().AutoWidth().Padding(2, 2)
			[
				SNew(SBox).WidthOverride(50).HAlign(HAlign_Center)
				[ SNew(STextBlock).Text(FText::FromString(FixText))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9)).ColorAndOpacity(FixColor) ]
			]
			] // close SBorder
		];
}

void SBPDoctorPanel::OnSelectionChanged(TSharedPtr<FBPDoctorResult> SelectedItem, ESelectInfo::Type SelectInfo)
{
	SelectedIssue = SelectedItem;

	// Explicitly update button states
	bool bHasSelection = SelectedItem.IsValid();
	bool bCanFix = bHasSelection && !SelectedItem->bFixed;
	bool bCanRevert = bHasSelection && SelectedItem->bFixed;
	if (FixButton.IsValid()) FixButton->SetEnabled(bCanFix);
	if (RevertButton.IsValid()) RevertButton->SetEnabled(bCanRevert);
	if (OpenEditorButton.IsValid()) OpenEditorButton->SetEnabled(bHasSelection);
	if (CopyButton.IsValid()) CopyButton->SetEnabled(bHasSelection);
	if (SuppressButton.IsValid()) SuppressButton->SetEnabled(bHasSelection);

	if (!bHasSelection)
	{
		DetailText->SetText(LOCTEXT("NoSelection", "Select an issue from the list to see details."));
		return;
	}

	const FBPDoctorCheckDef* Check = FBPDoctorChecks::FindCheck(SelectedItem->CheckCode);

	// ── Expert mode: compact one-liner ──
	if (ExperienceMode == EBPDoctorExperienceMode::Expert)
	{
		FString SevStr = (SelectedItem->Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
			(SelectedItem->Severity == EBPDoctorSeverity::Warning) ? TEXT("WARN") : TEXT("INFO");
		FString FixStr = SelectedItem->bFixed ? TEXT(" [FIXED]") :
			(SelectedItem->bAutoFixable ? TEXT(" [fixable]") : TEXT(""));

		FString Detail = FString::Printf(TEXT("%s [%s] — %s\n%s%s"),
			*SelectedItem->CheckCode, *SevStr, *SelectedItem->AssetName,
			*SelectedItem->Description, *FixStr);

		if (!SelectedItem->NodeHint.IsEmpty())
			Detail += FString::Printf(TEXT("\n> %s"), *SelectedItem->NodeHint);

		DetailText->SetText(FText::FromString(Detail));
		return;
	}

	if (!Check)
	{
		DetailText->SetText(FText::FromString(SelectedItem->Description));
		return;
	}

	// ── Intermediate + Beginner modes ──
	FString SevStr = (Check->Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
		(Check->Severity == EBPDoctorSeverity::Warning) ? TEXT("WARNING") : TEXT("INFO");
	FString ConfStr = (Check->Confidence == EBPDoctorConfidence::High) ? TEXT("HIGH") :
		(Check->Confidence == EBPDoctorConfidence::Medium) ? TEXT("MEDIUM") : TEXT("LOW");
	FString TypeStr = (SelectedItem->AssetType == EBPDoctorAssetType::AnimBP) ? TEXT("AnimBP") : TEXT("Blueprint");

	FString Detail;
	Detail += FString::Printf(TEXT("%s  [%s]\n"), *Check->Name, *SevStr);
	Detail += FString::Printf(TEXT("Code: %s  |  Type: %s  |  Confidence: %s\n"), *Check->Code, *TypeStr, *ConfStr);
	Detail += FString::Printf(TEXT("Asset: %s\n"), *SelectedItem->AssetName);

	// Show detection method in Intermediate + Beginner (transparency for the confidence metric)
	if (!Check->DetectionMethod.IsEmpty() && ExperienceMode != EBPDoctorExperienceMode::Expert)
	{
		Detail += FString::Printf(TEXT("Detection: %s\n"), *Check->DetectionMethod);
	}

	Detail += TEXT("\n----\n\n");
	Detail += FString::Printf(TEXT("%s\n"), *SelectedItem->Description);

	if (!SelectedItem->NodeHint.IsEmpty())
	{
		Detail += FString::Printf(TEXT("\n> %s\n"), *SelectedItem->NodeHint);
	}

	// HOW TO FIX — shown in both Intermediate and Beginner
	if (!Check->HowToFix.IsEmpty())
	{
		Detail += TEXT("\n----\n\n");
		Detail += FString::Printf(TEXT("HOW TO FIX:\n%s\n"), *Check->HowToFix);
	}

	// Beginner: also show WHY IT MATTERS + BEGINNER TIP + DETECTION METHOD
	if (ExperienceMode == EBPDoctorExperienceMode::Beginner)
	{
		if (!Check->WhyItMatters.IsEmpty())
		{
			Detail += TEXT("\n----\n\n");
			Detail += FString::Printf(TEXT("WHY IT MATTERS:\n%s\n"), *Check->WhyItMatters);
		}

		if (!Check->BeginnerTip.IsEmpty())
		{
			Detail += FString::Printf(TEXT("\nBEGINNER TIP:\n%s\n"), *Check->BeginnerTip);
		}

		if (!Check->DetectionMethod.IsEmpty())
		{
			Detail += FString::Printf(TEXT("\nDETECTION:\n%s\n"), *Check->DetectionMethod);
		}
	}

	if (SelectedItem->bFixed)
	{
		Detail += TEXT("\n[FIXED] — Click Revert to undo this fix.");
	}
	else if (SelectedItem->bAutoFixable)
	{
		Detail += TEXT("\nAuto-fix available — click 'Fix This Issue' to preview and apply.");
	}
	else
	{
		Detail += TEXT("\nManual fix required — click 'Navigate' to jump to the issue in the editor.");
	}

	DetailText->SetText(FText::FromString(Detail));
}

void SBPDoctorPanel::RefreshFilteredList()
{
	FilteredIssues.Empty();
	SelectedIssue.Reset();
	if (FixButton.IsValid()) FixButton->SetEnabled(false);
	if (RevertButton.IsValid()) RevertButton->SetEnabled(false);
	if (OpenEditorButton.IsValid()) OpenEditorButton->SetEnabled(false);
	if (CopyButton.IsValid()) CopyButton->SetEnabled(false);
	if (SuppressButton.IsValid()) SuppressButton->SetEnabled(false);

	for (const FBPDoctorAssetInfo& Info : AllResults)
	{
		for (const FBPDoctorResult& Issue : Info.Issues)
		{
			// Severity filter
			bool bShow = false;
			switch (Issue.Severity)
			{
				case EBPDoctorSeverity::Error:   bShow = bShowErrors;   break;
				case EBPDoctorSeverity::Warning: bShow = bShowWarnings; break;
				case EBPDoctorSeverity::Info:    bShow = bShowInfo;     break;
			}

			// Suppression filter
			FString SuppKey = Issue.CheckCode + TEXT("|") + Issue.AssetPath;
			bool bIsSuppressed = SuppressedIssueKeys.Contains(SuppKey);
			if (bShowSuppressed)
			{
				// Suppressed view: ONLY show suppressed items
				bShow = bIsSuppressed;
			}
			else if (bIsSuppressed)
			{
				// Normal view: hide suppressed items
				bShow = false;
			}

			// Search filter
			if (bShow && !SearchFilter.IsEmpty())
			{
				bShow = Issue.CheckCode.Contains(SearchFilter, ESearchCase::IgnoreCase) ||
						Issue.AssetName.Contains(SearchFilter, ESearchCase::IgnoreCase) ||
						Issue.Description.Contains(SearchFilter, ESearchCase::IgnoreCase);
			}

			if (bShow)
			{
				FilteredIssues.Add(MakeShareable(new FBPDoctorResult(Issue)));
			}
		}
	}

	// Sort by severity: Errors first, then Warnings, then Info
	FilteredIssues.Sort([](const TSharedPtr<FBPDoctorResult>& A, const TSharedPtr<FBPDoctorResult>& B)
	{
		return static_cast<int32>(A->Severity) < static_cast<int32>(B->Severity);
	});

	if (IssueListView.IsValid())
	{
		IssueListView->RequestListRefresh();
	}
}

void SBPDoctorPanel::UpdateStats()
{
	TotalScanned = AllResults.Num();
	TotalErrors = Scanner->GetErrorCount();
	TotalWarnings = Scanner->GetWarningCount();
	TotalInfos = Scanner->GetInfoCount();

	TotalAutoFixable = 0;
	for (const auto& Info : AllResults)
	{
		for (const auto& Issue : Info.Issues)
		{
			if (Issue.bAutoFixable && !Issue.bFixed) TotalAutoFixable++;
		}
	}

	// Calculate overall health grade
	if (TotalScanned == 0)
	{
		HealthGrade = TEXT("-");
	}
	else if (TotalErrors == 0 && TotalWarnings == 0 && TotalInfos == 0)
	{
		HealthGrade = TEXT("A+");
	}
	else if (TotalErrors == 0 && TotalWarnings == 0)
	{
		HealthGrade = TEXT("A");
	}
	else if (TotalErrors == 0 && TotalWarnings <= 3)
	{
		HealthGrade = TEXT("B+");
	}
	else if (TotalErrors == 0)
	{
		HealthGrade = TEXT("B");
	}
	else if (TotalErrors <= 2)
	{
		HealthGrade = TEXT("C");
	}
	else if (TotalErrors <= 5)
	{
		HealthGrade = TEXT("D");
	}
	else
	{
		HealthGrade = TEXT("F");
	}
}

// ─────────────────────────────────────────────────────────────────
//  ATTRIBUTE BINDINGS
// ─────────────────────────────────────────────────────────────────

TOptional<float> SBPDoctorPanel::GetProgressPercent() const
{
	if (!bScanRunning && CurrentProgress <= 0.f) return TOptional<float>();
	return CurrentProgress;
}

FText SBPDoctorPanel::GetHealthGradeText() const
{
	return FText::FromString(HealthGrade);
}

FSlateColor SBPDoctorPanel::GetHealthGradeColor() const
{
	if (HealthGrade == TEXT("A+") || HealthGrade == TEXT("A"))
		return FSlateColor(FLinearColor(0.f, 0.902f, 0.463f));
	if (HealthGrade == TEXT("B+") || HealthGrade == TEXT("B"))
		return FSlateColor(FLinearColor(1.f, 0.843f, 0.251f));
	if (HealthGrade == TEXT("C"))
		return FSlateColor(FLinearColor(1.f, 0.549f, 0.f));
	if (HealthGrade == TEXT("D") || HealthGrade == TEXT("F"))
		return FSlateColor(FLinearColor(1.f, 0.09f, 0.27f));
	return FSlateColor(FLinearColor(0.533f, 0.533f, 0.667f));
}

FText SBPDoctorPanel::GetStatsText() const
{
	if (TotalScanned == 0)
		return LOCTEXT("NoScan", "No scan results yet. Click Scan Project to begin.");

	FString StatsStr = FString::Printf(
		TEXT("Scanned: %d assets  |  %d AnimBPs + %d BPs\nErrors: %d  |  Warnings: %d  |  Info: %d  |  Auto-fixable: %d"),
		TotalScanned, Scanner->GetAnimBPCount(), Scanner->GetBlueprintCount(),
		TotalErrors, TotalWarnings, TotalInfos, TotalAutoFixable);
	if (SuppressedIssueKeys.Num() > 0)
	{
		StatsStr += FString::Printf(TEXT("  |  Suppressed: %d"), SuppressedIssueKeys.Num());
	}
	return FText::FromString(StatsStr);
}

// ─────────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────────

UBlueprint* SBPDoctorPanel::LoadBlueprintFromResult(const FBPDoctorResult& Result)
{
	// Try loading via AssetRegistry first (most reliable)
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

	// AssetPath from GetPathName() is like "/Game/Path/BP.BP"
	// Try as-is first
	FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(Result.AssetPath));
	if (AssetData.IsValid())
	{
		return Cast<UBlueprint>(AssetData.GetAsset());
	}

	// Fallback: try loading the object directly
	UObject* Obj = StaticLoadObject(UBlueprint::StaticClass(), nullptr, *Result.AssetPath);
	if (Obj)
	{
		return Cast<UBlueprint>(Obj);
	}

	// Final fallback: strip the object name suffix and try package path
	FString PackagePath = Result.AssetPath;
	int32 DotIndex;
	if (PackagePath.FindLastChar('.', DotIndex))
	{
		PackagePath = PackagePath.Left(DotIndex);
	}
	Obj = StaticLoadObject(UBlueprint::StaticClass(), nullptr, *PackagePath);
	return Cast<UBlueprint>(Obj);
}

// ─────────────────────────────────────────────────────────────────
//  FIX CONFIRMATION DIALOG
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::ShowFixConfirmDialog(TSharedPtr<FBPDoctorResult> Issue)
{
	UBlueprint* BP = LoadBlueprintFromResult(*Issue);
	if (!BP)
	{
		DetailText->SetText(FText::FromString(
			FString::Printf(TEXT("ERROR: Could not load Blueprint '%s'.\nIt may have been deleted or moved."),
				*Issue->AssetName)));
		return;
	}

	FBPDoctorFixAction Preview = FBPDoctorFixes::PreviewFix(*Issue, BP);

	TSharedPtr<int32> DialogResult = MakeShared<int32>(0);
	TSharedPtr<FString> CustomValue = MakeShared<FString>();

	// Fix type badge
	FString FixTypeStr;
	FLinearColor FixTypeColor;
	switch (Preview.FixType)
	{
		case EBPDoctorFixType::Programmatic:
			FixTypeStr = TEXT("AUTO-FIX AVAILABLE");
			FixTypeColor = FLinearColor(0.f, 0.902f, 0.463f);
			break;
		case EBPDoctorFixType::Script:
			FixTypeStr = TEXT("SCRIPT FIX");
			FixTypeColor = FLinearColor(1.f, 0.843f, 0.251f);
			break;
		default:
			FixTypeStr = TEXT("MANUAL FIX REQUIRED");
			FixTypeColor = FLinearColor(0.533f, 0.533f, 0.667f);
			break;
	}

	bool bCanAutoFix = (Preview.FixType == EBPDoctorFixType::Programmatic && Issue->bAutoFixable);

	// Manual input support — only for certain checks
	bool bHasCustomInput = bCanAutoFix &&
		(Issue->CheckCode == TEXT("BROKEN_BLEND_WT") || Issue->CheckCode == TEXT("DUP_SLOT"));
	FString InputLabel;
	FString InputDefault;
	if (Issue->CheckCode == TEXT("BROKEN_BLEND_WT"))
	{
		InputLabel = TEXT("CUSTOM VALUE (optional — leave empty for auto-clamp):");
		InputDefault = TEXT("");
	}
	else if (Issue->CheckCode == TEXT("DUP_SLOT"))
	{
		InputLabel = TEXT("CUSTOM SLOT NAME (optional — leave empty for auto-suffix):");
		InputDefault = TEXT("");
	}

	TSharedRef<SWindow> DialogWindow = SNew(SWindow)
		.Title(LOCTEXT("FixPreviewTitle", "BP Doctor — Fix Preview"))
		.ClientSize(FVector2D(540, 440))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.IsTopmostWindow(true);

	TWeakPtr<SWindow> WeakWindow(DialogWindow);

	DialogWindow->SetContent(
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
		.Padding(16)
		[
			SNew(SVerticalBox)

			// Header
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(STextBlock)
					.Text(FText::FromString(Issue->CheckCode))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(12, 3, 0, 0)
				[
					SNew(STextBlock)
					.Text(FText::FromString(FixTypeStr))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9))
					.ColorAndOpacity(FixTypeColor)
				]
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
			[
				SNew(STextBlock)
				.Text(FText::FromString(FString::Printf(TEXT("Asset: %s"), *Issue->AssetName)))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 4)
			[ SNew(SSeparator) ]

			// Description
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("WhatThisDoes2", "WHAT THIS FIX DOES:"))
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
				.ColorAndOpacity(FLinearColor(0.533f, 0.533f, 0.667f))
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
			[
				SNew(STextBlock)
				.Text(FText::FromString(Preview.Description))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 11))
				.AutoWrapText(true)
			]

			// Changes
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Changes2", "CHANGES:"))
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
				.ColorAndOpacity(FLinearColor(0.533f, 0.533f, 0.667f))
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
			[
				SNew(STextBlock)
				.Text(FText::FromString(Preview.Preview.IsEmpty() ? TEXT("See description above.") : Preview.Preview))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 11))
				.AutoWrapText(true)
			]

			// Manual input (only visible for supported checks)
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 4, 0, 4)
			[
				SNew(SVerticalBox)
				.Visibility(bHasCustomInput ? EVisibility::Visible : EVisibility::Collapsed)

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(STextBlock)
					.Text(FText::FromString(InputLabel))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
					.ColorAndOpacity(FLinearColor(1.f, 0.843f, 0.251f))
				]
				+ SVerticalBox::Slot().AutoHeight()
				[
					SNew(SEditableTextBox)
					.HintText(LOCTEXT("CustomHint", "Leave empty for default behavior"))
					.OnTextChanged_Lambda([CustomValue](const FText& Text) { *CustomValue = Text.ToString(); })
				]
			]

			// Revert note
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 12)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("UndoNote2", "All fixes can be reverted with Ctrl+Z or the Undo Fix button."))
				.Font(FCoreStyle::GetDefaultFontStyle("Italic", 9))
				.ColorAndOpacity(FLinearColor(0.f, 0.902f, 0.463f))
			]

			+ SVerticalBox::Slot().FillHeight(1.f) [ SNew(SSpacer) ]

			// Buttons
			+ SVerticalBox::Slot().AutoHeight()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
				[
					SNew(SButton)
					.Text(LOCTEXT("ApplyFixBtn2", "Apply Fix"))
					.ToolTipText(LOCTEXT("ApplyFixTip2", "Apply the fix now (undoable with Ctrl+Z)"))
					.IsEnabled(bCanAutoFix)
					.OnClicked_Lambda([DialogResult, WeakWindow]() {
						*DialogResult = 1;
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
				[
					SNew(SButton)
					.Text(LOCTEXT("OpenEditorBtn2", "Open in Editor"))
					.ToolTipText(LOCTEXT("OpenEditorTip2", "Open the Blueprint for manual editing"))
					.OnClicked_Lambda([DialogResult, WeakWindow]() {
						*DialogResult = 2;
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().FillWidth(1.f) [ SNew(SSpacer) ]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton)
					.Text(LOCTEXT("CancelBtn2", "Cancel"))
					.OnClicked_Lambda([WeakWindow]() {
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		]
	);

	FSlateApplication::Get().AddModalWindow(DialogWindow, TSharedPtr<const SWidget>());

	if (*DialogResult == 1)
	{
		// Backup .uasset BEFORE fixing — bulletproof revert
		FString BackupPath = BackupPackageFile(BP);

		FScopedTransaction Transaction(FText::Format(
			LOCTEXT("BPDFixTx2", "BP Doctor: Fix {0} in {1}"),
			FText::FromString(Issue->CheckCode),
			FText::FromString(Issue->AssetName)));

		BP->Modify();
		bool bSuccess = FBPDoctorFixes::ApplyFix(*Issue, BP, *CustomValue);

		if (bSuccess)
		{
			Issue->bFixed = true;
			for (FBPDoctorAssetInfo& Info : AllResults)
			{
				for (FBPDoctorResult& R : Info.Issues)
				{
					if (R.CheckCode == Issue->CheckCode && R.AssetPath == Issue->AssetPath)
						R.bFixed = true;
				}
			}

			FBPDoctorFixHistoryEntry Entry;
			Entry.CheckCode = Issue->CheckCode;
			Entry.AssetName = Issue->AssetName;
			Entry.AssetPath = Issue->AssetPath;
			Entry.FixDescription = Preview.Description;
			if (!BackupPath.IsEmpty())
			{
				FString PkgFile;
				FPackageName::DoesPackageExist(BP->GetPackage()->GetName(), &PkgFile);
				Entry.Backups.Add(PkgFile, BackupPath);
			}
			FixHistory.Add(Entry);

			UpdateStats();
			RefreshFilteredList();
			DetailText->SetText(FText::FromString(FString::Printf(
				TEXT("FIXED: %s in %s\n\nBlueprint modified. Save to persist, or Ctrl+Z / Undo Fix to revert."),
				*Issue->CheckCode, *Issue->AssetName)));
		}
		else
		{
			DetailText->SetText(FText::FromString(
				TEXT("Fix could not be applied automatically.\nUse 'Open in Editor' for manual intervention.")));
		}
	}
	else if (*DialogResult == 2)
	{
		OpenBlueprintInEditor(Issue->AssetPath);
	}
}

// ─────────────────────────────────────────────────────────────────
//  FIX ALL DIALOG — checklist UI
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::ShowFixAllDialog()
{
	// Collect all fixable issues with their asset paths
	TArray<FBPDoctorResult> FixableIssues;
	TArray<FString> AssetPaths;
	TArray<TSharedPtr<bool>> Selections;

	for (const FBPDoctorAssetInfo& Info : AllResults)
	{
		for (const FBPDoctorResult& Issue : Info.Issues)
		{
			if (Issue.bAutoFixable && !Issue.bFixed)
			{
				FixableIssues.Add(Issue);
				AssetPaths.Add(Info.AssetPath);
				Selections.Add(MakeShared<bool>(true));
			}
		}
	}

	if (FixableIssues.Num() == 0)
	{
		DetailText->SetText(LOCTEXT("NoFixable", "No auto-fixable issues found."));
		return;
	}

	TSharedPtr<bool> bApply = MakeShared<bool>(false);

	TSharedRef<SWindow> DialogWindow = SNew(SWindow)
		.Title(LOCTEXT("FixAllDlgTitle", "BP Doctor — Fix All Preview"))
		.ClientSize(FVector2D(700, 520))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.IsTopmostWindow(true);

	TWeakPtr<SWindow> WeakWindow(DialogWindow);

	// Build the scrollable checklist
	TSharedRef<SScrollBox> CheckList = SNew(SScrollBox);

	for (int32 i = 0; i < FixableIssues.Num(); ++i)
	{
		TSharedPtr<bool> Sel = Selections[i];
		const FBPDoctorResult& Issue = FixableIssues[i];

		FLinearColor SevColor = (Issue.Severity == EBPDoctorSeverity::Error)
			? FLinearColor(1.f, 0.09f, 0.27f)
			: (Issue.Severity == EBPDoctorSeverity::Warning)
				? FLinearColor(1.f, 0.843f, 0.251f)
				: FLinearColor(0.f, 0.898f, 1.f);

		FString SevStr = (Issue.Severity == EBPDoctorSeverity::Error) ? TEXT("ERR")
			: (Issue.Severity == EBPDoctorSeverity::Warning) ? TEXT("WRN") : TEXT("INF");

		CheckList->AddSlot()
		.Padding(2, 2)
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([Sel]() { return *Sel ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([Sel](ECheckBoxState State) { *Sel = (State == ECheckBoxState::Checked); })
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(4, 0)
				[
					SNew(SBox).WidthOverride(35)
					[
						SNew(STextBlock)
						.Text(FText::FromString(SevStr))
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9))
						.ColorAndOpacity(SevColor)
					]
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(4, 0)
				[
					SNew(SBox).WidthOverride(130)
					[
						SNew(STextBlock)
						.Text(FText::FromString(Issue.CheckCode))
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9))
						.ColorAndOpacity(SevColor)
					]
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(4, 0)
				[
					SNew(SBox).WidthOverride(140)
					[
						SNew(STextBlock)
						.Text(FText::FromString(Issue.AssetName))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					]
				]
				+ SHorizontalBox::Slot().FillWidth(1.f).Padding(4, 0)
				[
					SNew(STextBlock)
					.Text(FText::FromString(Issue.Description))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.AutoWrapText(true)
				]
			]
		];
	}

	DialogWindow->SetContent(
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
		.Padding(16)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
			[
				SNew(STextBlock)
				.Text(FText::Format(LOCTEXT("FixAllItemCount", "{0} auto-fixable issues found"), FText::AsNumber(FixableIssues.Num())))
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
				.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().FillWidth(1.f)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("FixAllInstructions", "Uncheck issues to skip. All fixes are revertable via Undo Fix."))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
					.AutoWrapText(true)
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(8, 0, 4, 0)
				[
					SNew(SButton)
					.Text(LOCTEXT("SelectAllBtn", "Select All"))
					.OnClicked_Lambda([Selections]() {
						for (const auto& Sel : Selections) *Sel = true;
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton)
					.Text(LOCTEXT("DeselectAllBtn", "Deselect All"))
					.OnClicked_Lambda([Selections]() {
						for (const auto& Sel : Selections) *Sel = false;
						return FReply::Handled();
					})
				]
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0, 4)
			[ SNew(SSeparator) ]

			// Checklist
			+ SVerticalBox::Slot().FillHeight(1.f).Padding(0, 4)
			[ CheckList ]

			+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 0)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
				[
					SNew(SButton)
					.Text(LOCTEXT("ApplySelectedBtn", "Apply Selected Fixes"))
					.ToolTipText(LOCTEXT("ApplySelectedTip", "Apply all checked fixes (undoable with Ctrl+Z)"))
					.OnClicked_Lambda([bApply, WeakWindow]() {
						*bApply = true;
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().FillWidth(1.f) [ SNew(SSpacer) ]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton)
					.Text(LOCTEXT("CancelAllBtn", "Cancel"))
					.OnClicked_Lambda([WeakWindow]() {
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		]
	);

	FSlateApplication::Get().AddModalWindow(DialogWindow, TSharedPtr<const SWidget>());

	if (!*bApply) return;

	// Count selected
	int32 SelectedCount = 0;
	for (const auto& Sel : Selections)
	{
		if (*Sel) SelectedCount++;
	}
	if (SelectedCount == 0) return;

	// Backup all affected .uasset files BEFORE fixing
	TMap<FString, FString> BatchBackups; // OriginalPath -> BackupPath
	for (int32 i = 0; i < FixableIssues.Num(); ++i)
	{
		if (!*Selections[i]) continue;
		const FString& Path = AssetPaths[i];
		if (!BatchBackups.Contains(Path))
		{
			FBPDoctorResult TmpR;
			TmpR.AssetPath = Path;
			UBlueprint* TmpBP = LoadBlueprintFromResult(TmpR);
			FString BkPath = BackupPackageFile(TmpBP);
			if (!BkPath.IsEmpty())
			{
				FString PkgFile;
				FPackageName::DoesPackageExist(TmpBP->GetPackage()->GetName(), &PkgFile);
				BatchBackups.Add(PkgFile, BkPath);
			}
		}
	}

	// Apply all selected in single transaction
	FScopedTransaction Transaction(FText::Format(
		LOCTEXT("FixSelTx", "BP Doctor: Fix Selected ({0} issues)"),
		FText::AsNumber(SelectedCount)));

	int32 TotalFixed = 0;
	TMap<FString, UBlueprint*> LoadedBPs;

	for (int32 i = 0; i < FixableIssues.Num(); ++i)
	{
		if (!*Selections[i]) continue;

		const FString& Path = AssetPaths[i];
		UBlueprint* BP = nullptr;

		if (UBlueprint** Found = LoadedBPs.Find(Path))
		{
			BP = *Found;
		}
		else
		{
			IAssetRegistry& AR = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();
			FAssetData AD = AR.GetAssetByObjectPath(FSoftObjectPath(Path));
			BP = AD.IsValid() ? Cast<UBlueprint>(AD.GetAsset()) : nullptr;
			if (BP)
			{
				BP->Modify();
				LoadedBPs.Add(Path, BP);
			}
		}

		if (BP && FBPDoctorFixes::ApplyFix(FixableIssues[i], BP))
		{
			TotalFixed++;
			for (FBPDoctorAssetInfo& Info : AllResults)
			{
				for (FBPDoctorResult& R : Info.Issues)
				{
					if (R.CheckCode == FixableIssues[i].CheckCode && R.AssetPath == FixableIssues[i].AssetPath)
						R.bFixed = true;
				}
			}
		}
	}

	FBPDoctorFixHistoryEntry Entry;
	Entry.CheckCode = TEXT("FIX_ALL");
	Entry.AssetName = FString::Printf(TEXT("%d of %d selected fixes applied"), TotalFixed, SelectedCount);
	Entry.FixDescription = TEXT("Batch fix (selected)");
	Entry.Backups = BatchBackups;
	FixHistory.Add(Entry);

	UpdateStats();
	RefreshFilteredList();
	DetailText->SetText(FText::FromString(FString::Printf(
		TEXT("Applied %d fixes.\n\nAll changes are undoable via Ctrl+Z or the Undo Fix button.\nRe-scan to verify."),
		TotalFixed)));
}

// ─────────────────────────────────────────────────────────────────
//  UNDO / REVERT
// ─────────────────────────────────────────────────────────────────

FReply SBPDoctorPanel::OnUndoLastFix()
{
	int32 LastIndex = -1;
	for (int32 i = FixHistory.Num() - 1; i >= 0; --i)
	{
		if (!FixHistory[i].bReverted)
		{
			LastIndex = i;
			break;
		}
	}

	if (LastIndex < 0)
	{
		DetailText->SetText(LOCTEXT("NoFixToUndo", "No fixes to undo."));
		return FReply::Handled();
	}

	// Try multiple undo methods — at least one will work
	bool bUndone = false;
	if (GEditor)
	{
		// Method 1: Transaction buffer direct undo (most reliable)
		if (GEditor->Trans && GEditor->Trans->CanUndo())
		{
			GEditor->Trans->Undo();
			bUndone = true;
		}
	}

	if (bUndone)
	{
		FixHistory[LastIndex].bReverted = true;
		DetailText->SetText(FText::FromString(FString::Printf(
			TEXT("REVERTED: %s in %s\n\nBlueprint restored. Re-scan to refresh results."),
			*FixHistory[LastIndex].CheckCode, *FixHistory[LastIndex].AssetName)));
	}
	else
	{
		// Fallback: reload from disk if transaction undo failed
		if (!FixHistory[LastIndex].AssetPath.IsEmpty())
		{
			RevertBlueprint(FixHistory[LastIndex].AssetPath);
			FixHistory[LastIndex].bReverted = true;
			DetailText->SetText(FText::FromString(FString::Printf(
				TEXT("REVERTED: %s in %s\n\nBlueprint reloaded from disk. Re-scan to refresh."),
				*FixHistory[LastIndex].CheckCode, *FixHistory[LastIndex].AssetName)));
		}
		else
		{
			DetailText->SetText(FText::FromString(
				TEXT("Could not undo automatically.\nRight-click the asset in Content Browser → Asset Actions → Reload to revert.")));
		}
	}

	return FReply::Handled();
}

FReply SBPDoctorPanel::OnRevertSelected()
{
	if (!SelectedIssue.IsValid() || !SelectedIssue->bFixed)
		return FReply::Handled();

	FString RevertedCheck = SelectedIssue->CheckCode;
	FString RevertedAsset = SelectedIssue->AssetName;
	FString RevertedPath = SelectedIssue->AssetPath;

	// Find the fix history entry with backup files
	FBPDoctorFixHistoryEntry* HistEntry = nullptr;
	for (int32 i = FixHistory.Num() - 1; i >= 0; --i)
	{
		if (!FixHistory[i].bReverted &&
			FixHistory[i].CheckCode == RevertedCheck &&
			FixHistory[i].AssetPath == RevertedPath)
		{
			HistEntry = &FixHistory[i];
			break;
		}
	}

	bool bReverted = false;

	if (HistEntry && HistEntry->Backups.Num() > 0)
	{
		// Bulletproof revert: restore from backup files
		UBlueprint* BP = LoadBlueprintFromResult(*SelectedIssue);
		if (BP && GEditor)
		{
			GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseAllEditorsForAsset(BP);
		}

		for (const auto& Pair : HistEntry->Backups)
		{
			const FString& OriginalPath = Pair.Key;
			const FString& BackupPath = Pair.Value;

			// Copy backup back over the original .uasset
			IFileManager::Get().Copy(*OriginalPath, *BackupPath, true);

			// Force reload from restored file
			if (BP)
			{
				UPackage* Package = BP->GetPackage();
				if (Package)
				{
					ResetLoaders(Package);
					LoadPackage(Package, *OriginalPath, LOAD_None);
				}
			}

			// Clean up backup file
			IFileManager::Get().Delete(*BackupPath);
		}

		HistEntry->Backups.Empty();
		HistEntry->bReverted = true;
		bReverted = true;
	}
	else
	{
		// Fallback: try transaction undo
		if (GEditor && GEditor->Trans && GEditor->Trans->CanUndo())
		{
			GEditor->Trans->Undo();
			bReverted = true;
			if (HistEntry) HistEntry->bReverted = true;
		}
	}

	if (bReverted)
	{
		for (FBPDoctorAssetInfo& Info : AllResults)
		{
			for (FBPDoctorResult& R : Info.Issues)
			{
				if (R.CheckCode == RevertedCheck && R.AssetPath == RevertedPath)
					R.bFixed = false;
			}
		}
		UpdateStats();
		RefreshFilteredList();
		DetailText->SetText(FText::FromString(FString::Printf(
			TEXT("REVERTED: %s in %s\n\nBlueprint restored to pre-fix state.\nRe-scan to verify."),
			*RevertedCheck, *RevertedAsset)));
	}

	return FReply::Handled();
}

void SBPDoctorPanel::RevertBlueprint(const FString& AssetPath)
{
	// Find history entry with backup for this asset
	for (int32 i = FixHistory.Num() - 1; i >= 0; --i)
	{
		if (!FixHistory[i].bReverted && FixHistory[i].AssetPath == AssetPath && FixHistory[i].Backups.Num() > 0)
		{
			FBPDoctorResult TempResult;
			TempResult.AssetPath = AssetPath;
			UBlueprint* BP = LoadBlueprintFromResult(TempResult);
			if (BP && GEditor)
			{
				GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseAllEditorsForAsset(BP);
			}

			for (const auto& Pair : FixHistory[i].Backups)
			{
				IFileManager::Get().Copy(*Pair.Key, *Pair.Value, true);
				if (BP)
				{
					UPackage* Package = BP->GetPackage();
					if (Package)
					{
						ResetLoaders(Package);
						LoadPackage(Package, *Pair.Key, LOAD_None);
					}
				}
				IFileManager::Get().Delete(*Pair.Value);
			}
			FixHistory[i].Backups.Empty();
			FixHistory[i].bReverted = true;
			return;
		}
	}

	// Fallback if no backup exists: try reload from existing disk file
	FBPDoctorResult TempResult;
	TempResult.AssetPath = AssetPath;
	UBlueprint* BP = LoadBlueprintFromResult(TempResult);
	if (!BP) return;
	if (GEditor) GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseAllEditorsForAsset(BP);
	UPackage* Package = BP->GetPackage();
	if (!Package) return;
	FString PkgFile;
	if (FPackageName::DoesPackageExist(Package->GetName(), &PkgFile))
	{
		ResetLoaders(Package);
		LoadPackage(Package, *PkgFile, LOAD_None);
	}
}

FString SBPDoctorPanel::BackupPackageFile(UBlueprint* BP)
{
	if (!BP) return FString();

	UPackage* Package = BP->GetPackage();
	if (!Package) return FString();

	FString PkgFilename;
	if (!FPackageName::DoesPackageExist(Package->GetName(), &PkgFilename))
		return FString();

	FString BackupDir = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("Backups");
	IFileManager::Get().MakeDirectory(*BackupDir, true);
	FString BackupPath = BackupDir / FString::Printf(TEXT("backup_%s.uasset"),
		*FGuid::NewGuid().ToString().Left(8));

	if (IFileManager::Get().Copy(*BackupPath, *PkgFilename) == COPY_OK)
	{
		return BackupPath;
	}
	return FString();
}

void SBPDoctorPanel::NavigateToIssue(const FBPDoctorResult& Result)
{
	UBlueprint* BP = LoadBlueprintFromResult(Result);
	if (!BP || !GEditor) return;

	// Open the Blueprint in the editor
	GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(BP);

	// Try to find and zoom to the specific node mentioned in NodeHint
	if (!Result.NodeHint.IsEmpty())
	{
		TArray<UEdGraph*> AllGraphs;
		AllGraphs.Append(BP->UbergraphPages);
		AllGraphs.Append(BP->FunctionGraphs);
		AllGraphs.Append(BP->MacroGraphs);

		for (UEdGraph* Graph : AllGraphs)
		{
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				FString NodeTitle = Node->GetNodeTitle(ENodeTitleType::FullTitle).ToString();
				FString NodeName = Node->GetName();
				if (Result.NodeHint.Contains(NodeTitle) || NodeTitle.Contains(Result.NodeHint) ||
					Result.NodeHint.Contains(NodeName))
				{
					FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(Node);
					return;
				}
			}
		}
	}
}

// ─────────────────────────────────────────────────────────────────
//  COPY / SUPPRESS
// ─────────────────────────────────────────────────────────────────

FReply SBPDoctorPanel::OnCopyDetails()
{
	if (!SelectedIssue.IsValid()) return FReply::Handled();

	const FBPDoctorCheckDef* Check = FBPDoctorChecks::FindCheck(SelectedIssue->CheckCode);

	FString ClipText;
	ClipText += FString::Printf(TEXT("BP Doctor Issue: %s\n"), *SelectedIssue->CheckCode);
	ClipText += FString::Printf(TEXT("Asset: %s\n"), *SelectedIssue->AssetName);
	ClipText += FString::Printf(TEXT("Path: %s\n"), *SelectedIssue->AssetPath);
	FString SevStr = (SelectedIssue->Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
		(SelectedIssue->Severity == EBPDoctorSeverity::Warning) ? TEXT("WARNING") : TEXT("INFO");
	ClipText += FString::Printf(TEXT("Severity: %s\n"), *SevStr);
	if (Check)
	{
		FString ConfStr = (Check->Confidence == EBPDoctorConfidence::High) ? TEXT("HIGH") :
			(Check->Confidence == EBPDoctorConfidence::Medium) ? TEXT("MEDIUM") : TEXT("LOW");
		ClipText += FString::Printf(TEXT("Confidence: %s\n"), *ConfStr);
		ClipText += FString::Printf(TEXT("Name: %s\n"), *Check->Name);
	}
	ClipText += FString::Printf(TEXT("Description: %s\n"), *SelectedIssue->Description);
	if (!SelectedIssue->NodeHint.IsEmpty())
		ClipText += FString::Printf(TEXT("Node: %s\n"), *SelectedIssue->NodeHint);
	if (Check)
		ClipText += FString::Printf(TEXT("Why It Matters: %s\n"), *Check->WhyItMatters);
	ClipText += FString::Printf(TEXT("Auto-fixable: %s\n"), SelectedIssue->bAutoFixable ? TEXT("Yes") : TEXT("No"));
	if (SelectedIssue->bFixed)
		ClipText += TEXT("Status: FIXED\n");

	FPlatformApplicationMisc::ClipboardCopy(*ClipText);
	DetailText->SetText(FText::FromString(TEXT("Issue details copied to clipboard.")));
	return FReply::Handled();
}

FReply SBPDoctorPanel::OnSuppressSelected()
{
	if (!SelectedIssue.IsValid()) return FReply::Handled();

	FString Key = SelectedIssue->CheckCode + TEXT("|") + SelectedIssue->AssetPath;
	FString Code = SelectedIssue->CheckCode;
	FString Asset = SelectedIssue->AssetName;

	if (SuppressedIssueKeys.Contains(Key))
	{
		// Unsuppress
		SuppressedIssueKeys.Remove(Key);
		SaveSettings();
		RefreshFilteredList();
		DetailText->SetText(FText::FromString(FString::Printf(
			TEXT("UNSUPPRESSED: %s in %s\n\nThis issue will appear in normal scan results again."),
			*Code, *Asset)));
	}
	else
	{
		// Suppress
		SuppressedIssueKeys.Add(Key);
		SaveSettings();
		RefreshFilteredList();
		DetailText->SetText(FText::FromString(FString::Printf(
			TEXT("SUPPRESSED: %s in %s\n\nToggle the 'Suppressed' filter to view and unsuppress."),
			*Code, *Asset)));
	}

	return FReply::Handled();
}

// ─────────────────────────────────────────────────────────────────
//  OPEN IN EDITOR
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::OpenBlueprintInEditor(const FString& AssetPath)
{
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();
	FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(AssetPath));

	UObject* Asset = AssetData.IsValid() ? AssetData.GetAsset() : nullptr;
	if (!Asset)
	{
		Asset = StaticLoadObject(UBlueprint::StaticClass(), nullptr, *AssetPath);
	}

	if (!Asset)
	{
		FString PackagePath = AssetPath;
		int32 DotIndex;
		if (PackagePath.FindLastChar('.', DotIndex))
		{
			PackagePath = PackagePath.Left(DotIndex);
		}
		Asset = StaticLoadObject(UBlueprint::StaticClass(), nullptr, *PackagePath);
	}

	if (Asset && GEditor)
	{
		GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Asset);
	}
}

// ─────────────────────────────────────────────────────────────────
//  CHECK LIBRARY + ENABLE/DISABLE
// ─────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────
//  SETTINGS DIALOG — interactive GUI
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::ShowSettingsDialog()
{
	TSharedRef<SWindow> DialogWindow = SNew(SWindow)
		.Title(LOCTEXT("SettingsWinTitle", "BP Doctor — Settings"))
		.ClientSize(FVector2D(550, 480))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.IsTopmostWindow(true);

	TWeakPtr<SWindow> WeakWindow(DialogWindow);

	// Experience mode selection (copy current value for the dialog)
	TSharedPtr<int32> SelectedMode = MakeShared<int32>(static_cast<int32>(ExperienceMode));

	FString SettingsDir = FPaths::ProjectSavedDir() / TEXT("BPDoctor");
	FString CustomRulesPath = SettingsDir / TEXT("CustomRules.json");
	bool bHasCustomRules = FPaths::FileExists(CustomRulesPath);
	int32 NumCustomRules = 0;
	for (const auto& C : FBPDoctorChecks::GetAllChecks()) { if (C.Id >= 100) NumCustomRules++; }

	DialogWindow->SetContent(
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
		.Padding(16)
		[
			SNew(SScrollBox)
			+ SScrollBox::Slot()
			[
				SNew(SVerticalBox)

				// ── EXPERIENCE MODE ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("ExpModeLabel", "EXPERIENCE MODE"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("ExpModeDesc", "Controls how much guidance and detail is shown in the detail panel."))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.AutoWrapText(true)
				]

				// Radio-style buttons for each mode
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(SCheckBox)
					.Style(FCoreStyle::Get(), "RadioButton")
					.IsChecked_Lambda([SelectedMode]() { return *SelectedMode == 0 ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
					.OnCheckStateChanged_Lambda([SelectedMode](ECheckBoxState) { *SelectedMode = 0; })
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("BegLabel", "Beginner")).Font(FCoreStyle::GetDefaultFontStyle("Bold", 10)) ]
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("BegDesc", "Full guidance: step-by-step fix instructions, beginner tips, why-it-matters explanations, detection method details.")).Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)).AutoWrapText(true) ]
					]
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(SCheckBox)
					.Style(FCoreStyle::Get(), "RadioButton")
					.IsChecked_Lambda([SelectedMode]() { return *SelectedMode == 1 ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
					.OnCheckStateChanged_Lambda([SelectedMode](ECheckBoxState) { *SelectedMode = 1; })
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("IntLabel", "Intermediate")).Font(FCoreStyle::GetDefaultFontStyle("Bold", 10)) ]
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("IntDesc", "Standard: check details, fix instructions, confidence level. No beginner tips.")).Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)).AutoWrapText(true) ]
					]
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 12)
				[
					SNew(SCheckBox)
					.Style(FCoreStyle::Get(), "RadioButton")
					.IsChecked_Lambda([SelectedMode]() { return *SelectedMode == 2 ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
					.OnCheckStateChanged_Lambda([SelectedMode](ECheckBoxState) { *SelectedMode = 2; })
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("ExpLabel", "Expert")).Font(FCoreStyle::GetDefaultFontStyle("Bold", 10)) ]
						+ SVerticalBox::Slot().AutoHeight()
						[ SNew(STextBlock).Text(LOCTEXT("ExpDesc", "Minimal: one-line compact view. Code, severity, asset, description. No guidance.")).Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)).AutoWrapText(true) ]
					]
				]

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 4) [ SNew(SSeparator) ]

				// ── CHECKS ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("ChecksLabel", "CHECKS"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(STextBlock)
					.Text(FText::FromString(FString::Printf(TEXT("26 built-in checks  |  %d disabled  |  %d custom rules loaded"),
						DisabledChecks.Num(), NumCustomRules)))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 12)
				[
					SNew(SButton)
					.Text(LOCTEXT("ManageChecks", "Manage Checks..."))
					.ToolTipText(LOCTEXT("ManageChecksTip", "Open the Check Library to enable/disable individual checks"))
					.OnClicked_Lambda([this, WeakWindow]() {
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						ShowChecksDialog();
						return FReply::Handled();
					})
				]

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 4) [ SNew(SSeparator) ]

				// ── SUPPRESSION ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("SuppLabel", "SUPPRESSION"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(STextBlock)
					.Text(FText::FromString(FString::Printf(TEXT("%d issues currently suppressed."), SuppressedIssueKeys.Num())))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 12)
				[
					SNew(SButton)
					.Text(LOCTEXT("ClearAllSupp", "Clear All Suppressions"))
					.IsEnabled(SuppressedIssueKeys.Num() > 0)
					.OnClicked_Lambda([this]() {
						SuppressedIssueKeys.Empty();
						SaveSettings();
						RefreshFilteredList();
						return FReply::Handled();
					})
				]

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 4) [ SNew(SSeparator) ]

				// ── CUSTOM RULES ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("CustomLabel", "CUSTOM RULES"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
				[
					SNew(STextBlock)
					.Text(FText::FromString(FString::Printf(TEXT("%d custom rules loaded.  |  File: %s"),
						NumCustomRules, bHasCustomRules ? TEXT("Found") : TEXT("Not created yet"))))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 4, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("EditRules", "Edit Rules..."))
						.ToolTipText(LOCTEXT("EditRulesTip", "Open the visual custom rules editor"))
						.OnClicked_Lambda([this, WeakWindow]() {
							if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
							ShowCustomRulesEditor();
							return FReply::Handled();
						})
					]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 4, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("ImportRulesBtn", "Import..."))
						.ToolTipText(LOCTEXT("ImportRulesTip", "Import a custom rules JSON file from disk"))
						.OnClicked_Lambda([this]() {
							ImportCustomRules();
							return FReply::Handled();
						})
					]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 4, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("CreateExample", "Create Example"))
						.ToolTipText(LOCTEXT("CreateExampleTip", "Create a starter CustomRules.json with example rules"))
						.IsEnabled(!bHasCustomRules)
						.OnClicked_Lambda([this, CustomRulesPath]() {
							FString ExampleContent = TEXT("{\n  \"rules\": [\n    {\n      \"name\": \"Ban GetAllActorsOfClass\",\n      \"code\": \"CUSTOM_NO_GAA\",\n      \"severity\": \"WARNING\",\n      \"confidence\": \"HIGH\",\n      \"description\": \"GetAllActorsOfClass is expensive at scale.\",\n      \"why_it_matters\": \"Iterates the entire actor list every call.\",\n      \"beginner_tip\": \"Store the result in a variable instead.\",\n      \"type\": \"banned_function\",\n      \"function_name\": \"GetAllActorsOfClass\"\n    }\n  ]\n}");
							FString Dir = FPaths::GetPath(CustomRulesPath);
							IFileManager::Get().MakeDirectory(*Dir, true);
							FFileHelper::SaveStringToFile(ExampleContent, *CustomRulesPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
							FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Example rules created at:\n%s\n\nEdit the file to add your own rules, then re-scan."), *CustomRulesPath)));
							return FReply::Handled();
						})
					]
				]

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 12) [ SNew(SSeparator) ]

				// ── IMPORT / EXPORT SETTINGS ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("IOLabel", "CONFIGURATION"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("IODesc", "Import or export your full BP Doctor configuration (experience mode, disabled checks, suppressions) to share across projects or team members."))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.AutoWrapText(true)
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 4)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 4, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("ImportSettingsBtn", "Import Settings..."))
						.ToolTipText(LOCTEXT("ImportSettingsTip", "Load a Settings.json from another location"))
						.OnClicked_Lambda([this]() { ImportSettings(); return FReply::Handled(); })
					]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 4, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("ExportSettingsBtn", "Export Settings..."))
						.ToolTipText(LOCTEXT("ExportSettingsTip", "Save your current settings to a file for sharing"))
						.OnClicked_Lambda([this]() { ExportSettings(); return FReply::Handled(); })
					]
				]

				+ SVerticalBox::Slot().AutoHeight().Padding(0, 12) [ SNew(SSeparator) ]

				// ── FILE PATHS ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 4)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("PathsLabel", "FILE PATHS"))
					.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
					.ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f))
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 12)
				[
					SNew(STextBlock)
					.Text(FText::FromString(FString::Printf(TEXT("Settings: %s/Settings.json\nCustom Rules: %s/CustomRules.json\nBackups: %s/Backups/"),
						*SettingsDir, *SettingsDir, *SettingsDir)))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.AutoWrapText(true)
				]

				// ── BUTTONS ──
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 0)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
					[
						SNew(SButton)
						.Text(LOCTEXT("SaveSettings", "Save & Close"))
						.OnClicked_Lambda([this, SelectedMode, WeakWindow]() {
							ExperienceMode = static_cast<EBPDoctorExperienceMode>(*SelectedMode);
							SaveSettings();
							if (SelectedIssue.IsValid())
								OnSelectionChanged(SelectedIssue, ESelectInfo::Direct);
							if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
							return FReply::Handled();
						})
					]
					+ SHorizontalBox::Slot().FillWidth(1.f) [ SNew(SSpacer) ]
					+ SHorizontalBox::Slot().AutoWidth()
					[
						SNew(SButton)
						.Text(LOCTEXT("CancelSettings", "Cancel"))
						.OnClicked_Lambda([WeakWindow]() {
							if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
							return FReply::Handled();
						})
					]
				]
			]
		]
	);

	FSlateApplication::Get().AddModalWindow(DialogWindow, TSharedPtr<const SWidget>());
}

// ─────────────────────────────────────────────────────────────────
//  CUSTOM RULES EDITOR GUI
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::ShowCustomRulesEditor()
{
	FString RulesPath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("CustomRules.json");

	// Load existing rules into editable structures
	struct FEditableRule
	{
		TSharedPtr<FString> Name, Code, Description, Type, MatchStr, Severity;
		TSharedPtr<int32> MaxCount;
		TSharedPtr<bool> bAnimBPOnly;
	};

	TArray<TSharedPtr<FEditableRule>> Rules;

	// Parse existing file
	FString JsonStr;
	if (FFileHelper::LoadFileToString(JsonStr, *RulesPath))
	{
		TSharedPtr<FJsonObject> Root;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonStr);
		if (FJsonSerializer::Deserialize(Reader, Root) && Root.IsValid())
		{
			const TArray<TSharedPtr<FJsonValue>>* Arr;
			if (Root->TryGetArrayField(TEXT("rules"), Arr))
			{
				for (const auto& V : *Arr)
				{
					const TSharedPtr<FJsonObject>* Obj;
					if (!V->TryGetObject(Obj)) continue;
					TSharedPtr<FEditableRule> R = MakeShared<FEditableRule>();
					R->Name = MakeShared<FString>((*Obj)->GetStringField(TEXT("name")));
					R->Code = MakeShared<FString>((*Obj)->GetStringField(TEXT("code")));
					R->Description = MakeShared<FString>((*Obj)->GetStringField(TEXT("description")));
					R->Type = MakeShared<FString>((*Obj)->GetStringField(TEXT("type")));
					R->Severity = MakeShared<FString>((*Obj)->GetStringField(TEXT("severity")));
					R->MatchStr = MakeShared<FString>(
						(*Obj)->HasField(TEXT("function_name")) ? (*Obj)->GetStringField(TEXT("function_name")) :
						(*Obj)->GetStringField(TEXT("node_class_contains")));
					R->MaxCount = MakeShared<int32>((*Obj)->HasField(TEXT("max_count")) ? (*Obj)->GetIntegerField(TEXT("max_count")) : 3);
					bool bAnim = false; (*Obj)->TryGetBoolField(TEXT("animBP_only"), bAnim);
					R->bAnimBPOnly = MakeShared<bool>(bAnim);
					Rules.Add(R);
				}
			}
		}
	}

	TSharedPtr<bool> bSaved = MakeShared<bool>(false);

	TSharedRef<SWindow> Win = SNew(SWindow)
		.Title(LOCTEXT("RulesEdTitle", "BP Doctor — Custom Rules Editor"))
		.ClientSize(FVector2D(700, 520))
		.SupportsMaximize(false).SupportsMinimize(false).IsTopmostWindow(true);
	TWeakPtr<SWindow> WW(Win);

	TSharedRef<SScrollBox> RulesList = SNew(SScrollBox);

	// Use shared ptr so lambda captures are safe even if stack unwinds
	TSharedRef<TArray<TSharedPtr<FEditableRule>>> RulesRef = MakeShared<TArray<TSharedPtr<FEditableRule>>>(Rules);
	auto RebuildList = [RulesList, RulesRef]()
	{
		RulesList->ClearChildren();
		for (int32 i = 0; i < RulesRef->Num(); ++i)
		{
			TSharedPtr<FEditableRule> R = (*RulesRef)[i];
			RulesList->AddSlot().Padding(4, 4)
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
				.Padding(8)
				[
					SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight()
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)
						[ SNew(STextBlock).Text(FText::FromString(*R->Code)).Font(FCoreStyle::GetDefaultFontStyle("Bold", 11)).ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f)) ]
						+ SHorizontalBox::Slot().FillWidth(1.f)
						[ SNew(STextBlock).Text(FText::FromString(*R->Name)).Font(FCoreStyle::GetDefaultFontStyle("Regular", 10)) ]
						+ SHorizontalBox::Slot().AutoWidth()
						[ SNew(STextBlock).Text(FText::FromString(*R->Severity)).Font(FCoreStyle::GetDefaultFontStyle("Bold", 9)) ]
					]
					+ SVerticalBox::Slot().AutoHeight().Padding(0,4,0,0)
					[ SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("Type: %s  |  Match: %s"), **R->Type, **R->MatchStr)))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9)).ColorAndOpacity(FLinearColor(0.5f,0.5f,0.6f)) ]
				]
			];
		}
	};
	RebuildList();

	// Type options for dropdown
	TArray<TSharedPtr<FString>> TypeOptions;
	TypeOptions.Add(MakeShared<FString>(TEXT("banned_function")));
	TypeOptions.Add(MakeShared<FString>(TEXT("banned_node")));
	TypeOptions.Add(MakeShared<FString>(TEXT("required_node")));
	TypeOptions.Add(MakeShared<FString>(TEXT("node_limit")));

	TArray<TSharedPtr<FString>> SevOptions;
	SevOptions.Add(MakeShared<FString>(TEXT("ERROR")));
	SevOptions.Add(MakeShared<FString>(TEXT("WARNING")));
	SevOptions.Add(MakeShared<FString>(TEXT("INFO")));

	// New rule form fields
	TSharedPtr<FString> NewName = MakeShared<FString>(TEXT("My Custom Check"));
	TSharedPtr<FString> NewCode = MakeShared<FString>(TEXT("CUSTOM_NEW"));
	TSharedPtr<FString> NewDesc = MakeShared<FString>(TEXT("Description of what this check finds."));
	TSharedPtr<FString> NewType = MakeShared<FString>(TEXT("banned_function"));
	TSharedPtr<FString> NewSev = MakeShared<FString>(TEXT("WARNING"));
	TSharedPtr<FString> NewMatch = MakeShared<FString>(TEXT("FunctionName"));
	TSharedPtr<int32> NewMax = MakeShared<int32>(3);

	Win->SetContent(
		SNew(SBorder).BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder")).Padding(16)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot().AutoHeight().Padding(0,0,0,8)
			[ SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("%d custom rules loaded. Edit below or add new ones."), RulesRef->Num())))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10)) ]

			// Current rules list
			+ SVerticalBox::Slot().FillHeight(0.4f).Padding(0,0,0,4)
			[ RulesList ]

			+ SVerticalBox::Slot().AutoHeight().Padding(0,4)
			[
				SNew(SButton).Text(LOCTEXT("DeleteLast", "Delete Last Rule"))
				.OnClicked_Lambda([RulesRef, RebuildList]() {
					if (RulesRef->Num() > 0) { RulesRef->RemoveAt(RulesRef->Num()-1); RebuildList(); }
					return FReply::Handled();
				})
			]

			+ SVerticalBox::Slot().AutoHeight().Padding(0,8) [ SNew(SSeparator) ]

			// ── ADD NEW RULE form ──
			+ SVerticalBox::Slot().AutoHeight().Padding(0,4,0,4)
			[ SNew(STextBlock).Text(LOCTEXT("AddNewLabel", "ADD NEW RULE")).Font(FCoreStyle::GetDefaultFontStyle("Bold", 11)).ColorAndOpacity(FLinearColor(0.f, 0.898f, 1.f)) ]

			+ SVerticalBox::Slot().AutoHeight().Padding(0,2)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().FillWidth(0.5f).Padding(0,0,4,0)
				[ SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleName","Name:")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
					+ SVerticalBox::Slot().AutoHeight() [ SNew(SEditableTextBox).Text(FText::FromString(*NewName)).OnTextChanged_Lambda([NewName](const FText& T){ *NewName = T.ToString(); }) ]
				]
				+ SHorizontalBox::Slot().FillWidth(0.5f)
				[ SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleCode","Code:")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
					+ SVerticalBox::Slot().AutoHeight() [ SNew(SEditableTextBox).Text(FText::FromString(*NewCode)).OnTextChanged_Lambda([NewCode](const FText& T){ *NewCode = T.ToString(); }) ]
				]
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0,2)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().FillWidth(0.33f).Padding(0,0,4,0)
				[ SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleType","Type:")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextComboBox).OptionsSource(&TypeOptions).InitiallySelectedItem(TypeOptions[0])
						.OnSelectionChanged_Lambda([NewType](TSharedPtr<FString> V, ESelectInfo::Type){ if(V.IsValid()) *NewType = *V; }) ]
				]
				+ SHorizontalBox::Slot().FillWidth(0.33f).Padding(0,0,4,0)
				[ SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleSev","Severity:")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextComboBox).OptionsSource(&SevOptions).InitiallySelectedItem(SevOptions[1])
						.OnSelectionChanged_Lambda([NewSev](TSharedPtr<FString> V, ESelectInfo::Type){ if(V.IsValid()) *NewSev = *V; }) ]
				]
				+ SHorizontalBox::Slot().FillWidth(0.33f)
				[ SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleMatch","Match (function/node name):")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
					+ SVerticalBox::Slot().AutoHeight() [ SNew(SEditableTextBox).Text(FText::FromString(*NewMatch)).OnTextChanged_Lambda([NewMatch](const FText& T){ *NewMatch = T.ToString(); }) ]
				]
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(0,2)
			[ SNew(SVerticalBox)
				+ SVerticalBox::Slot().AutoHeight() [ SNew(STextBlock).Text(LOCTEXT("RuleDesc","Description:")).Font(FCoreStyle::GetDefaultFontStyle("Regular",9)) ]
				+ SVerticalBox::Slot().AutoHeight() [ SNew(SEditableTextBox).Text(FText::FromString(*NewDesc)).OnTextChanged_Lambda([NewDesc](const FText& T){ *NewDesc = T.ToString(); }) ]
			]

			+ SVerticalBox::Slot().AutoHeight().Padding(0,8,0,0)
			[
				SNew(SButton).Text(LOCTEXT("AddRuleBtn", "Add Rule"))
				.OnClicked_Lambda([RulesRef, RebuildList, NewName, NewCode, NewDesc, NewType, NewSev, NewMatch, NewMax]() {
					auto& Rules = *RulesRef; // Alias for readability
					TSharedPtr<FEditableRule> R = MakeShared<FEditableRule>();
					R->Name = MakeShared<FString>(*NewName);
					R->Code = MakeShared<FString>(*NewCode);
					R->Description = MakeShared<FString>(*NewDesc);
					R->Type = MakeShared<FString>(*NewType);
					R->Severity = MakeShared<FString>(*NewSev);
					R->MatchStr = MakeShared<FString>(*NewMatch);
					R->MaxCount = MakeShared<int32>(*NewMax);
					R->bAnimBPOnly = MakeShared<bool>(false);
					Rules.Add(R);
					RebuildList();
					return FReply::Handled();
				})
			]

			+ SVerticalBox::Slot().AutoHeight().Padding(0,12,0,0)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)
				[ SNew(SButton).Text(LOCTEXT("SaveRules", "Save & Close"))
					.OnClicked_Lambda([bSaved, WW]() { *bSaved = true; if(auto P=WW.Pin()) P->RequestDestroyWindow(); return FReply::Handled(); }) ]
				+ SHorizontalBox::Slot().FillWidth(1.f) [ SNew(SSpacer) ]
				+ SHorizontalBox::Slot().AutoWidth()
				[ SNew(SButton).Text(LOCTEXT("CancelRules", "Cancel"))
					.OnClicked_Lambda([WW]() { if(auto P=WW.Pin()) P->RequestDestroyWindow(); return FReply::Handled(); }) ]
			]
		]
	);

	FSlateApplication::Get().AddModalWindow(Win, TSharedPtr<const SWidget>());

	if (!*bSaved) return;

	// Serialize rules back to JSON
	TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
	TArray<TSharedPtr<FJsonValue>> Arr;
	for (const auto& R : *RulesRef)
	{
		TSharedRef<FJsonObject> Obj = MakeShared<FJsonObject>();
		Obj->SetStringField(TEXT("name"), *R->Name);
		Obj->SetStringField(TEXT("code"), *R->Code);
		Obj->SetStringField(TEXT("description"), *R->Description);
		Obj->SetStringField(TEXT("severity"), *R->Severity);
		Obj->SetStringField(TEXT("confidence"), TEXT("HIGH"));
		Obj->SetStringField(TEXT("why_it_matters"), TEXT(""));
		Obj->SetStringField(TEXT("beginner_tip"), TEXT(""));
		Obj->SetStringField(TEXT("type"), *R->Type);
		if (*R->Type == TEXT("banned_function"))
			Obj->SetStringField(TEXT("function_name"), *R->MatchStr);
		else
			Obj->SetStringField(TEXT("node_class_contains"), *R->MatchStr);
		if (*R->Type == TEXT("node_limit"))
			Obj->SetNumberField(TEXT("max_count"), *R->MaxCount);
		if (*R->bAnimBPOnly)
			Obj->SetBoolField(TEXT("animBP_only"), true);
		Arr.Add(MakeShared<FJsonValueObject>(Obj));
	}
	Root->SetArrayField(TEXT("rules"), Arr);

	FString Out;
	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(&Out);
	FJsonSerializer::Serialize(Root, Writer);

	FString Dir = FPaths::GetPath(RulesPath);
	IFileManager::Get().MakeDirectory(*Dir, true);
	FFileHelper::SaveStringToFile(Out, *RulesPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

void SBPDoctorPanel::ImportCustomRules()
{
	TArray<FString> Files;
	IDesktopPlatform* DP = FDesktopPlatformModule::Get();
	if (!DP) return;
	DP->OpenFileDialog(
		FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
		TEXT("Import Custom Rules"), FPaths::ProjectDir(),
		TEXT(""), TEXT("JSON (*.json)|*.json"), 0, Files);
	if (Files.Num() == 0) return;

	FString DestPath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("CustomRules.json");
	FString Dir = FPaths::GetPath(DestPath);
	IFileManager::Get().MakeDirectory(*Dir, true);
	IFileManager::Get().Copy(*DestPath, *Files[0], true);
	FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(
		TEXT("Custom rules imported to:\n%s\n\nRe-scan to apply new rules."), *DestPath)));
}

void SBPDoctorPanel::ExportSettings()
{
	// Save current settings first
	SaveSettings();

	TArray<FString> Files;
	IDesktopPlatform* DP = FDesktopPlatformModule::Get();
	if (!DP) return;
	DP->SaveFileDialog(
		FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
		TEXT("Export BP Doctor Settings"), FPaths::ProjectDir(),
		TEXT("BPDoctor_Settings.json"), TEXT("JSON (*.json)|*.json"), 0, Files);
	if (Files.Num() == 0) return;

	FString SourcePath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("Settings.json");
	IFileManager::Get().Copy(*Files[0], *SourcePath, true);
}

void SBPDoctorPanel::ImportSettings()
{
	TArray<FString> Files;
	IDesktopPlatform* DP = FDesktopPlatformModule::Get();
	if (!DP) return;
	DP->OpenFileDialog(
		FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
		TEXT("Import BP Doctor Settings"), FPaths::ProjectDir(),
		TEXT(""), TEXT("JSON (*.json)|*.json"), 0, Files);
	if (Files.Num() == 0) return;

	FString DestPath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("Settings.json");
	FString Dir = FPaths::GetPath(DestPath);
	IFileManager::Get().MakeDirectory(*Dir, true);
	IFileManager::Get().Copy(*DestPath, *Files[0], true);
	LoadSettings();
	FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("ImportedSettings", "Settings imported successfully. Changes applied."));
}

void SBPDoctorPanel::ShowChecksDialog()
{
	const TArray<FBPDoctorCheckDef>& AllDefs = FBPDoctorChecks::GetAllChecks();

	// Track enabled state per check (shared pointers for lambda capture)
	TArray<TSharedPtr<bool>> EnabledStates;
	for (const FBPDoctorCheckDef& Def : AllDefs)
	{
		EnabledStates.Add(MakeShared<bool>(!DisabledChecks.Contains(Def.Code)));
	}

	TSharedRef<SWindow> DialogWindow = SNew(SWindow)
		.Title(LOCTEXT("ChecksTitle", "BP Doctor — Check Library (26 Checks)"))
		.ClientSize(FVector2D(750, 560))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.IsTopmostWindow(true);

	TWeakPtr<SWindow> WeakWindow(DialogWindow);
	TSharedPtr<bool> bSaved = MakeShared<bool>(false);

	// Build scrollable check list
	TSharedRef<SScrollBox> CheckList = SNew(SScrollBox);

	for (int32 i = 0; i < AllDefs.Num(); ++i)
	{
		const FBPDoctorCheckDef& Def = AllDefs[i];
		TSharedPtr<bool> bEnabled = EnabledStates[i];

		FString SevStr = (Def.Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
			(Def.Severity == EBPDoctorSeverity::Warning) ? TEXT("WARN") : TEXT("INFO");
		FLinearColor SevColor = (Def.Severity == EBPDoctorSeverity::Error)
			? FLinearColor(1.f, 0.09f, 0.27f)
			: (Def.Severity == EBPDoctorSeverity::Warning)
				? FLinearColor(1.f, 0.843f, 0.251f) : FLinearColor(0.f, 0.898f, 1.f);
		FString ConfStr = (Def.Confidence == EBPDoctorConfidence::High) ? TEXT("HIGH") :
			(Def.Confidence == EBPDoctorConfidence::Medium) ? TEXT("MED") : TEXT("LOW");
		FString TypeStr = (Def.Id <= 12) ? TEXT("AnimBP") : TEXT("BP");
		FString FixStr = Def.bAutoFixable ? TEXT("Yes") : TEXT("No");

		CheckList->AddSlot()
		.Padding(4, 3)
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([bEnabled]() { return *bEnabled ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([bEnabled](ECheckBoxState S) { *bEnabled = (S == ECheckBoxState::Checked); })
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot().AutoHeight()
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
					[
						SNew(STextBlock)
						.Text(FText::FromString(FString::Printf(TEXT("#%d %s"), Def.Id, *Def.Code)))
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
						.ColorAndOpacity(SevColor)
					]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
					[
						SNew(STextBlock)
						.Text(FText::FromString(Def.Name))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
					]
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 2, 0, 0)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 12, 0)
					[ SNew(STextBlock).Text(FText::FromString(SevStr))
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 8)).ColorAndOpacity(SevColor) ]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 12, 0)
					[ SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("Conf: %s"), *ConfStr)))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8)) ]
					+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 12, 0)
					[ SNew(STextBlock).Text(FText::FromString(TypeStr))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8)) ]
					+ SHorizontalBox::Slot().AutoWidth()
					[ SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("Fix: %s"), *FixStr)))
						.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8)) ]
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0, 2, 0, 0)
				[
					SNew(STextBlock)
					.Text(FText::FromString(Def.Description))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
					.ColorAndOpacity(FLinearColor(0.6f, 0.6f, 0.7f))
					.AutoWrapText(true)
				]
			]
		];
	}

	DialogWindow->SetContent(
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
		.Padding(16)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot().AutoHeight().Padding(0, 0, 0, 8)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().FillWidth(1.f)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("ChecksHeader", "Enable or disable checks. Disabled checks are skipped during scan."))
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
					.AutoWrapText(true)
				]
				+ SHorizontalBox::Slot().AutoWidth().Padding(8, 0, 4, 0)
				[
					SNew(SButton).Text(LOCTEXT("EnableAll", "Enable All"))
					.OnClicked_Lambda([EnabledStates]() {
						for (auto& S : EnabledStates) *S = true;
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton).Text(LOCTEXT("DisableAll", "Disable All"))
					.OnClicked_Lambda([EnabledStates]() {
						for (auto& S : EnabledStates) *S = false;
						return FReply::Handled();
					})
				]
			]

			+ SVerticalBox::Slot().AutoHeight().Padding(0, 4)
			[ SNew(SSeparator) ]

			+ SVerticalBox::Slot().FillHeight(1.f).Padding(0, 4)
			[ CheckList ]

			+ SVerticalBox::Slot().AutoHeight().Padding(0, 8, 0, 0)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(0, 0, 8, 0)
				[
					SNew(SButton).Text(LOCTEXT("SaveChecks", "Save"))
					.ToolTipText(LOCTEXT("SaveChecksTip", "Save check settings and close"))
					.OnClicked_Lambda([bSaved, WeakWindow]() {
						*bSaved = true;
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot().FillWidth(1.f) [ SNew(SSpacer) ]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton).Text(LOCTEXT("CancelChecks", "Cancel"))
					.OnClicked_Lambda([WeakWindow]() {
						if (auto Pin = WeakWindow.Pin()) Pin->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		]
	);

	FSlateApplication::Get().AddModalWindow(DialogWindow, TSharedPtr<const SWidget>());

	if (*bSaved)
	{
		DisabledChecks.Empty();
		for (int32 i = 0; i < AllDefs.Num(); ++i)
		{
			if (!*EnabledStates[i])
			{
				DisabledChecks.Add(AllDefs[i].Code);
			}
		}
		SaveSettings();
	}
}

// ─────────────────────────────────────────────────────────────────
//  HTML REPORT EXPORT
// ─────────────────────────────────────────────────────────────────

static FString HtmlEscape(const FString& In)
{
	FString Out = In;
	Out.ReplaceInline(TEXT("&"), TEXT("&amp;"));
	Out.ReplaceInline(TEXT("<"), TEXT("&lt;"));
	Out.ReplaceInline(TEXT(">"), TEXT("&gt;"));
	Out.ReplaceInline(TEXT("\""), TEXT("&quot;"));
	return Out;
}

FReply SBPDoctorPanel::OnExportHTMLReport()
{
	FString H;
	H += TEXT("<!DOCTYPE html>\n<html><head>\n<meta charset=\"utf-8\">\n");
	H += TEXT("<title>BP Doctor Scan Report</title>\n<style>\n");
	H += TEXT("body{background:#0d1117;color:#c9d1d9;font-family:'Segoe UI',sans-serif;margin:40px}\n");
	H += TEXT("h1{color:#00e5ff}h2{color:#88aacc;border-bottom:1px solid #333;padding-bottom:4px}\n");
	H += TEXT(".grade{font-size:48px;font-weight:bold}\n");
	H += TEXT(".ga{color:#00e676}.gb{color:#ffd740}.gc{color:#ff9100}.gd,.gf{color:#ff1744}\n");
	H += TEXT("table{width:100%;border-collapse:collapse;margin:16px 0}\n");
	H += TEXT("th{background:#161b22;padding:8px;text-align:left;border-bottom:2px solid #333}\n");
	H += TEXT("td{padding:6px 8px;border-bottom:1px solid #222}\n");
	H += TEXT(".err{color:#ff1744}.wrn{color:#ffd740}.inf{color:#00e5ff}\n");
	H += TEXT(".hi{color:#00e676}.med{color:#ffd740}.lo{color:#ff9100}\n");
	H += TEXT(".fx{color:#00e676;font-weight:bold}\n");
	H += TEXT("</style>\n</head><body>\n");

	H += TEXT("<h1>BP Doctor Scan Report</h1>\n");
	H += FString::Printf(TEXT("<p>Generated: %s</p>\n"), *FDateTime::Now().ToString());

	FString GC = HealthGrade.StartsWith(TEXT("A")) ? TEXT("ga") :
		HealthGrade.StartsWith(TEXT("B")) ? TEXT("gb") :
		HealthGrade == TEXT("C") ? TEXT("gc") : TEXT("gd");
	H += FString::Printf(TEXT("<div class=\"grade %s\">%s</div>\n"), *GC, *HealthGrade);
	H += FString::Printf(TEXT("<p>Scanned: %d | Errors: %d | Warnings: %d | Info: %d | Auto-fixable: %d</p>\n"),
		TotalScanned, TotalErrors, TotalWarnings, TotalInfos, TotalAutoFixable);

	H += TEXT("<table><tr><th>Sev</th><th>Conf</th><th>Check</th><th>Type</th><th>Asset</th><th>Description</th><th>Fix</th></tr>\n");

	for (const FBPDoctorAssetInfo& Info : AllResults)
	{
		for (const FBPDoctorResult& Issue : Info.Issues)
		{
			FString SC = (Issue.Severity == EBPDoctorSeverity::Error) ? TEXT("err") :
				(Issue.Severity == EBPDoctorSeverity::Warning) ? TEXT("wrn") : TEXT("inf");
			FString ST = (Issue.Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
				(Issue.Severity == EBPDoctorSeverity::Warning) ? TEXT("WARN") : TEXT("INFO");

			const FBPDoctorCheckDef* CD = FBPDoctorChecks::FindCheck(Issue.CheckCode);
			FString CC = TEXT("med"); FString CT = TEXT("MED");
			if (CD)
			{
				if (CD->Confidence == EBPDoctorConfidence::High) { CC = TEXT("hi"); CT = TEXT("HIGH"); }
				else if (CD->Confidence == EBPDoctorConfidence::Low) { CC = TEXT("lo"); CT = TEXT("LOW"); }
			}
			FString TT = (Issue.AssetType == EBPDoctorAssetType::AnimBP) ? TEXT("AnimBP") : TEXT("BP");
			FString FT = Issue.bFixed ? TEXT("<span class=\"fx\">FIXED</span>") :
				(Issue.bAutoFixable ? TEXT("Yes") : TEXT("-"));

			H += FString::Printf(TEXT("<tr><td class=\"%s\">%s</td><td class=\"%s\">%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n"),
				*SC, *ST, *CC, *CT, *HtmlEscape(Issue.CheckCode), *TT, *HtmlEscape(Issue.AssetName), *HtmlEscape(Issue.Description), *FT);
		}
	}
	H += TEXT("</table>\n");

	// Per-asset detail with why-it-matters
	for (const FBPDoctorAssetInfo& Info : AllResults)
	{
		if (Info.Issues.Num() == 0) continue;
		H += FString::Printf(TEXT("<h2>%s [%s]</h2>\n"), *Info.Name, *Info.Grade);
		for (const FBPDoctorResult& Issue : Info.Issues)
		{
			FString SC = (Issue.Severity == EBPDoctorSeverity::Error) ? TEXT("err") :
				(Issue.Severity == EBPDoctorSeverity::Warning) ? TEXT("wrn") : TEXT("inf");
			H += FString::Printf(TEXT("<p><span class=\"%s\"><b>%s</b></span> %s</p>\n"),
				*SC, *Issue.CheckCode, *Issue.Description);
			if (!Issue.NodeHint.IsEmpty())
				H += FString::Printf(TEXT("<p style=\"color:#666;margin-left:20px\">%s</p>\n"), *Issue.NodeHint);

			const FBPDoctorCheckDef* CD = FBPDoctorChecks::FindCheck(Issue.CheckCode);
			if (CD && !CD->WhyItMatters.IsEmpty())
				H += FString::Printf(TEXT("<p style=\"color:#88aacc;margin-left:20px\"><i>Why: %s</i></p>\n"), *CD->WhyItMatters);
		}
	}

	H += TEXT("<hr><p style=\"color:#555\">Generated by BP Doctor — Blueprint Diagnostics &amp; Auto-Fix</p>\n");
	H += TEXT("</body></html>\n");

	TArray<FString> OutFiles;
	IDesktopPlatform* DP = FDesktopPlatformModule::Get();
	if (DP)
	{
		DP->SaveFileDialog(
			FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
			TEXT("Export HTML Report"), FPaths::ProjectDir(),
			TEXT("BPDoctor_Report.html"), TEXT("HTML (*.html)|*.html"),
			0, OutFiles);
		if (OutFiles.Num() > 0)
			FFileHelper::SaveStringToFile(H, *OutFiles[0], FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
	}
	return FReply::Handled();
}

// ─────────────────────────────────────────────────────────────────
//  SETTINGS PERSISTENCE
// ─────────────────────────────────────────────────────────────────

void SBPDoctorPanel::SaveSettings()
{
	TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();

	TArray<TSharedPtr<FJsonValue>> DisArr;
	for (const FString& Code : DisabledChecks)
		DisArr.Add(MakeShared<FJsonValueString>(Code));
	Root->SetArrayField(TEXT("disabled_checks"), DisArr);

	FString ModeStr = (ExperienceMode == EBPDoctorExperienceMode::Beginner) ? TEXT("beginner") :
		(ExperienceMode == EBPDoctorExperienceMode::Expert) ? TEXT("expert") : TEXT("intermediate");
	Root->SetStringField(TEXT("experience_mode"), ModeStr);

	TArray<TSharedPtr<FJsonValue>> SupArr;
	for (const FString& Key : SuppressedIssueKeys)
		SupArr.Add(MakeShared<FJsonValueString>(Key));
	Root->SetArrayField(TEXT("suppressed_issues"), SupArr);

	FString OutputString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(Root, Writer);

	FString SettingsDir = FPaths::ProjectSavedDir() / TEXT("BPDoctor");
	IFileManager::Get().MakeDirectory(*SettingsDir, true);
	FFileHelper::SaveStringToFile(OutputString, *(SettingsDir / TEXT("Settings.json")));
}

void SBPDoctorPanel::LoadSettings()
{
	FString SettingsPath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("Settings.json");
	FString JsonString;
	if (!FFileHelper::LoadFileToString(JsonString, *SettingsPath)) return;

	TSharedPtr<FJsonObject> Root;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
	if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid()) return;

	DisabledChecks.Empty();
	const TArray<TSharedPtr<FJsonValue>>* DisArr;
	if (Root->TryGetArrayField(TEXT("disabled_checks"), DisArr))
	{
		for (const auto& V : *DisArr)
			DisabledChecks.Add(V->AsString());
	}

	FString ModeStr;
	if (Root->TryGetStringField(TEXT("experience_mode"), ModeStr))
	{
		if (ModeStr == TEXT("beginner")) ExperienceMode = EBPDoctorExperienceMode::Beginner;
		else if (ModeStr == TEXT("expert")) ExperienceMode = EBPDoctorExperienceMode::Expert;
		else ExperienceMode = EBPDoctorExperienceMode::Intermediate;
	}

	SuppressedIssueKeys.Empty();
	const TArray<TSharedPtr<FJsonValue>>* SupArr;
	if (Root->TryGetArrayField(TEXT("suppressed_issues"), SupArr))
	{
		for (const auto& V : *SupArr)
			SuppressedIssueKeys.Add(V->AsString());
	}
}

#undef LOCTEXT_NAMESPACE
