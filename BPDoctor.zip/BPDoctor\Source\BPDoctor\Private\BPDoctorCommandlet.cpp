// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#include "BPDoctorCommandlet.h"
#include "BPDoctorChecks.h"
#include "BPDoctorTypes.h"

#include "Engine/Blueprint.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Serialization/JsonSerializer.h"

DEFINE_LOG_CATEGORY_STATIC(LogBPDoctor, Log, All);

UBPDoctorCommandlet::UBPDoctorCommandlet()
{
	IsClient = false;
	IsEditor = true;
	IsServer = false;
	LogToConsole = true;
}

int32 UBPDoctorCommandlet::Main(const FString& Params)
{
	UE_LOG(LogBPDoctor, Display, TEXT(""));
	UE_LOG(LogBPDoctor, Display, TEXT("========================================"));
	UE_LOG(LogBPDoctor, Display, TEXT("  BP Doctor — Blueprint Diagnostics"));
	UE_LOG(LogBPDoctor, Display, TEXT("========================================"));

	// Parse command line
	FString OutputPath, FormatStr, SeverityStr, FailOnStr;
	FParse::Value(*Params, TEXT("-output="), OutputPath);
	FParse::Value(*Params, TEXT("-format="), FormatStr);
	FParse::Value(*Params, TEXT("-severity="), SeverityStr);
	FParse::Value(*Params, TEXT("-fail-on="), FailOnStr);

	if (FormatStr.IsEmpty()) FormatStr = TEXT("text");
	if (SeverityStr.IsEmpty()) SeverityStr = TEXT("info");
	if (FailOnStr.IsEmpty()) FailOnStr = TEXT("error");

	// Severity mapping
	auto ParseSeverity = [](const FString& Str) -> EBPDoctorSeverity
	{
		if (Str == TEXT("error")) return EBPDoctorSeverity::Error;
		if (Str == TEXT("warning")) return EBPDoctorSeverity::Warning;
		return EBPDoctorSeverity::Info;
	};

	EBPDoctorSeverity MinSeverity = ParseSeverity(SeverityStr.ToLower());
	EBPDoctorSeverity FailSeverity = ParseSeverity(FailOnStr.ToLower());

	// Discover all Blueprint assets
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();
	AssetRegistry.SearchAllAssets(true);

	FARFilter Filter;
	Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add(TEXT("/Game"));
	Filter.bRecursivePaths = true;

	TArray<FAssetData> BlueprintAssets;
	AssetRegistry.GetAssets(Filter, BlueprintAssets);

	UE_LOG(LogBPDoctor, Display, TEXT("Found %d Blueprint assets in /Game"), BlueprintAssets.Num());

	// Scan each Blueprint
	TArray<FBPDoctorResult> AllResults;
	int32 Scanned = 0;
	int32 Errors = 0, Warnings = 0, Infos = 0;

	for (const FAssetData& AssetData : BlueprintAssets)
	{
		UBlueprint* BP = Cast<UBlueprint>(AssetData.GetAsset());
		if (!BP) continue;

		Scanned++;

		TArray<FBPDoctorResult> Results = FBPDoctorChecks::RunChecks(BP);
		Results.Append(FBPDoctorChecks::RunCustomRules(BP));

		for (const FBPDoctorResult& R : Results)
		{
			// Filter: include this severity and more severe (Error=0 < Warning=1 < Info=2)
			// Skip anything LESS severe than the minimum (higher enum value = less severe)
			if (static_cast<int32>(R.Severity) > static_cast<int32>(MinSeverity))
				continue;

			AllResults.Add(R);

			switch (R.Severity)
			{
				case EBPDoctorSeverity::Error:   Errors++;   break;
				case EBPDoctorSeverity::Warning: Warnings++; break;
				case EBPDoctorSeverity::Info:    Infos++;    break;
			}
		}

		if (Scanned % 50 == 0)
		{
			UE_LOG(LogBPDoctor, Display, TEXT("  Scanned %d / %d ..."), Scanned, BlueprintAssets.Num());
		}
	}

	// Generate report
	FString Report;
	if (FormatStr.ToLower() == TEXT("json"))
	{
		Report = GenerateJSONReport(AllResults, Scanned);
	}
	else
	{
		Report = GenerateTextReport(AllResults, Scanned);
	}

	// Output
	if (OutputPath.IsEmpty())
	{
		UE_LOG(LogBPDoctor, Display, TEXT("\n%s"), *Report);
	}
	else
	{
		FFileHelper::SaveStringToFile(Report, *OutputPath,
			FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
		UE_LOG(LogBPDoctor, Display, TEXT("Report written to: %s"), *OutputPath);
	}

	// Summary
	UE_LOG(LogBPDoctor, Display, TEXT(""));
	UE_LOG(LogBPDoctor, Display, TEXT("SUMMARY: Scanned %d BPs | Errors: %d | Warnings: %d | Info: %d"),
		Scanned, Errors, Warnings, Infos);

	// Exit code
	int32 FailCount = 0;
	for (const FBPDoctorResult& R : AllResults)
	{
		if (static_cast<int32>(R.Severity) <= static_cast<int32>(FailSeverity))
			FailCount++;
	}

	if (FailCount > 0)
	{
		UE_LOG(LogBPDoctor, Warning, TEXT("FAIL: %d issues at '%s' severity or above"),
			FailCount, *FailOnStr);
		return 1;
	}

	UE_LOG(LogBPDoctor, Display, TEXT("PASS: No issues at '%s' severity or above"), *FailOnStr);
	return 0;
}

FString UBPDoctorCommandlet::GenerateTextReport(const TArray<FBPDoctorResult>& Results, int32 TotalScanned) const
{
	FString Out;
	Out += TEXT("BP Doctor Scan Report\n");
	Out += FString::Printf(TEXT("Generated: %s\n"), *FDateTime::Now().ToString());
	Out += FString::Printf(TEXT("Scanned: %d Blueprints\n"), TotalScanned);
	Out += TEXT("=============================================\n\n");

	for (const FBPDoctorResult& R : Results)
	{
		FString SevStr = (R.Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
			(R.Severity == EBPDoctorSeverity::Warning) ? TEXT("WARN") : TEXT("INFO");
		Out += FString::Printf(TEXT("[%s] %s — %s: %s\n"), *SevStr, *R.CheckCode, *R.AssetName, *R.Description);
		if (!R.NodeHint.IsEmpty())
			Out += FString::Printf(TEXT("  > %s\n"), *R.NodeHint);
	}

	return Out;
}

FString UBPDoctorCommandlet::GenerateJSONReport(const TArray<FBPDoctorResult>& Results, int32 TotalScanned) const
{
	TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
	Root->SetStringField(TEXT("scan_date"), FDateTime::Now().ToString());
	Root->SetNumberField(TEXT("total_scanned"), TotalScanned);
	Root->SetNumberField(TEXT("total_issues"), Results.Num());

	int32 E = 0, W = 0, I = 0;
	TArray<TSharedPtr<FJsonValue>> IssueArray;

	for (const FBPDoctorResult& R : Results)
	{
		switch (R.Severity)
		{
			case EBPDoctorSeverity::Error: E++; break;
			case EBPDoctorSeverity::Warning: W++; break;
			case EBPDoctorSeverity::Info: I++; break;
		}

		TSharedRef<FJsonObject> Issue = MakeShared<FJsonObject>();
		Issue->SetStringField(TEXT("check_code"), R.CheckCode);
		Issue->SetStringField(TEXT("severity"),
			(R.Severity == EBPDoctorSeverity::Error) ? TEXT("ERROR") :
			(R.Severity == EBPDoctorSeverity::Warning) ? TEXT("WARNING") : TEXT("INFO"));
		Issue->SetStringField(TEXT("asset_name"), R.AssetName);
		Issue->SetStringField(TEXT("asset_path"), R.AssetPath);
		Issue->SetStringField(TEXT("description"), R.Description);
		if (!R.NodeHint.IsEmpty())
			Issue->SetStringField(TEXT("node_hint"), R.NodeHint);
		Issue->SetBoolField(TEXT("auto_fixable"), R.bAutoFixable);

		IssueArray.Add(MakeShared<FJsonValueObject>(Issue));
	}

	Root->SetNumberField(TEXT("errors"), E);
	Root->SetNumberField(TEXT("warnings"), W);
	Root->SetNumberField(TEXT("info"), I);
	Root->SetArrayField(TEXT("issues"), IssueArray);

	FString OutputString;
	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(&OutputString);
	FJsonSerializer::Serialize(Root, Writer);

	return OutputString;
}
