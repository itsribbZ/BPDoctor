// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

using UnrealBuildTool;

public class BPDoctor : ModuleRules
{
	public BPDoctor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"CoreUObject",
			"Engine",
			"Slate",
			"SlateCore",
			"UnrealEd",
			"InputCore",
			"ToolMenus",
			"Projects",
			"AnimGraph",
			"AnimGraphRuntime",
			"BlueprintGraph",
			"AssetRegistry",
			"DesktopPlatform",
			"Json",
			"ApplicationCore",
			"WorkspaceMenuStructure",
			"EditorFramework",
		});
	}
}
