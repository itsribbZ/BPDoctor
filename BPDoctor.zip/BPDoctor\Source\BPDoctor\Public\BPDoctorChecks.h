// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "BPDoctorTypes.h"

class UBlueprint;
class UAnimBlueprint;

/**
 * BP Doctor Check Registry.
 * Contains all 26 diagnostic check definitions and their handler functions.
 * 12 AnimBP-specific + 14 General Blueprint checks.
 */
class FBPDoctorChecks
{
public:
	/** Get all check definitions. */
	static const TArray<FBPDoctorCheckDef>& GetAllChecks();

	/** Get a check definition by code. */
	static const FBPDoctorCheckDef* FindCheck(const FString& Code);

	/** Run all applicable checks on a Blueprint asset. Returns results. */
	static TArray<FBPDoctorResult> RunChecks(UBlueprint* Blueprint);

	/** Run a single check by code. */
	static TArray<FBPDoctorResult> RunCheck(const FString& CheckCode, UBlueprint* Blueprint);

	/** Run custom rules against a Blueprint. */
	static TArray<FBPDoctorResult> RunCustomRules(UBlueprint* Blueprint);

	/** Set which checks are disabled (skipped during scanning). */
	static void SetDisabledChecks(const TSet<FString>& Codes);

	/** Force reload of custom rules from disk on next GetAllChecks(). */
	static void RefreshCustomRules();

private:
	// ── AnimBP Checks (1-12) ──
	static TArray<FBPDoctorResult> CheckNullAnimRef(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckBrokenBlendWeight(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckSkeletonMismatch(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckMissingSlot(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckBrokenTransition(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckTPoseFallback(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckOrphanedNode(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckInvalidBlendSpace(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckMissingNotify(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckDuplicateSlot(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckUnusedVariable(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);
	static TArray<FBPDoctorResult> CheckDeprecatedNode(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP);

	// ── General BP Checks (13-26) ──
	static TArray<FBPDoctorResult> CheckBrokenAssetRef(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckComplexity(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckEmptyGraph(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckTickHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckSelfCast(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckDeprecatedFunc(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckCircularDep(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckMassiveAsset(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckHardRef(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckExpensiveTick(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckDebugNodes(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckConstructHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckForEachPerf(const FBPDoctorCheckDef& Check, UBlueprint* BP);
	static TArray<FBPDoctorResult> CheckTimelineHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP);

	/** Initialize the check definitions array (called once). */
	static void InitChecks();

	/** Load user-defined custom rules from Saved/BPDoctor/CustomRules.json */
	static void LoadCustomRules();

	static TArray<FBPDoctorCheckDef> AllChecks;
	static bool bInitialized;
	static bool bCustomRulesLoaded;
	static TSet<FString> DisabledCheckCodes;
};
