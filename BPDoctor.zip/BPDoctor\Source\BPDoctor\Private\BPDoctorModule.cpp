// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#include "BPDoctorModule.h"
#include "BPDoctorStyle.h"
#include "BPDoctorCommands.h"
#include "SBPDoctorPanel.h"

#include "ToolMenus.h"
#include "Widgets/Docking/SDockTab.h"
#include "Styling/AppStyle.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"

static const FName BPDoctorTabName("BPDoctorTab");

#define LOCTEXT_NAMESPACE "FBPDoctorModule"

void FBPDoctorModule::StartupModule()
{
	FBPDoctorStyle::Initialize();
	FBPDoctorStyle::ReloadTextures();
	FBPDoctorCommands::Register();

	// Register the tab spawner
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		BPDoctorTabName,
		FOnSpawnTab::CreateRaw(this, &FBPDoctorModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("TabTitle", "BP Doctor"))
		.SetTooltipText(LOCTEXT("TabTooltip", "Scan and fix Blueprint issues"))
		.SetGroup(WorkspaceMenu::GetMenuStructure().GetToolsCategory())
		.SetIcon(FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.AnimBlueprint"));

	// Register menus after ToolMenus is ready
	UToolMenus::RegisterStartupCallback(
		FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FBPDoctorModule::RegisterMenus));
}

void FBPDoctorModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);
	FBPDoctorCommands::Unregister();
	FBPDoctorStyle::Shutdown();
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(BPDoctorTabName);
}

void FBPDoctorModule::RegisterMenus()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	// Add to Window menu
	UToolMenu* WindowMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
	FToolMenuSection& Section = WindowMenu->FindOrAddSection("WindowLayout");
	Section.AddMenuEntry(
		"BPDoctor",
		LOCTEXT("MenuTitle", "BP Doctor"),
		LOCTEXT("MenuTooltip", "Open BP Doctor — scan and fix Blueprint issues"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.AnimBlueprint"),
		FUIAction(FExecuteAction::CreateLambda([]()
		{
			FGlobalTabmanager::Get()->TryInvokeTab(BPDoctorTabName);
		}))
	);

	// Add to Tools menu
	UToolMenu* ToolsMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Tools");
	FToolMenuSection& ToolsSection = ToolsMenu->FindOrAddSection("Animation");
	ToolsSection.AddMenuEntry(
		"BPDoctor",
		LOCTEXT("ToolsMenuTitle", "BP Doctor"),
		LOCTEXT("ToolsMenuTooltip", "Scan and auto-fix Blueprint issues"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.AnimBlueprint"),
		FUIAction(FExecuteAction::CreateLambda([]()
		{
			FGlobalTabmanager::Get()->TryInvokeTab(BPDoctorTabName);
		}))
	);
}

TSharedRef<SDockTab> FBPDoctorModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SBPDoctorPanel)
		];
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FBPDoctorModule, BPDoctor)
