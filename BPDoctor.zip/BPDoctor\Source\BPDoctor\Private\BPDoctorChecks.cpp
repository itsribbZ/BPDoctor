// Copyright (c) 2025-2026 BP Doctor. All rights reserved.
// All 26 diagnostic checks ported from Python binary parsing to UE5 native APIs.

#include "BPDoctorChecks.h"

#include "Animation/AnimBlueprint.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimMontage.h"
#include "Animation/BlendSpace.h"
#include "Animation/Skeleton.h"
#include "EdGraphSchema_K2.h"

#include "AnimGraphNode_Base.h"
#include "AnimGraphNode_SequencePlayer.h"
#include "AnimGraphNode_BlendSpacePlayer.h"
#include "AnimGraphNode_LayeredBoneBlend.h"
#include "AnimGraphNode_Slot.h"
#include "AnimGraphNode_StateMachine.h"
#include "AnimGraphNode_StateResult.h"
#include "AnimGraphNode_TransitionResult.h"

#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphPin.h"
#include "K2Node.h"
#include "K2Node_CallFunction.h"
#include "K2Node_DynamicCast.h"
#include "K2Node_Event.h"
#include "K2Node_Timeline.h"
#include "K2Node_MacroInstance.h"

#include "Engine/Blueprint.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "UObject/UObjectIterator.h"
#include "Misc/PackageName.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Serialization/JsonSerializer.h"

TArray<FBPDoctorCheckDef> FBPDoctorChecks::AllChecks;
bool FBPDoctorChecks::bInitialized = false;
bool FBPDoctorChecks::bCustomRulesLoaded = false;
TSet<FString> FBPDoctorChecks::DisabledCheckCodes;

// ─────────────────────────────────────────────────────────────────
//  CHECK DEFINITIONS
// ─────────────────────────────────────────────────────────────────

void FBPDoctorChecks::InitChecks()
{
	if (bInitialized) return;
	bInitialized = true;

	auto MakeCheck = [](int32 Id, const FString& Name, const FString& Code,
		EBPDoctorSeverity Sev, EBPDoctorConfidence Conf, bool bFixable,
		const FString& Desc, const FString& Why, const FString& Tip,
		const FString& Fix = FString(), const FString& Detection = FString()) -> FBPDoctorCheckDef
	{
		FBPDoctorCheckDef C;
		C.Id = Id;
		C.Name = Name;
		C.Code = Code;
		C.Severity = Sev;
		C.Confidence = Conf;
		C.bAutoFixable = bFixable;
		C.Description = Desc;
		C.WhyItMatters = Why;
		C.BeginnerTip = Tip;
		C.HowToFix = Fix;
		C.DetectionMethod = Detection;
		return C;
	};

	// AnimBP Checks (1-12)
	AllChecks.Add(MakeCheck(1, TEXT("Null Anim Reference"), TEXT("NULL_ANIM_REF"),
		EBPDoctorSeverity::Error, EBPDoctorConfidence::High, false,
		TEXT("Sequence Player node has no animation asset assigned."),
		TEXT("A Sequence Player with no animation can cause the character to snap to T-pose when that state is entered."),
		TEXT("One of your animation nodes is empty -- it has no animation assigned. This can make your character snap to a T-pose."),
		TEXT("1. Click Navigate to open the AnimBP\n2. Find the Sequence Player node with no animation\n3. In its Details panel, set the Sequence property to a valid AnimSequence\n4. Compile and save the AnimBP"),
		TEXT("Scans all AnimGraphNode_SequencePlayer nodes. Flags any where the Sequence property is null.")));

	AllChecks.Add(MakeCheck(2, TEXT("Broken Blend Weight"), TEXT("BROKEN_BLEND_WT"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, true,
		TEXT("Blend weight value is outside the valid [0.0, 1.0] range."),
		TEXT("Weights outside [0,1] produce wrong blend proportions or visual pops. Clamping behavior varies by engine version."),
		TEXT("A blend weight controls how much two animations mix together. Yours is outside the valid range."),
		TEXT("AUTO-FIX: Clamps the value to [0.0, 1.0]. Use the custom input field to set a specific value.\n\nMANUAL: Navigate to the LayeredBoneBlend node > find the BlendWeight pin > set a value between 0.0 and 1.0."),
		TEXT("Reads default pin values on LayeredBoneBlend nodes. Flags any BlendWeight pin with a value outside [0.0, 1.0].")));

	AllChecks.Add(MakeCheck(3, TEXT("Skeleton Mismatch"), TEXT("SKEL_MISMATCH"),
		EBPDoctorSeverity::Error, EBPDoctorConfidence::Medium, false,
		TEXT("Animation asset targets a different skeleton than the AnimBlueprint."),
		TEXT("Skeleton mismatches cause distorted meshes, bones in wrong positions, or cook/package failures."),
		TEXT("Your AnimBP uses a skeleton, but one of the animations in it was made for a DIFFERENT skeleton."),
		TEXT("1. Open the AnimBP and find the mismatched animation node\n2. Check which Skeleton the AnimBP uses (Class Defaults > Target Skeleton)\n3. Either retarget the animation to the correct skeleton, or replace it with a compatible animation\n4. Use the Retarget Manager (Window > Retarget Manager) for bulk retargeting"),
		TEXT("Compares the AnimBP's TargetSkeleton against each referenced animation's Skeleton. Flags mismatches.")));

	AllChecks.Add(MakeCheck(4, TEXT("Missing Default Slot"), TEXT("MISSING_SLOT"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, true,
		TEXT("AnimBP references montages but has no Slot node in the AnimGraph -- montages will not play."),
		TEXT("This is the #1 AnimBP question on forums. PlayMontage() silently fails without a Slot node."),
		TEXT("Your AnimBP uses montages but has no Slot node. Without a Slot, the engine has nowhere to play them."),
		TEXT("AUTO-FIX: Adds a DefaultSlot node to the AnimGraph. After fixing, open the AnimBP and connect the Slot node into your pose chain.\n\nMANUAL:\n1. Open the AnimBP > AnimGraph\n2. Right-click > Add Slot node (search 'Slot')\n3. Set the Slot Name (usually 'DefaultSlot')\n4. Connect it between your pose chain and the Output Pose\n5. Make sure your Montages use the same Slot Name"),
		TEXT("Searches AnimGraph for AnimGraphNode_Slot. Detection confidence is MEDIUM because montages may be triggered from other BPs.")));

	AllChecks.Add(MakeCheck(5, TEXT("Broken Transition"), TEXT("BROKEN_TRANS"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("State machine contains unreachable states with no inbound transitions."),
		TEXT("Unreachable states mean your character can get stuck in an animation with no way out."),
		TEXT("Your state machine has states that can never be reached -- no arrow pointing into them."),
		TEXT("1. Open the State Machine graph\n2. Look for states with no arrows pointing INTO them (only outgoing arrows)\n3. Either add a transition from another state, or delete the unreachable state\n4. Verify every state has at least one inbound transition path from the Entry node"),
		TEXT("Skips state machines with fewer than 3 states. Counts states vs transitions; if states > transitions + 1, some states may be unreachable.")));

	AllChecks.Add(MakeCheck(6, TEXT("T-Pose Fallback"), TEXT("TPOSE_FALLBACK"),
		EBPDoctorSeverity::Error, EBPDoctorConfidence::Medium, false,
		TEXT("LayeredBoneBlend has a disconnected BasePose input, causing T-pose."),
		TEXT("This produces a partial T-pose on specific bones during specific blend scenarios."),
		TEXT("A bone blending node has a disconnected input. Affected bones fall back to T-pose."),
		TEXT("1. Open the AnimBP and find the LayeredBoneBlend node\n2. Check that the BasePose (first) input pin is connected\n3. Connect it to your main animation pose chain\n4. If layering is intentional, ensure all blend layers have valid inputs"),
		TEXT("Checks LayeredBoneBlend nodes for disconnected BasePose input pins.")));

	AllChecks.Add(MakeCheck(7, TEXT("Orphaned Node"), TEXT("ORPHANED_NODE"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::Medium, true,
		TEXT("Node exists in the graph but is not reachable from the Output Pose."),
		TEXT("Orphaned nodes clutter the graph and create noise during debugging. Consider deleting them."),
		TEXT("Your AnimBP graph has nodes that aren't connected to anything. Safe to delete."),
		TEXT("AUTO-FIX: Deletes all AnimGraph nodes not reachable from the Output Pose root. Only affects top-level graph nodes (state machine contents are preserved).\n\nMANUAL:\n1. Click Navigate to find the orphaned node\n2. Check if it was accidentally disconnected (reconnect if needed)\n3. If truly unused, select it and press Delete\n4. Clean up any connected but also-orphaned nodes"),
		TEXT("Skips AnimBPs with 15 or fewer anim nodes. Walks from Output Pose root via input pins. Flags if more than 3 nodes are unreachable.")));

	AllChecks.Add(MakeCheck(8, TEXT("Invalid BlendSpace"), TEXT("INVALID_BSPACE"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("BlendSpace asset has 0 or 1 sample points -- cannot interpolate."),
		TEXT("A BlendSpace with insufficient samples produces static or broken interpolation."),
		TEXT("A BlendSpace needs at least 2 animation samples to interpolate between."),
		TEXT("1. Open the BlendSpace asset (double-click in Content Browser)\n2. Add sample points by dragging animations onto the grid\n3. Place at least 2 samples at different axis positions\n4. Preview the interpolation by moving the green crosshair"),
		TEXT("Reads BlendSpace sample count. Flags assets with fewer than 2 samples.")));

	AllChecks.Add(MakeCheck(9, TEXT("Missing Notify"), TEXT("MISSING_NOTIFY"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::Medium, false,
		TEXT("AnimNotify references a function or event that has been deleted."),
		TEXT("Missing notify handlers cause footstep sounds, VFX triggers, and gameplay events to silently stop firing."),
		TEXT("Your animation has a Notify event but there's no matching handler function."),
		TEXT("1. Open the AnimBP > Event Graph\n2. Check if the notify handler function exists (AnimNotify_[NotifyName])\n3. If deleted: right-click > Add AnimNotify Event > select the notify\n4. Reconnect the event to its gameplay logic (sound, VFX, etc.)"),
		TEXT("Checks for AnimNotify references in the AnimBP that have no corresponding handler function in the event graph.")));

	AllChecks.Add(MakeCheck(10, TEXT("Duplicate Slot Name"), TEXT("DUP_SLOT"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::High, true,
		TEXT("The same slot name is used by multiple Slot nodes in the AnimGraph."),
		TEXT("Duplicate slot names cause montages to play on ALL matching slots simultaneously, causing animation conflicts."),
		TEXT("Two Slot nodes have the same name. Montages will play on ALL matching slots simultaneously."),
		TEXT("AUTO-FIX: Renames duplicates with _2, _3 suffixes. Use custom input to set your own name.\n\nMANUAL: Open AnimGraph > find Slot nodes > give each a unique name (e.g., UpperBody, LowerBody, FullBody)."),
		TEXT("Compares SlotName on all AnimGraphNode_Slot nodes. Exact string match — HIGH confidence.")));

	AllChecks.Add(MakeCheck(11, TEXT("Unused Variable"), TEXT("UNUSED_VAR"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::Low, false,
		TEXT("AnimBP declares many variables but very few are read in the AnimGraph (heuristic)."),
		TEXT("Unused variables create false leads during debugging."),
		TEXT("Your AnimBP declares many variables but barely uses them in the animation graph."),
		TEXT("1. Open the AnimBP > Class Defaults or My Blueprint panel\n2. Find the flagged variable\n3. Search for it in the AnimGraph (Ctrl+F)\n4. If truly unused, delete it from My Blueprint\n\nNOTE: Verify in editor — this check uses heuristics and may have false positives."),
		TEXT("Heuristic: flags AnimBPs with 12+ properties and fewer than 3 VariableGet nodes. LOW confidence — may miss property access bindings and struct patterns. Always verify in editor.")));

	AllChecks.Add(MakeCheck(12, TEXT("Deprecated Node"), TEXT("DEPRECATED_NODE"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("AnimGraph uses a node class marked CLASS_Deprecated."),
		TEXT("Deprecated nodes will break on the next engine upgrade."),
		TEXT("Your AnimBP uses a node type that Epic has marked as deprecated."),
		TEXT("1. Click Navigate to find the deprecated node\n2. Hover over it to see the deprecation warning\n3. Right-click > Find Replacement (if available)\n4. Replace with the modern equivalent node\n5. Reconnect all pins and verify behavior"),
		TEXT("Checks node class flags for CLASS_Deprecated. Reliable across engine versions.")));

	// General BP Checks (13-26)
	AllChecks.Add(MakeCheck(13, TEXT("Broken Asset Reference"), TEXT("BP_BROKEN_REF"),
		EBPDoctorSeverity::Error, EBPDoctorConfidence::High, false,
		TEXT("Blueprint references an asset path that does not exist on disk."),
		TEXT("Broken references cause crashes, failed loads, or silent null behavior at runtime."),
		TEXT("Your Blueprint references another asset that has been deleted or moved."),
		TEXT("1. Click Navigate to open the Blueprint\n2. Look for nodes with red 'Missing' errors or yellow warning icons\n3. Right-click the broken reference > Browse to Asset (will fail)\n4. Replace with a valid asset reference, or delete the node\n5. Check Content Browser > Filters > Show Redirectors for moved assets"),
		TEXT("Scans all object references in the Blueprint package. Flags paths that don't resolve via AssetRegistry.")));

	AllChecks.Add(MakeCheck(14, TEXT("Excessive Complexity"), TEXT("BP_COMPLEXITY"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint has an extremely high node count (100+ unique nodes)."),
		TEXT("Complex Blueprints are harder to maintain, debug, and optimize."),
		TEXT("This Blueprint has over 100 nodes. Consider breaking it into smaller functions."),
		TEXT("1. Open the Blueprint and assess which logic can be grouped\n2. Select related nodes > right-click > Collapse to Function\n3. Consider moving heavy computation to C++ (better performance + debugging)\n4. Split responsibilities: one BP per concern, not one mega-BP"),
		TEXT("Counts unique graph nodes across all graphs. Threshold: 100+ nodes. MEDIUM confidence — node count alone doesn't determine complexity.")));

	AllChecks.Add(MakeCheck(15, TEXT("Empty Event Graph"), TEXT("BP_EMPTY_GRAPH"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::High, false,
		TEXT("Blueprint contains very few logic nodes (fewer than 3)."),
		TEXT("Empty Blueprints clutter the project, confuse team members, and waste compile time."),
		TEXT("This Blueprint has no logic inside it. Delete it if not needed."),
		TEXT("1. Verify this BP isn't used as a data-only Blueprint (check for variables/components)\n2. If truly empty: right-click in Content Browser > Delete\n3. Fix Up Redirectors after deleting to clean up references\n4. If it's a parent class: check if child BPs depend on it"),
		TEXT("Counts meaningful nodes (excludes default Event nodes). Flags BPs with 0-2 logic nodes.")));

	AllChecks.Add(MakeCheck(16, TEXT("Tick Performance Risk"), TEXT("BP_TICK_HEAVY"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint has Event Tick enabled with high node complexity."),
		TEXT("Event Tick runs every frame for every instance. Complex Tick = major FPS drops."),
		TEXT("Event Tick runs code EVERY FRAME. Use a Timer instead for heavy work."),
		TEXT("1. Open the Blueprint > Event Graph > find Event Tick\n2. Move non-essential logic to: Set Timer by Event (0.1-0.5s intervals)\n3. For checks: use Event-driven patterns (overlap events, delegates)\n4. Class Defaults > uncheck 'Start with Tick Enabled' if Tick isn't needed\n5. For C++ actors: set TickInterval to reduce frequency"),
		TEXT("Detects Event Tick node alongside 30+ total nodes. MEDIUM confidence — doesn't verify the expensive nodes are in the Tick execution path.")));

	AllChecks.Add(MakeCheck(17, TEXT("Self-Cast Detected"), TEXT("BP_SELF_CAST"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::High, true,
		TEXT("Blueprint casts to its own class type (unnecessary overhead)."),
		TEXT("Casting to Self always succeeds and creates an unnecessary hard reference. Replace with a direct Self reference."),
		TEXT("Your Blueprint casts to its own type. Use 'Self' reference instead."),
		TEXT("AUTO-FIX: Removes the Cast node and reroutes connections through the source pin.\n\nMANUAL:\n1. Find the Cast-to-Self node\n2. Note what's connected to the 'As [ClassName]' output pin\n3. Delete the Cast node\n4. Drag from 'Self' reference and connect to where the cast output was used"),
		TEXT("Compares Cast node TargetType against the Blueprint's own GeneratedClass. Exact match — HIGH confidence.")));

	AllChecks.Add(MakeCheck(18, TEXT("Deprecated API Usage"), TEXT("BP_DEPRECATED_FUNC"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint uses functions or classes marked as deprecated."),
		TEXT("Deprecated APIs will be removed in future engine versions."),
		TEXT("This Blueprint calls deprecated functions. They work now but will be removed."),
		TEXT("1. Click Navigate to find the deprecated node\n2. Hover over it — the tooltip shows the deprecation message and suggested replacement\n3. Delete the deprecated node\n4. Add the replacement function (usually has a similar name)\n5. Reconnect pins and test"),
		TEXT("Checks function metadata for the 'DeprecatedFunction' tag.")));

	AllChecks.Add(MakeCheck(19, TEXT("Circular Dependency"), TEXT("BP_CIRCULAR_DEP"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Two Blueprints reference each other, creating a circular dependency."),
		TEXT("Circular dependencies cause unpredictable load order, editor hitches, and potential crashes."),
		TEXT("Two Blueprints reference each other. Use a Blueprint Interface to break the cycle."),
		TEXT("1. Identify which BP should 'own' the relationship\n2. Create a Blueprint Interface (right-click > Blueprint > Blueprint Interface)\n3. Move the shared function signatures to the Interface\n4. Have the dependent BP implement the Interface instead of casting\n5. Replace Cast nodes with Interface calls (Message nodes)"),
		TEXT("Uses AssetRegistry dependency tracking to detect bidirectional package references. MEDIUM confidence — only detects package-level deps, not pin-level.")));

	AllChecks.Add(MakeCheck(20, TEXT("Oversized Blueprint Asset"), TEXT("BP_MASSIVE_ASSET"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::High, false,
		TEXT("Blueprint .uasset file is abnormally large (>5MB)."),
		TEXT("Oversized files slow down editor load times, version control, and cooking."),
		TEXT("This Blueprint file is unusually large (over 5MB). Normal Blueprints are under 1MB."),
		TEXT("1. Check for embedded data: large arrays, mesh data, or texture references stored as defaults\n2. Move large data to separate Data Assets or Data Tables\n3. Check for excessive node graphs (see BP_COMPLEXITY check)\n4. Right-click > Size Map in Content Browser to see what's consuming space"),
		TEXT("Reads the .uasset file size from disk. Threshold: 5MB. Deterministic — HIGH confidence.")));

	AllChecks.Add(MakeCheck(21, TEXT("Hard Reference Bloat"), TEXT("BP_HARD_REF"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint has excessive hard references to other Blueprint classes."),
		TEXT("Each Cast-to-Blueprint forces the target AND all dependencies into memory at load time."),
		TEXT("This Blueprint has many hard references via Cast nodes. Use Interfaces or Soft References."),
		TEXT("1. Open the Blueprint and identify Cast-to-Blueprint nodes\n2. Replace casts with Blueprint Interface calls where possible\n3. For asset loading: use Soft Object References (TSoftObjectPtr) + Async Load\n4. Use the Reference Viewer (right-click > Reference Viewer) to visualize the dependency chain"),
		TEXT("Counts Cast-to-Blueprint nodes. Each creates a hard reference. Threshold: 5+ casts. MEDIUM confidence — some casts are necessary.")));

	AllChecks.Add(MakeCheck(22, TEXT("Expensive Operations in Tick"), TEXT("BP_EXPENSIVE_TICK"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint has expensive query operations alongside Event Tick."),
		TEXT("GetAllActorsOfClass and similar queries inside Tick run every frame for every instance."),
		TEXT("Expensive search functions alongside Event Tick will tank FPS. Move to Timer or BeginPlay."),
		TEXT("1. Find the expensive node (GetAllActorsOfClass, SweepMulti, etc.)\n2. Move it to BeginPlay and cache the result in a variable\n3. Or use Set Timer by Event to run it periodically (every 0.2-0.5s)\n4. For actor finding: use Actor Tags + GetAllActorsWithTag (faster)\n5. Single line traces in Tick are usually OK — bulk queries are the problem"),
		TEXT("Detects expensive function calls (GetAllActorsOfClass, etc.) coexisting with Event Tick. MEDIUM confidence — doesn't verify execution flow.")));

	AllChecks.Add(MakeCheck(23, TEXT("Debug Nodes in Production"), TEXT("BP_DEBUG_NODES"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::High, true,
		TEXT("Blueprint contains PrintString or DrawDebug nodes."),
		TEXT("PrintString executes in Shipping builds (logs to output). DrawDebug is compiled out but clutters the graph."),
		TEXT("Debug nodes should be removed before shipping. PrintString still runs in packaged builds."),
		TEXT("AUTO-FIX: Deletes all PrintString and DrawDebug nodes, rerouting execution pins.\n\nMANUAL:\n1. Search the BP for 'PrintString' and 'DrawDebug' (Ctrl+F)\n2. Delete each debug node\n3. Reconnect the execution (white) pins around the deleted nodes\n4. Consider using UE_LOG in C++ for persistent logging instead"),
		TEXT("Searches for K2Node_CallFunction nodes calling PrintString, DrawDebug*, etc. Exact function name match — HIGH confidence.")));

	AllChecks.Add(MakeCheck(24, TEXT("Construction Script Misuse"), TEXT("BP_CONSTRUCT_HEAVY"),
		EBPDoctorSeverity::Warning, EBPDoctorConfidence::High, false,
		TEXT("Construction Script contains spawning or heavy query operations."),
		TEXT("Construction Script runs in the editor every time a property changes. Heavy ops cause editor freezes."),
		TEXT("Heavy operations like SpawnActor in Construction Script cause editor freezes. Move to BeginPlay."),
		TEXT("1. Open the Blueprint > Construction Script graph\n2. Find SpawnActor, GetAllActorsOfClass, or similar heavy nodes\n3. Move them to the BeginPlay event in the Event Graph\n4. Construction Script should only set variables, configure components, or do lightweight setup\n5. If you need editor-visible spawning, use ChildActorComponents instead"),
		TEXT("Scans Construction Script graph for SpawnActor, query operations, and other heavy calls. HIGH confidence — these patterns reliably cause editor issues.")));

	AllChecks.Add(MakeCheck(25, TEXT("ForEach Loop Performance"), TEXT("BP_FOREACH_PERF"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::Medium, false,
		TEXT("ForEachLoop re-evaluates pure input nodes on every iteration."),
		TEXT("ForEachLoop re-evaluates pure input expressions every iteration, multiplying the cost of connected queries."),
		TEXT("ForEachLoop re-runs input expressions on every pass. Cache the array in a variable first."),
		TEXT("1. Find the ForEachLoop macro node\n2. Check what's connected to its Array input\n3. If it's a function call (GetComponentsByClass, etc.): cache it first\n4. Create a local variable, assign the query result to it BEFORE the loop\n5. Connect the variable to the ForEachLoop input instead"),
		TEXT("Detects ForEachLoop macro alongside expensive function calls in the same Blueprint. MEDIUM confidence — doesn't verify the expensive call is the loop's input.")));

	AllChecks.Add(MakeCheck(26, TEXT("Excessive Timeline Components"), TEXT("BP_TIMELINE_HEAVY"),
		EBPDoctorSeverity::Info, EBPDoctorConfidence::Medium, false,
		TEXT("Blueprint has multiple Timeline nodes creating hidden tick overhead."),
		TEXT("Each Timeline creates a hidden UTimelineComponent that ticks every frame."),
		TEXT("Each Timeline node creates a hidden per-frame cost. Consider merging Timelines."),
		TEXT("1. Identify which Timelines can be merged (similar curves/durations)\n2. Combine into one Timeline with multiple output tracks\n3. For simple lerps: use FInterpTo/FInterpConstantTo in Tick with a low tick rate\n4. For one-shot animations: consider using Set Timer instead of a Timeline"),
		TEXT("Counts K2Node_Timeline instances. Threshold: 3+ Timelines. MEDIUM confidence — multiple Timelines may be intentional.")));
}

const TArray<FBPDoctorCheckDef>& FBPDoctorChecks::GetAllChecks()
{
	InitChecks();
	if (!bCustomRulesLoaded)
	{
		LoadCustomRules();
		bCustomRulesLoaded = true;
	}
	return AllChecks;
}

void FBPDoctorChecks::SetDisabledChecks(const TSet<FString>& Codes)
{
	DisabledCheckCodes = Codes;
}

void FBPDoctorChecks::RefreshCustomRules()
{
	bCustomRulesLoaded = false;
}

const FBPDoctorCheckDef* FBPDoctorChecks::FindCheck(const FString& Code)
{
	InitChecks();
	for (const auto& Check : AllChecks)
	{
		if (Check.Code == Code) return &Check;
	}
	return nullptr;
}

// ─────────────────────────────────────────────────────────────────
//  CUSTOM RULES (user-defined via JSON)
// ─────────────────────────────────────────────────────────────────

void FBPDoctorChecks::LoadCustomRules()
{
	// Remove any previously loaded custom rules (IDs >= 100)
	AllChecks.RemoveAll([](const FBPDoctorCheckDef& C) { return C.Id >= 100; });

	FString RulesPath = FPaths::ProjectSavedDir() / TEXT("BPDoctor") / TEXT("CustomRules.json");
	FString JsonString;
	if (!FFileHelper::LoadFileToString(JsonString, *RulesPath)) return;

	TSharedPtr<FJsonObject> Root;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
	if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid()) return;

	const TArray<TSharedPtr<FJsonValue>>* RulesArray;
	if (!Root->TryGetArrayField(TEXT("rules"), RulesArray)) return;

	int32 CustomId = 100;
	for (const auto& RuleVal : *RulesArray)
	{
		const TSharedPtr<FJsonObject>* RuleObj;
		if (!RuleVal->TryGetObject(RuleObj)) continue;

		FBPDoctorCheckDef Def;
		Def.Id = CustomId++;
		Def.Name = (*RuleObj)->GetStringField(TEXT("name"));
		Def.Code = (*RuleObj)->GetStringField(TEXT("code"));
		Def.Description = (*RuleObj)->GetStringField(TEXT("description"));
		Def.WhyItMatters = (*RuleObj)->GetStringField(TEXT("why_it_matters"));
		Def.BeginnerTip = (*RuleObj)->GetStringField(TEXT("beginner_tip"));
		Def.bAutoFixable = false;

		FString SevStr = (*RuleObj)->GetStringField(TEXT("severity")).ToUpper();
		Def.Severity = (SevStr == TEXT("ERROR")) ? EBPDoctorSeverity::Error :
			(SevStr == TEXT("WARNING")) ? EBPDoctorSeverity::Warning : EBPDoctorSeverity::Info;

		FString ConfStr = (*RuleObj)->GetStringField(TEXT("confidence")).ToUpper();
		Def.Confidence = (ConfStr == TEXT("HIGH")) ? EBPDoctorConfidence::High :
			(ConfStr == TEXT("LOW")) ? EBPDoctorConfidence::Low : EBPDoctorConfidence::Medium;

		FString TypeStr = (*RuleObj)->GetStringField(TEXT("type")).ToLower();
		if (TypeStr == TEXT("banned_function"))
		{
			Def.CustomRule.Type = EBPDoctorRuleType::BannedFunction;
			Def.CustomRule.MatchString = (*RuleObj)->GetStringField(TEXT("function_name"));
		}
		else if (TypeStr == TEXT("banned_node"))
		{
			Def.CustomRule.Type = EBPDoctorRuleType::BannedNode;
			Def.CustomRule.MatchString = (*RuleObj)->GetStringField(TEXT("node_class_contains"));
		}
		else if (TypeStr == TEXT("required_node"))
		{
			Def.CustomRule.Type = EBPDoctorRuleType::RequiredNode;
			Def.CustomRule.MatchString = (*RuleObj)->GetStringField(TEXT("node_class_contains"));
			(*RuleObj)->TryGetBoolField(TEXT("animBP_only"), Def.CustomRule.bAnimBPOnly);
		}
		else if (TypeStr == TEXT("node_limit"))
		{
			Def.CustomRule.Type = EBPDoctorRuleType::NodeLimit;
			Def.CustomRule.MatchString = (*RuleObj)->GetStringField(TEXT("node_class_contains"));
			Def.CustomRule.MaxCount = (*RuleObj)->GetIntegerField(TEXT("max_count"));
		}
		else
		{
			continue; // Unknown rule type, skip
		}

		AllChecks.Add(Def);
	}
}

TArray<FBPDoctorResult> FBPDoctorChecks::RunCustomRules(UBlueprint* Blueprint)
{
	TArray<FBPDoctorResult> Results;
	bool bIsAnimBP = Blueprint->IsA<UAnimBlueprint>();

	// Collect all graphs
	TArray<UEdGraph*> AllGraphs;
	AllGraphs.Append(Blueprint->UbergraphPages);
	AllGraphs.Append(Blueprint->FunctionGraphs);
	AllGraphs.Append(Blueprint->MacroGraphs);

	for (const FBPDoctorCheckDef& Def : AllChecks)
	{
		if (Def.CustomRule.Type == EBPDoctorRuleType::None) continue;
		if (Def.CustomRule.bAnimBPOnly && !bIsAnimBP) continue;

		switch (Def.CustomRule.Type)
		{
			case EBPDoctorRuleType::BannedFunction:
			{
				for (UEdGraph* Graph : AllGraphs)
				{
					for (UEdGraphNode* Node : Graph->Nodes)
					{
						if (UK2Node_CallFunction* Call = Cast<UK2Node_CallFunction>(Node))
						{
							if (Call->FunctionReference.GetMemberName() == FName(*Def.CustomRule.MatchString))
							{
								FBPDoctorResult R;
								R.CheckCode = Def.Code;
								R.Severity = Def.Severity;
								R.AssetName = Blueprint->GetName();
								R.AssetPath = Blueprint->GetPathName();
								R.Description = Def.Description;
								R.NodeHint = Node->GetNodeTitle(ENodeTitleType::ListView).ToString();
								R.bAutoFixable = false;
								R.AssetType = bIsAnimBP ? EBPDoctorAssetType::AnimBP : EBPDoctorAssetType::Blueprint;
								Results.Add(R);
							}
						}
					}
				}
				break;
			}
			case EBPDoctorRuleType::BannedNode:
			{
				for (UEdGraph* Graph : AllGraphs)
				{
					for (UEdGraphNode* Node : Graph->Nodes)
					{
						if (Node->GetClass()->GetName().Contains(Def.CustomRule.MatchString))
						{
							FBPDoctorResult R;
							R.CheckCode = Def.Code;
							R.Severity = Def.Severity;
							R.AssetName = Blueprint->GetName();
							R.AssetPath = Blueprint->GetPathName();
							R.Description = Def.Description;
							R.NodeHint = Node->GetNodeTitle(ENodeTitleType::ListView).ToString();
							R.bAutoFixable = false;
							R.AssetType = bIsAnimBP ? EBPDoctorAssetType::AnimBP : EBPDoctorAssetType::Blueprint;
							Results.Add(R);
						}
					}
				}
				break;
			}
			case EBPDoctorRuleType::RequiredNode:
			{
				bool bFound = false;
				for (UEdGraph* Graph : AllGraphs)
				{
					for (UEdGraphNode* Node : Graph->Nodes)
					{
						if (Node->GetClass()->GetName().Contains(Def.CustomRule.MatchString))
						{
							bFound = true;
							break;
						}
					}
					if (bFound) break;
				}
				if (!bFound)
				{
					FBPDoctorResult R;
					R.CheckCode = Def.Code;
					R.Severity = Def.Severity;
					R.AssetName = Blueprint->GetName();
					R.AssetPath = Blueprint->GetPathName();
					R.Description = Def.Description;
					R.bAutoFixable = false;
					R.AssetType = bIsAnimBP ? EBPDoctorAssetType::AnimBP : EBPDoctorAssetType::Blueprint;
					Results.Add(R);
				}
				break;
			}
			case EBPDoctorRuleType::NodeLimit:
			{
				int32 Count = 0;
				for (UEdGraph* Graph : AllGraphs)
				{
					for (UEdGraphNode* Node : Graph->Nodes)
					{
						if (Node->GetClass()->GetName().Contains(Def.CustomRule.MatchString))
							Count++;
					}
				}
				if (Count > Def.CustomRule.MaxCount)
				{
					FBPDoctorResult R;
					R.CheckCode = Def.Code;
					R.Severity = Def.Severity;
					R.AssetName = Blueprint->GetName();
					R.AssetPath = Blueprint->GetPathName();
					R.Description = FString::Printf(TEXT("%s Found %d (max: %d)."), *Def.Description, Count, Def.CustomRule.MaxCount);
					R.bAutoFixable = false;
					R.AssetType = bIsAnimBP ? EBPDoctorAssetType::AnimBP : EBPDoctorAssetType::Blueprint;
					Results.Add(R);
				}
				break;
			}
			default: break;
		}
	}

	return Results;
}

// ─────────────────────────────────────────────────────────────────
//  GRAPH UTILITY HELPERS
// ─────────────────────────────────────────────────────────────────

namespace BPDoctorUtil
{
	// ── Per-BP Scan Memoization ──────────────────────────────────
	// Caches expensive computations so each is done once per BP
	// instead of once per check (up to 22 redundant walks → 5).

	static UBlueprint* s_MemoBP = nullptr;
	static int32 s_MemoNodeCount = -1;
	static int8 s_MemoHasEventTick = -1;  // -1=unknown, 0=false, 1=true
	static TArray<UAnimGraphNode_Base*> s_MemoAnimNodes;
	static bool s_bMemoAnimNodesValid = false;
	static TArray<UK2Node_CallFunction*> s_MemoCallFunctions;
	static bool s_bMemoCallFunctionsValid = false;
	static TArray<UK2Node_DynamicCast*> s_MemoDynamicCasts;
	static bool s_bMemoDynamicCastsValid = false;

	void BeginMemo(UBlueprint* BP)
	{
		s_MemoBP = BP;
		s_MemoNodeCount = -1;
		s_MemoHasEventTick = -1;
		s_MemoAnimNodes.Reset();
		s_bMemoAnimNodesValid = false;
		s_MemoCallFunctions.Reset();
		s_bMemoCallFunctionsValid = false;
		s_MemoDynamicCasts.Reset();
		s_bMemoDynamicCastsValid = false;
	}

	void EndMemo()
	{
		s_MemoBP = nullptr;
		s_MemoNodeCount = -1;
		s_MemoHasEventTick = -1;
		s_MemoAnimNodes.Reset();
		s_bMemoAnimNodesValid = false;
		s_MemoCallFunctions.Reset();
		s_bMemoCallFunctionsValid = false;
		s_MemoDynamicCasts.Reset();
		s_bMemoDynamicCastsValid = false;
	}

	// ── Node Collection Utilities ────────────────────────────────

	/** Count all nodes of a given type across all graphs in a Blueprint. */
	template<typename T>
	int32 CountNodesOfType(UBlueprint* BP)
	{
		int32 Count = 0;
		for (UEdGraph* Graph : BP->UbergraphPages)
		{
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				if (Cast<T>(Node)) Count++;
			}
		}
		for (UEdGraph* Graph : BP->FunctionGraphs)
		{
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				if (Cast<T>(Node)) Count++;
			}
		}
		return Count;
	}

	/** Collect all nodes of a given type across all graphs. */
	template<typename T>
	TArray<T*> CollectNodesOfType(UBlueprint* BP)
	{
		TArray<T*> Result;
		for (UEdGraph* Graph : BP->UbergraphPages)
		{
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				if (T* Typed = Cast<T>(Node)) Result.Add(Typed);
			}
		}
		for (UEdGraph* Graph : BP->FunctionGraphs)
		{
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				if (T* Typed = Cast<T>(Node)) Result.Add(Typed);
			}
		}
		return Result;
	}

	/** Memoized: Collect all K2Node_CallFunction nodes (called by 5 checks). */
	const TArray<UK2Node_CallFunction*>& GetCallFunctionNodes(UBlueprint* BP)
	{
		if (BP == s_MemoBP && s_bMemoCallFunctionsValid)
			return s_MemoCallFunctions;

		TArray<UK2Node_CallFunction*> Result = CollectNodesOfType<UK2Node_CallFunction>(BP);

		if (BP == s_MemoBP)
		{
			s_MemoCallFunctions = MoveTemp(Result);
			s_bMemoCallFunctionsValid = true;
			return s_MemoCallFunctions;
		}
		// Fallback for uncached calls — store temporarily and return
		s_MemoCallFunctions = MoveTemp(Result);
		return s_MemoCallFunctions;
	}

	/** Memoized: Collect all K2Node_DynamicCast nodes (called by 3 checks). */
	const TArray<UK2Node_DynamicCast*>& GetDynamicCastNodes(UBlueprint* BP)
	{
		if (BP == s_MemoBP && s_bMemoDynamicCastsValid)
			return s_MemoDynamicCasts;

		TArray<UK2Node_DynamicCast*> Result = CollectNodesOfType<UK2Node_DynamicCast>(BP);

		if (BP == s_MemoBP)
		{
			s_MemoDynamicCasts = MoveTemp(Result);
			s_bMemoDynamicCastsValid = true;
			return s_MemoDynamicCasts;
		}
		s_MemoDynamicCasts = MoveTemp(Result);
		return s_MemoDynamicCasts;
	}

	/** Memoized: Count total nodes across all graphs. Called by 3 checks. */
	int32 CountTotalNodes(UBlueprint* BP)
	{
		if (BP == s_MemoBP && s_MemoNodeCount >= 0)
			return s_MemoNodeCount;

		int32 Count = 0;
		for (UEdGraph* Graph : BP->UbergraphPages)
		{
			Count += Graph->Nodes.Num();
		}
		for (UEdGraph* Graph : BP->FunctionGraphs)
		{
			Count += Graph->Nodes.Num();
		}

		if (BP == s_MemoBP)
			s_MemoNodeCount = Count;

		return Count;
	}

	/** Check if any graph has a node calling a specific function. */
	bool HasFunctionCall(UBlueprint* BP, const FName& FunctionName)
	{
		const auto& CallNodes = GetCallFunctionNodes(BP);
		for (UK2Node_CallFunction* Node : CallNodes)
		{
			if (Node->FunctionReference.GetMemberName() == FunctionName)
			{
				return true;
			}
		}
		return false;
	}

	/** Memoized: Check if Blueprint has Event Tick. Called by 2 checks. */
	bool HasEventTick(UBlueprint* BP)
	{
		if (BP == s_MemoBP && s_MemoHasEventTick >= 0)
			return s_MemoHasEventTick == 1;

		auto EventNodes = CollectNodesOfType<UK2Node_Event>(BP);
		for (UK2Node_Event* Event : EventNodes)
		{
			if (Event->EventReference.GetMemberName() == FName("ReceiveTick"))
			{
				if (BP == s_MemoBP) s_MemoHasEventTick = 1;
				return true;
			}
		}
		if (BP == s_MemoBP) s_MemoHasEventTick = 0;
		return false;
	}

	/** Memoized: Get AnimBP graph nodes from ALL graph sources. Called by 9 checks. */
	TArray<UAnimGraphNode_Base*> GetAnimGraphNodes(UAnimBlueprint* AnimBP)
	{
		if (static_cast<UBlueprint*>(AnimBP) == s_MemoBP && s_bMemoAnimNodesValid)
			return s_MemoAnimNodes;

		TArray<UAnimGraphNode_Base*> Result;

		// Helper lambda to scan a graph and its subgraphs recursively
		TFunction<void(UEdGraph*)> ScanGraph = [&](UEdGraph* Graph)
		{
			if (!Graph) return;
			for (UEdGraphNode* Node : Graph->Nodes)
			{
				if (UAnimGraphNode_Base* AnimNode = Cast<UAnimGraphNode_Base>(Node))
				{
					Result.Add(AnimNode);
					// Also scan subgraphs (state machines, etc.)
					TArray<UEdGraph*> SubGraphs = AnimNode->GetSubGraphs();
					for (UEdGraph* Sub : SubGraphs)
					{
						ScanGraph(Sub);
					}
				}
			}
		};

		// AnimBP animation graphs (the actual AnimGraph lives here)
		for (UEdGraph* Graph : AnimBP->FunctionGraphs)
		{
			ScanGraph(Graph);
		}
		// Also check UbergraphPages (some AnimBP setups put nodes here)
		for (UEdGraph* Graph : AnimBP->UbergraphPages)
		{
			ScanGraph(Graph);
		}

		if (static_cast<UBlueprint*>(AnimBP) == s_MemoBP)
		{
			s_MemoAnimNodes = Result;
			s_bMemoAnimNodesValid = true;
		}

		return Result;
	}

	/** Build a result struct. */
	FBPDoctorResult MakeResult(const FBPDoctorCheckDef& Check, const FString& AssetName,
		const FString& AssetPath, const FString& Desc, const FString& Hint,
		EBPDoctorAssetType Type = EBPDoctorAssetType::AnimBP)
	{
		FBPDoctorResult R;
		R.CheckCode = Check.Code;
		R.Severity = Check.Severity;
		R.AssetName = AssetName;
		R.AssetPath = AssetPath;
		R.Description = Desc;
		R.NodeHint = Hint;
		R.bAutoFixable = Check.bAutoFixable;
		R.AssetType = Type;
		return R;
	}
}

// ─────────────────────────────────────────────────────────────────
//  CHECK DISPATCH
// ─────────────────────────────────────────────────────────────────

TArray<FBPDoctorResult> FBPDoctorChecks::RunChecks(UBlueprint* Blueprint)
{
	using namespace BPDoctorUtil;
	InitChecks();
	BeginMemo(Blueprint);

	TArray<FBPDoctorResult> AllResults;
	AllResults.Reserve(8); // Most BPs have few issues

	UAnimBlueprint* AnimBP = Cast<UAnimBlueprint>(Blueprint);
	bool bIsAnimBP = (AnimBP != nullptr);

	for (const FBPDoctorCheckDef& Check : AllChecks)
	{
		if (DisabledCheckCodes.Contains(Check.Code)) continue;
		TArray<FBPDoctorResult> Results = RunCheck(Check.Code, Blueprint);
		AllResults.Append(Results);
	}

	EndMemo();
	return AllResults;
}

TArray<FBPDoctorResult> FBPDoctorChecks::RunCheck(const FString& CheckCode, UBlueprint* Blueprint)
{
	InitChecks();
	const FBPDoctorCheckDef* Check = FindCheck(CheckCode);
	if (!Check) return {};

	UAnimBlueprint* AnimBP = Cast<UAnimBlueprint>(Blueprint);

	// AnimBP-specific checks require an AnimBP
	if (Check->Id <= 12 && !AnimBP) return {};

	// Dispatch to handler
	if (CheckCode == TEXT("NULL_ANIM_REF"))       return CheckNullAnimRef(*Check, AnimBP);
	if (CheckCode == TEXT("BROKEN_BLEND_WT"))      return CheckBrokenBlendWeight(*Check, AnimBP);
	if (CheckCode == TEXT("SKEL_MISMATCH"))        return CheckSkeletonMismatch(*Check, AnimBP);
	if (CheckCode == TEXT("MISSING_SLOT"))          return CheckMissingSlot(*Check, AnimBP);
	if (CheckCode == TEXT("BROKEN_TRANS"))          return CheckBrokenTransition(*Check, AnimBP);
	if (CheckCode == TEXT("TPOSE_FALLBACK"))        return CheckTPoseFallback(*Check, AnimBP);
	if (CheckCode == TEXT("ORPHANED_NODE"))         return CheckOrphanedNode(*Check, AnimBP);
	if (CheckCode == TEXT("INVALID_BSPACE"))        return CheckInvalidBlendSpace(*Check, AnimBP);
	if (CheckCode == TEXT("MISSING_NOTIFY"))        return CheckMissingNotify(*Check, AnimBP);
	if (CheckCode == TEXT("DUP_SLOT"))              return CheckDuplicateSlot(*Check, AnimBP);
	if (CheckCode == TEXT("UNUSED_VAR"))            return CheckUnusedVariable(*Check, AnimBP);
	if (CheckCode == TEXT("DEPRECATED_NODE"))       return CheckDeprecatedNode(*Check, AnimBP);
	if (CheckCode == TEXT("BP_BROKEN_REF"))         return CheckBrokenAssetRef(*Check, Blueprint);
	if (CheckCode == TEXT("BP_COMPLEXITY"))          return CheckComplexity(*Check, Blueprint);
	if (CheckCode == TEXT("BP_EMPTY_GRAPH"))         return CheckEmptyGraph(*Check, Blueprint);
	if (CheckCode == TEXT("BP_TICK_HEAVY"))          return CheckTickHeavy(*Check, Blueprint);
	if (CheckCode == TEXT("BP_SELF_CAST"))           return CheckSelfCast(*Check, Blueprint);
	if (CheckCode == TEXT("BP_DEPRECATED_FUNC"))     return CheckDeprecatedFunc(*Check, Blueprint);
	if (CheckCode == TEXT("BP_CIRCULAR_DEP"))        return CheckCircularDep(*Check, Blueprint);
	if (CheckCode == TEXT("BP_MASSIVE_ASSET"))       return CheckMassiveAsset(*Check, Blueprint);
	if (CheckCode == TEXT("BP_HARD_REF"))            return CheckHardRef(*Check, Blueprint);
	if (CheckCode == TEXT("BP_EXPENSIVE_TICK"))      return CheckExpensiveTick(*Check, Blueprint);
	if (CheckCode == TEXT("BP_DEBUG_NODES"))         return CheckDebugNodes(*Check, Blueprint);
	if (CheckCode == TEXT("BP_CONSTRUCT_HEAVY"))     return CheckConstructHeavy(*Check, Blueprint);
	if (CheckCode == TEXT("BP_FOREACH_PERF"))        return CheckForEachPerf(*Check, Blueprint);
	if (CheckCode == TEXT("BP_TIMELINE_HEAVY"))      return CheckTimelineHeavy(*Check, Blueprint);

	return {};
}

// ─────────────────────────────────────────────────────────────────
//  ANIMBP CHECK IMPLEMENTATIONS (1-12)
// ─────────────────────────────────────────────────────────────────

TArray<FBPDoctorResult> FBPDoctorChecks::CheckNullAnimRef(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto SeqPlayers = CollectNodesOfType<UAnimGraphNode_SequencePlayer>(AnimBP);
	for (UAnimGraphNode_SequencePlayer* Player : SeqPlayers)
	{
		// Check if the SequencePlayer has an animation asset assigned
		UAnimationAsset* Asset = Player->GetAnimationAsset();
		if (!Asset)
		{
			Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
				Check.Description,
				FString::Printf(TEXT("SequencePlayer '%s' has no animation assigned"),
					*Player->GetNodeTitle(ENodeTitleType::ListView).ToString())));
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckBrokenBlendWeight(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto LBBNodes = CollectNodesOfType<UAnimGraphNode_LayeredBoneBlend>(AnimBP);
	for (UAnimGraphNode_LayeredBoneBlend* LBB : LBBNodes)
	{
		// Check blend weights on the node's pins
		for (UEdGraphPin* Pin : LBB->Pins)
		{
			if (Pin->PinName.ToString().Contains(TEXT("BlendWeight")) && !Pin->LinkedTo.Num())
			{
				// Check default value
				FString DefaultVal = Pin->GetDefaultAsString();
				if (!DefaultVal.IsEmpty())
				{
					float Val = FCString::Atof(*DefaultVal);
					if (Val < 0.0f || Val > 1.0f)
					{
						Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
							FString::Printf(TEXT("%s Found weight: %.3f"), *Check.Description, Val),
							FString::Printf(TEXT("BlendWeight = %.3f"), Val)));
					}
				}
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckSkeletonMismatch(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	USkeleton* TargetSkeleton = AnimBP->TargetSkeleton.Get();
	if (!TargetSkeleton) return Results;

	// Walk all anim graph nodes and check referenced animation assets
	auto AnimNodes = GetAnimGraphNodes(AnimBP);
	TSet<FString> MismatchedSkeletons;
	for (UAnimGraphNode_Base* Node : AnimNodes)
	{
		UAnimationAsset* AnimAsset = Node->GetAnimationAsset();
		if (AnimAsset)
		{
			USkeleton* AnimSkeleton = AnimAsset->GetSkeleton();
			if (AnimSkeleton && AnimSkeleton != TargetSkeleton)
			{
				MismatchedSkeletons.Add(AnimSkeleton->GetName());
			}
		}
	}

	if (MismatchedSkeletons.Num() > 0)
	{
		FString SkeletonList = FString::Join(MismatchedSkeletons.Array(), TEXT(", "));
		Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
			FString::Printf(TEXT("%s Target: %s, Mismatched: %s"),
				*Check.Description, *TargetSkeleton->GetName(), *SkeletonList),
			FString::Printf(TEXT("Skeletons: %s vs %s"),
				*TargetSkeleton->GetName(), *SkeletonList)));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckMissingSlot(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Check if any montage references exist
	bool bHasMontageRef = false;
	auto AnimNodes = GetAnimGraphNodes(AnimBP);
	for (UAnimGraphNode_Base* Node : AnimNodes)
	{
		UAnimationAsset* Asset = Node->GetAnimationAsset();
		if (Asset && Asset->IsA<UAnimMontage>())
		{
			bHasMontageRef = true;
			break;
		}
	}

	// Also check function calls for PlayMontage
	if (!bHasMontageRef)
	{
		bHasMontageRef = HasFunctionCall(AnimBP, FName("PlayMontage"))
			|| HasFunctionCall(AnimBP, FName("Montage_Play"));
	}

	// Check for Slot nodes
	bool bHasSlot = CollectNodesOfType<UAnimGraphNode_Slot>(AnimBP).Num() > 0;

	if (bHasMontageRef && !bHasSlot)
	{
		Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
			Check.Description,
			TEXT("No AnimGraphNode_Slot found -- montages will silently fail")));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckBrokenTransition(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto StateMachines = CollectNodesOfType<UAnimGraphNode_StateMachine>(AnimBP);
	for (UAnimGraphNode_StateMachine* SM : StateMachines)
	{
		// Get the state machine's sub-graphs
		TArray<UEdGraph*> SubGraphs = SM->GetSubGraphs();

		for (UEdGraph* SMGraph : SubGraphs)
		{
			if (!SMGraph) continue;

			int32 StateCount = 0;
			int32 TransCount = 0;

			for (UEdGraphNode* Node : SMGraph->Nodes)
			{
				if (Cast<UAnimGraphNode_StateResult>(Node))
				{
					StateCount++;
				}
				if (Cast<UAnimGraphNode_TransitionResult>(Node))
				{
					TransCount++;
				}
			}

			if (StateCount > 2)
			{
				// Minimum transitions for reachability: N-1 (tree-shaped)
				int32 MinTransitions = StateCount - 1;
				if (TransCount < MinTransitions)
				{
					int32 Missing = MinTransitions - TransCount;
					Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
						FString::Printf(TEXT("%s %d states, %d transitions (minimum %d needed)."),
							*Check.Description, StateCount, TransCount, MinTransitions),
						FString::Printf(TEXT("%d missing transition(s) -- states may be unreachable"), Missing)));
				}
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckTPoseFallback(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto LBBNodes = CollectNodesOfType<UAnimGraphNode_LayeredBoneBlend>(AnimBP);
	for (UAnimGraphNode_LayeredBoneBlend* LBB : LBBNodes)
	{
		// Check if BasePose pin is disconnected
		for (UEdGraphPin* Pin : LBB->Pins)
		{
			if (Pin->PinName == TEXT("BasePose") && Pin->LinkedTo.Num() == 0)
			{
				Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
					Check.Description,
					FString::Printf(TEXT("LayeredBoneBlend '%s' -- disconnected BasePose"),
						*LBB->GetNodeTitle(ENodeTitleType::ListView).ToString())));
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckOrphanedNode(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto AllAnimNodes = GetAnimGraphNodes(AnimBP);
	if (AllAnimNodes.Num() <= 15) return Results;

	// Walk from output pose root and mark reachable nodes
	TSet<UEdGraphNode*> Reachable;
	TArray<UEdGraphNode*> WorkQueue;

	for (UEdGraphNode* Node : AllAnimNodes)
	{
		// Find the root (output pose node)
		if (Node->GetClass()->GetName().Contains(TEXT("Root")))
		{
			WorkQueue.Add(Node);
			Reachable.Add(Node);
		}
	}

	while (WorkQueue.Num() > 0)
	{
		UEdGraphNode* Current = WorkQueue.Pop();
		for (UEdGraphPin* Pin : Current->Pins)
		{
			if (Pin->Direction == EGPD_Input)
			{
				for (UEdGraphPin* LinkedPin : Pin->LinkedTo)
				{
					UEdGraphNode* LinkedNode = LinkedPin->GetOwningNode();
					if (!Reachable.Contains(LinkedNode))
					{
						Reachable.Add(LinkedNode);
						WorkQueue.Add(LinkedNode);
					}
				}
			}
		}
	}

	int32 OrphanCount = AllAnimNodes.Num() - Reachable.Num();
	if (OrphanCount > 3)
	{
		Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
			FString::Printf(TEXT("%s %d nodes not reachable from Output Pose."), *Check.Description, OrphanCount),
			FString::Printf(TEXT("%d orphaned nodes (of %d total) -- safe to delete"),
				OrphanCount, AllAnimNodes.Num())));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckInvalidBlendSpace(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto BSPlayers = CollectNodesOfType<UAnimGraphNode_BlendSpacePlayer>(AnimBP);
	for (UAnimGraphNode_BlendSpacePlayer* BSPlayer : BSPlayers)
	{
		UAnimationAsset* Asset = BSPlayer->GetAnimationAsset();
		UBlendSpace* BS = Asset ? Cast<UBlendSpace>(Asset) : nullptr;
		if (BS)
		{
			int32 SampleCount = BS->GetBlendSamples().Num();
			if (SampleCount < 2)
			{
				Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
					FString::Printf(TEXT("%s BlendSpace '%s' has %d sample(s)."),
						*Check.Description, *BS->GetName(), SampleCount),
					FString::Printf(TEXT("BlendSpace '%s' needs 2+ samples, has %d"),
						*BS->GetName(), SampleCount)));
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckMissingNotify(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Check animation assets referenced by the AnimBP for notifies
	auto AnimNodes = GetAnimGraphNodes(AnimBP);
	for (UAnimGraphNode_Base* Node : AnimNodes)
	{
		UAnimationAsset* Asset = Node->GetAnimationAsset();
		UAnimSequenceBase* SeqBase = Asset ? Cast<UAnimSequenceBase>(Asset) : nullptr;
		if (!SeqBase) continue;

		for (const FAnimNotifyEvent& Notify : SeqBase->Notifies)
		{
			if (Notify.NotifyName != NAME_None && !Notify.Notify && !Notify.NotifyStateClass)
			{
				Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
					FString::Printf(TEXT("%s Notify '%s' in '%s' has no handler."),
						*Check.Description, *Notify.NotifyName.ToString(), *SeqBase->GetName()),
					FString::Printf(TEXT("Missing handler for notify '%s'"),
						*Notify.NotifyName.ToString())));
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckDuplicateSlot(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto SlotNodes = CollectNodesOfType<UAnimGraphNode_Slot>(AnimBP);
	TMap<FName, int32> SlotNameCounts;

	for (UAnimGraphNode_Slot* Slot : SlotNodes)
	{
		FName SlotName = Slot->Node.SlotName;
		SlotNameCounts.FindOrAdd(SlotName)++;
	}

	for (const auto& Pair : SlotNameCounts)
	{
		if (Pair.Value > 1)
		{
			Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
				FString::Printf(TEXT("%s Duplicate: '%s' (%d times)"),
					*Check.Description, *Pair.Key.ToString(), Pair.Value),
				FString::Printf(TEXT("Slot name '%s' used %d times"),
					*Pair.Key.ToString(), Pair.Value)));
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckUnusedVariable(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	UAnimBlueprintGeneratedClass* GenClass = AnimBP->GetAnimBlueprintGeneratedClass();
	if (!GenClass) return Results;

	// Get all user-defined properties
	TArray<FProperty*> UserProps;
	for (TFieldIterator<FProperty> PropIt(GenClass, EFieldIteratorFlags::ExcludeSuper); PropIt; ++PropIt)
	{
		FProperty* Prop = *PropIt;
		if (Prop)
		{
			UserProps.Add(Prop);
		}
	}

	// Count variable-get nodes in graphs
	int32 VarGetCount = 0;
	for (UEdGraph* Graph : AnimBP->FunctionGraphs)
	{
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (Node->GetClass()->GetName().Contains(TEXT("VariableGet")))
			{
				VarGetCount++;
			}
		}
	}

	if (UserProps.Num() > 12 && VarGetCount < 3)
	{
		Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
			FString::Printf(TEXT("%s %d properties, %d graph reads."),
				*Check.Description, UserProps.Num(), VarGetCount),
			FString::Printf(TEXT("%d properties with minimal graph reads"), UserProps.Num())));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckDeprecatedNode(const FBPDoctorCheckDef& Check, UAnimBlueprint* AnimBP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	auto AnimNodes = GetAnimGraphNodes(AnimBP);
	for (UAnimGraphNode_Base* Node : AnimNodes)
	{
		if (Node->GetClass()->HasAnyClassFlags(CLASS_Deprecated))
		{
			Results.Add(MakeResult(Check, AnimBP->GetName(), AnimBP->GetPathName(),
				FString::Printf(TEXT("%s Node: %s"), *Check.Description, *Node->GetClass()->GetName()),
				FString::Printf(TEXT("Deprecated: %s"), *Node->GetClass()->GetName())));
		}
	}

	return Results;
}

// ─────────────────────────────────────────────────────────────────
//  GENERAL BP CHECK IMPLEMENTATIONS (13-26)
// ─────────────────────────────────────────────────────────────────

TArray<FBPDoctorResult> FBPDoctorChecks::CheckBrokenAssetRef(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Walk all nodes and check for broken references via pins
	TArray<UEdGraph*> AllGraphs;
	AllGraphs.Append(BP->UbergraphPages);
	AllGraphs.Append(BP->FunctionGraphs);
	AllGraphs.Append(BP->MacroGraphs);
	for (UEdGraph* Graph : AllGraphs)
	{
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			for (UEdGraphPin* Pin : Node->Pins)
			{
				if (Pin->PinType.PinCategory == UEdGraphSchema_K2::PC_Object ||
					Pin->PinType.PinCategory == UEdGraphSchema_K2::PC_SoftObject)
				{
					FString DefaultVal = Pin->GetDefaultAsString();
					if (!DefaultVal.IsEmpty() && DefaultVal != TEXT("None"))
					{
						FSoftObjectPath Path(DefaultVal);
						if (!Path.ResolveObject())
						{
							// Verify it's actually a /Game/ path (not a class path)
							if (DefaultVal.StartsWith(TEXT("/Game/")))
							{
								Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
									FString::Printf(TEXT("%s Missing: %s"), *Check.Description, *DefaultVal),
									FString::Printf(TEXT("Broken ref: %s"), *DefaultVal),
									EBPDoctorAssetType::Blueprint));
							}
						}
					}
				}
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckComplexity(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	int32 NodeCount = CountTotalNodes(BP);
	if (NodeCount > 100)
	{
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s %d nodes detected."), *Check.Description, NodeCount),
			FString::Printf(TEXT("%d nodes -- consider refactoring to functions or C++"), NodeCount),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckEmptyGraph(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	int32 NodeCount = CountTotalNodes(BP);
	if (NodeCount < 3)
	{
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s Only %d node(s) found."), *Check.Description, NodeCount),
			TEXT("Blueprint appears to contain no meaningful logic"),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckTickHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	if (HasEventTick(BP))
	{
		int32 NodeCount = CountTotalNodes(BP);
		if (NodeCount > 30)
		{
			Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
				FString::Printf(TEXT("%s Tick enabled with %d nodes."), *Check.Description, NodeCount),
				FString::Printf(TEXT("EventTick + %d nodes -- consider timers or C++ Tick"), NodeCount),
				EBPDoctorAssetType::Blueprint));
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckSelfCast(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	const auto& CastNodes = GetDynamicCastNodes(BP);
	UClass* BPClass = BP->GeneratedClass;
	if (!BPClass) return Results;

	for (UK2Node_DynamicCast* CastNode : CastNodes)
	{
		if (CastNode->TargetType == BPClass)
		{
			Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
				Check.Description,
				FString::Printf(TEXT("Blueprint casts to its own type '%s' -- use Self instead"),
					*BPClass->GetName()),
				EBPDoctorAssetType::Blueprint));
			break; // One report is enough
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckDeprecatedFunc(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	const auto& CallNodes = GetCallFunctionNodes(BP);
	TArray<FString> DeprecatedFuncs;

	for (UK2Node_CallFunction* Call : CallNodes)
	{
		UFunction* Func = Call->GetTargetFunction();
		if (Func && Func->HasMetaData(TEXT("DeprecatedFunction")))
		{
			DeprecatedFuncs.AddUnique(Func->GetName());
		}
	}

	if (DeprecatedFuncs.Num() > 0)
	{
		FString FuncList = FString::Join(DeprecatedFuncs, TEXT(", "));
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s Found: %s"), *Check.Description, *FuncList),
			FString::Printf(TEXT("Deprecated functions: %s"), *FuncList),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckCircularDep(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Get all hard-referenced Blueprint classes
	TSet<FString> ReferencedBPs;
	const auto& CastNodes = GetDynamicCastNodes(BP);
	for (UK2Node_DynamicCast* CastNode : CastNodes)
	{
		if (CastNode->TargetType && CastNode->TargetType->ClassGeneratedBy)
		{
			ReferencedBPs.Add(CastNode->TargetType->GetPathName());
		}
	}

	// For each referenced BP, check if IT references US back
	FString OurPath = BP->GeneratedClass ? BP->GeneratedClass->GetPathName() : BP->GetPathName();
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

	for (const FString& RefPath : ReferencedBPs)
	{
		TArray<FName> Referencers;
		AssetRegistry.GetReferencers(FName(*RefPath), Referencers);
		FName OurPackageName(*BP->GetOutermost()->GetName());
		for (const FName& Ref : Referencers)
		{
			if (Ref == OurPackageName)
			{
				Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
					FString::Printf(TEXT("%s Circular: %s <-> %s"),
						*Check.Description, *BP->GetName(),
						*FPaths::GetBaseFilename(RefPath)),
					FString::Printf(TEXT("Circular dependency with %s"),
						*FPaths::GetBaseFilename(RefPath)),
					EBPDoctorAssetType::Blueprint));
				break;
			}
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckMassiveAsset(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Get file size from the package
	FString PackagePath = BP->GetOutermost()->GetName();
	FString FilePath;
	if (FPackageName::DoesPackageExist(PackagePath, &FilePath))
	{
		int64 FileSize = IFileManager::Get().FileSize(*FilePath);
		if (FileSize > 5 * 1024 * 1024)
		{
			float SizeMB = FileSize / (1024.0f * 1024.0f);
			Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
				FString::Printf(TEXT("%s File is %.1fMB."), *Check.Description, SizeMB),
				FString::Printf(TEXT("%.1fMB -- check for embedded data or excessive nodes"), SizeMB),
				EBPDoctorAssetType::Blueprint));
		}
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckHardRef(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	const auto& CastNodes = GetDynamicCastNodes(BP);
	TSet<FString> HardRefs;

	for (UK2Node_DynamicCast* CastNode : CastNodes)
	{
		if (CastNode->TargetType && CastNode->TargetType->ClassGeneratedBy)
		{
			HardRefs.Add(CastNode->TargetType->GetName());
		}
	}

	if (HardRefs.Num() >= 5)
	{
		TArray<FString> RefList = HardRefs.Array();
		FString DisplayList = FString::Join(
			TArrayView<FString>(RefList.GetData(), FMath::Min(3, RefList.Num())),
			TEXT(", "));
		if (RefList.Num() > 3) DisplayList += TEXT("...");

		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s %d hard BP references."), *Check.Description, HardRefs.Num()),
			FString::Printf(TEXT("Hard refs: %s"), *DisplayList),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckExpensiveTick(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	if (!HasEventTick(BP)) return Results;

	static const TArray<FName> ExpensiveOps = {
		FName("GetAllActorsOfClass"), FName("GetAllActorsWithTag"),
		FName("GetAllActorsWithInterface"),
		FName("LineTraceByChannel"), FName("LineTraceForObjects"),
		FName("SweepSingleByChannel"), FName("SweepMultiByChannel"),
		FName("GetComponentsByClass"), FName("GetComponentsByTag"),
		FName("GetOverlappingActors"), FName("GetOverlappingComponents"),
	};

	TArray<FString> FoundOps;
	const auto& CallNodes = GetCallFunctionNodes(BP);
	for (UK2Node_CallFunction* Call : CallNodes)
	{
		FName FuncName = Call->FunctionReference.GetMemberName();
		if (ExpensiveOps.Contains(FuncName))
		{
			FoundOps.AddUnique(FuncName.ToString());
		}
	}

	if (FoundOps.Num() > 0)
	{
		FString OpList = FString::Join(
			TArrayView<FString>(FoundOps.GetData(), FMath::Min(3, FoundOps.Num())),
			TEXT(", "));
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s Found: %s"), *Check.Description, *OpList),
			FString::Printf(TEXT("Tick + %s -- move to timer or C++"), *OpList),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckDebugNodes(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	static const TArray<FName> DebugFunctions = {
		FName("PrintString"), FName("PrintText"), FName("PrintWarning"),
		FName("DrawDebugLine"), FName("DrawDebugBox"), FName("DrawDebugSphere"),
		FName("DrawDebugPoint"), FName("DrawDebugArrow"), FName("DrawDebugString"),
		FName("DrawDebugCapsule"), FName("DrawDebugCylinder"),
	};

	TArray<FString> Found;
	const auto& CallNodes = GetCallFunctionNodes(BP);
	for (UK2Node_CallFunction* Call : CallNodes)
	{
		FName FuncName = Call->FunctionReference.GetMemberName();
		if (DebugFunctions.Contains(FuncName))
		{
			Found.AddUnique(FuncName.ToString());
		}
	}

	if (Found.Num() > 0)
	{
		FString FoundList = FString::Join(
			TArrayView<FString>(Found.GetData(), FMath::Min(3, Found.Num())),
			TEXT(", "));
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s Found: %s"), *Check.Description, *FoundList),
			FString::Printf(TEXT("Debug nodes: %s -- remove before shipping"), *FoundList),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckConstructHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Find the Construction Script graph
	UEdGraph* ConstructGraph = nullptr;
	for (UEdGraph* Graph : BP->FunctionGraphs)
	{
		if (Graph->GetName() == TEXT("UserConstructionScript"))
		{
			ConstructGraph = Graph;
			break;
		}
	}

	if (!ConstructGraph) return Results;

	static const TArray<FName> HeavyOps = {
		FName("SpawnActorFromClass"), FName("SpawnActor"),
		FName("GetAllActorsOfClass"), FName("GetAllActorsWithTag"),
		FName("DestroyActor"), FName("DestroyComponent"),
		FName("AddComponentByClass"),
	};

	TArray<FString> Found;
	for (UEdGraphNode* Node : ConstructGraph->Nodes)
	{
		if (UK2Node_CallFunction* Call = Cast<UK2Node_CallFunction>(Node))
		{
			FName FuncName = Call->FunctionReference.GetMemberName();
			if (HeavyOps.Contains(FuncName))
			{
				Found.AddUnique(FuncName.ToString());
			}
		}
	}

	if (Found.Num() > 0)
	{
		FString FoundList = FString::Join(Found, TEXT(", "));
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s Found: %s"), *Check.Description, *FoundList),
			FString::Printf(TEXT("Construction Script + %s -- causes editor freezes"), *Found[0]),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckForEachPerf(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	// Find ForEachLoop macro instances
	auto MacroNodes = CollectNodesOfType<UK2Node_MacroInstance>(BP);
	bool bHasForEach = false;
	for (UK2Node_MacroInstance* Macro : MacroNodes)
	{
		FString MacroName = Macro->GetMacroGraph() ? Macro->GetMacroGraph()->GetName() : TEXT("");
		if (MacroName.Contains(TEXT("ForEachLoop")))
		{
			bHasForEach = true;
			break;
		}
	}

	if (!bHasForEach) return Results;

	static const TArray<FName> PureQueries = {
		FName("GetComponentsByClass"), FName("GetAllActorsOfClass"),
		FName("GetComponentsByTag"), FName("GetAllActorsWithTag"),
	};

	TArray<FString> Found;
	const auto& CallNodes = GetCallFunctionNodes(BP);
	for (UK2Node_CallFunction* Call : CallNodes)
	{
		FName FuncName = Call->FunctionReference.GetMemberName();
		if (PureQueries.Contains(FuncName))
		{
			Found.AddUnique(FuncName.ToString());
		}
	}

	if (Found.Num() > 0)
	{
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s ForEach + %s"), *Check.Description, *FString::Join(Found, TEXT(", "))),
			FString::Printf(TEXT("ForEachLoop re-evaluates %s every iteration -- cache the array"), *Found[0]),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}

TArray<FBPDoctorResult> FBPDoctorChecks::CheckTimelineHeavy(const FBPDoctorCheckDef& Check, UBlueprint* BP)
{
	using namespace BPDoctorUtil;
	TArray<FBPDoctorResult> Results;

	int32 TimelineCount = CountNodesOfType<UK2Node_Timeline>(BP);
	if (TimelineCount >= 3)
	{
		Results.Add(MakeResult(Check, BP->GetName(), BP->GetPathName(),
			FString::Printf(TEXT("%s %d Timeline components."), *Check.Description, TimelineCount),
			FString::Printf(TEXT("%d hidden tick registrations -- consider merging"), TimelineCount),
			EBPDoctorAssetType::Blueprint));
	}

	return Results;
}
