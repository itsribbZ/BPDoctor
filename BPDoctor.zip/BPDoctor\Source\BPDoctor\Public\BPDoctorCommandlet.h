// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#pragma once

#include "Commandlets/Commandlet.h"
#include "BPDoctorCommandlet.generated.h"

/**
 * BP Doctor Commandlet — headless Blueprint scanning for CI/CD pipelines.
 *
 * Usage:
 *   UnrealEditor-Cmd.exe Project.uproject -run=BPDoctor [options]
 *
 * Options:
 *   -output=<path>       Output file path (default: stdout)
 *   -format=json|text    Output format (default: text)
 *   -severity=error|warning|info  Minimum severity to include (default: info)
 *   -fail-on=error|warning|info   Severity that causes exit code 1 (default: error)
 *
 * Exit codes:
 *   0 = No issues at fail-on severity
 *   1 = Issues found at fail-on severity or above
 *
 * Examples:
 *   # Fail CI if any errors found, output JSON report
 *   UnrealEditor-Cmd.exe MyProject.uproject -run=BPDoctor -output=report.json -format=json -fail-on=error
 *
 *   # Strict mode: fail on any warning or error
 *   UnrealEditor-Cmd.exe MyProject.uproject -run=BPDoctor -fail-on=warning
 *
 *   # Full report to file
 *   UnrealEditor-Cmd.exe MyProject.uproject -run=BPDoctor -output=bp_report.txt -format=text -severity=info
 */
UCLASS()
class UBPDoctorCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UBPDoctorCommandlet();
	virtual int32 Main(const FString& Params) override;

private:
	FString GenerateTextReport(const TArray<struct FBPDoctorResult>& Results, int32 TotalScanned) const;
	FString GenerateJSONReport(const TArray<struct FBPDoctorResult>& Results, int32 TotalScanned) const;
};
