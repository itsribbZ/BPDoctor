// Copyright (c) 2025-2026 BP Doctor. All rights reserved.

#include "BPDoctorFixes.h"

#include "Animation/AnimBlueprint.h"
#include "AnimGraphNode_LayeredBoneBlend.h"
#include "AnimGraphNode_Slot.h"
#include "AnimGraphNode_Base.h"

#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphPin.h"
#include "K2Node_CallFunction.h"
#include "K2Node_DynamicCast.h"
#include "EdGraphSchema_K2.h"

#include "Kismet2/BlueprintEditorUtils.h"

// ─────────────────────────────────────────────────────────────────
//  PREVIEW
// ─────────────────────────────────────────────────────────────────

FBPDoctorFixAction FBPDoctorFixes::PreviewFix(const FBPDoctorResult& Issue, UBlueprint* Blueprint)
{
	FBPDoctorFixAction Action;
	Action.CheckCode = Issue.CheckCode;
	Action.AssetName = Issue.AssetName;
	Action.AssetPath = Issue.AssetPath;

	if (Issue.CheckCode == TEXT("BROKEN_BLEND_WT"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Clamp all blend weight default values to the [0.0, 1.0] range.");
		Action.Preview = TEXT("BlendWeight pins with out-of-range defaults will be clamped.");
	}
	else if (Issue.CheckCode == TEXT("MISSING_SLOT"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Add a DefaultSlot node to the AnimGraph.");
		Action.Preview = TEXT("A new AnimGraphNode_Slot with SlotName='DefaultSlot' will be created. Wire it into your pose chain after fixing.");
	}
	else if (Issue.CheckCode == TEXT("TPOSE_FALLBACK"))
	{
		Action.FixType = EBPDoctorFixType::Manual;
		Action.Description = TEXT("Connect disconnected BasePose pins on LayeredBoneBlend nodes.");
		Action.Preview = TEXT("Open the AnimBP and connect the BasePose input pin to your main pose chain.");
	}
	else if (Issue.CheckCode == TEXT("DUP_SLOT"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Rename duplicate slot names to be unique (append _2, _3, etc.).");
		Action.Preview = TEXT("Duplicate SlotNames will get numeric suffixes.");
	}
	else if (Issue.CheckCode == TEXT("BP_SELF_CAST"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Remove self-cast nodes and reroute connections through Self reference.");
		Action.Preview = TEXT("Cast-to-Self nodes will be deleted; output pins rerouted to Self.");
	}
	else if (Issue.CheckCode == TEXT("BP_DEBUG_NODES"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Delete all PrintString and DrawDebug nodes.");
		Action.Preview = TEXT("Debug function call nodes will be removed from all graphs.");
	}
	else if (Issue.CheckCode == TEXT("BP_CONSTRUCT_HEAVY"))
	{
		Action.FixType = EBPDoctorFixType::Manual;
		Action.Description = TEXT("Move heavy operations from Construction Script to BeginPlay.");
		Action.Preview = TEXT("SpawnActor and query nodes should be moved manually to BeginPlay.");
	}
	else if (Issue.CheckCode == TEXT("ORPHANED_NODE"))
	{
		Action.FixType = EBPDoctorFixType::Programmatic;
		Action.Description = TEXT("Delete all AnimGraph nodes not reachable from the Output Pose root.");
		Action.Preview = TEXT("Orphaned nodes in the top-level AnimGraph will be removed. State machine contents are preserved.");
	}
	else
	{
		Action.FixType = EBPDoctorFixType::Manual;
		Action.Description = TEXT("This issue requires manual intervention in the Blueprint editor.");
		Action.Preview = Issue.NodeHint;
	}

	return Action;
}

// ─────────────────────────────────────────────────────────────────
//  APPLY
// ─────────────────────────────────────────────────────────────────

bool FBPDoctorFixes::ApplyFix(const FBPDoctorResult& Issue, UBlueprint* Blueprint, const FString& CustomValue)
{
	if (!Issue.bAutoFixable) return false;

	bool bSuccess = false;

	if (Issue.CheckCode == TEXT("BROKEN_BLEND_WT"))   bSuccess = FixBrokenBlendWeight(Blueprint, CustomValue);
	else if (Issue.CheckCode == TEXT("MISSING_SLOT")) bSuccess = FixMissingSlot(Blueprint);
	else if (Issue.CheckCode == TEXT("TPOSE_FALLBACK")) bSuccess = FixTPoseFallback(Blueprint);
	else if (Issue.CheckCode == TEXT("DUP_SLOT"))      bSuccess = FixDuplicateSlot(Blueprint, CustomValue);
	else if (Issue.CheckCode == TEXT("BP_SELF_CAST"))   bSuccess = FixSelfCast(Blueprint);
	else if (Issue.CheckCode == TEXT("BP_DEBUG_NODES")) bSuccess = FixDebugNodes(Blueprint);
	else if (Issue.CheckCode == TEXT("ORPHANED_NODE")) bSuccess = FixOrphanedNode(Blueprint);
	else if (Issue.CheckCode == TEXT("BP_CONSTRUCT_HEAVY")) bSuccess = FixConstructHeavy(Blueprint);

	if (bSuccess)
	{
		FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);
		Blueprint->MarkPackageDirty();
		// NOTE: Do NOT call PostEditChange here — it triggers a full recompile
		// per-Blueprint inside the transaction, which is both slow and can corrupt undo state.
	}

	return bSuccess;
}

int32 FBPDoctorFixes::ApplyAllFixes(const TArray<FBPDoctorResult>& Issues, UBlueprint* Blueprint)
{
	int32 Count = 0;
	for (const FBPDoctorResult& Issue : Issues)
	{
		if (Issue.bAutoFixable && ApplyFix(Issue, Blueprint))
		{
			Count++;
		}
	}
	return Count;
}

// ─────────────────────────────────────────────────────────────────
//  FIX IMPLEMENTATIONS
// ─────────────────────────────────────────────────────────────────

bool FBPDoctorFixes::FixBrokenBlendWeight(UBlueprint* BP, const FString& CustomValue)
{
	bool bFixed = false;
	// If user provided a custom value, use it; otherwise clamp to [0,1]
	bool bUseCustom = !CustomValue.IsEmpty();
	float CustomFloat = bUseCustom ? FMath::Clamp(FCString::Atof(*CustomValue), 0.0f, 1.0f) : 0.f;

	TArray<UEdGraph*> AllGraphs;
	AllGraphs.Append(BP->UbergraphPages);
	AllGraphs.Append(BP->FunctionGraphs);
	AllGraphs.Append(BP->MacroGraphs);
	for (UEdGraph* Graph : AllGraphs)
	{
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (UAnimGraphNode_LayeredBoneBlend* LBB = Cast<UAnimGraphNode_LayeredBoneBlend>(Node))
			{
				for (UEdGraphPin* Pin : LBB->Pins)
				{
					if (Pin->PinName.ToString().Contains(TEXT("BlendWeight")) && !Pin->LinkedTo.Num())
					{
						FString DefaultVal = Pin->GetDefaultAsString();
						if (!DefaultVal.IsEmpty())
						{
							float Val = FCString::Atof(*DefaultVal);
							if (Val < 0.0f || Val > 1.0f)
							{
								LBB->Modify();
								float NewVal = bUseCustom ? CustomFloat : FMath::Clamp(Val, 0.0f, 1.0f);
								Pin->DefaultValue = FString::Printf(TEXT("%.6f"), NewVal);
								bFixed = true;
							}
						}
					}
				}
			}
		}
	}
	return bFixed;
}

bool FBPDoctorFixes::FixMissingSlot(UBlueprint* BP)
{
	UAnimBlueprint* AnimBP = Cast<UAnimBlueprint>(BP);
	if (!AnimBP) return false;

	// Find the AnimGraph (the graph containing the Root output pose node)
	UEdGraph* AnimGraph = nullptr;
	for (UEdGraph* Graph : AnimBP->FunctionGraphs)
	{
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (Node->GetClass()->GetName().Contains(TEXT("Root")))
			{
				AnimGraph = Graph;
				break;
			}
		}
		if (AnimGraph) break;
	}
	if (!AnimGraph) return false;

	// Verify no Slot node already exists in this graph
	for (UEdGraphNode* Node : AnimGraph->Nodes)
	{
		if (Cast<UAnimGraphNode_Slot>(Node))
		{
			return false;
		}
	}

	// Create a new DefaultSlot node
	AnimGraph->Modify();
	UAnimGraphNode_Slot* NewSlot = NewObject<UAnimGraphNode_Slot>(AnimGraph);
	NewSlot->Node.SlotName = FName("DefaultSlot");
	NewSlot->CreateNewGuid();
	NewSlot->PostPlacedNewNode();
	NewSlot->AllocateDefaultPins();

	// Position offset from origin so it's visible when the graph opens
	NewSlot->NodePosX = -200;
	NewSlot->NodePosY = 0;

	AnimGraph->AddNode(NewSlot, /*bFromUI=*/false, /*bSelectNewNode=*/false);

	return true;
}

bool FBPDoctorFixes::FixTPoseFallback(UBlueprint* BP)
{
	// Cannot auto-connect BasePose without knowing what to connect to.
	// Flag for manual fix in editor.
	return false;
}

bool FBPDoctorFixes::FixDuplicateSlot(UBlueprint* BP, const FString& CustomValue)
{
	bool bFixed = false;
	TMap<FName, int32> SlotNameCounts;

	TArray<UEdGraph*> AllSlotGraphs;
	AllSlotGraphs.Append(BP->UbergraphPages);
	AllSlotGraphs.Append(BP->FunctionGraphs);
	AllSlotGraphs.Append(BP->MacroGraphs);
	for (UEdGraph* Graph : AllSlotGraphs)
	{
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (UAnimGraphNode_Slot* Slot = Cast<UAnimGraphNode_Slot>(Node))
			{
				FName SlotName = Slot->Node.SlotName;
				int32& Count = SlotNameCounts.FindOrAdd(SlotName);
				Count++;

				if (Count > 1)
				{
					Slot->Modify();
					// Use custom name if provided, otherwise auto-suffix
					FString NewName = !CustomValue.IsEmpty()
						? FString::Printf(TEXT("%s_%d"), *CustomValue, Count)
						: FString::Printf(TEXT("%s_%d"), *SlotName.ToString(), Count);
					Slot->Node.SlotName = FName(*NewName);
					bFixed = true;
				}
			}
		}
	}
	return bFixed;
}

bool FBPDoctorFixes::FixSelfCast(UBlueprint* BP)
{
	bool bFixed = false;
	UClass* BPClass = BP->GeneratedClass;
	if (!BPClass) return false;

	TArray<UEdGraph*> AllGraphs;
	AllGraphs.Append(BP->UbergraphPages);
	AllGraphs.Append(BP->FunctionGraphs);
	AllGraphs.Append(BP->MacroGraphs);

	for (UEdGraph* Graph : AllGraphs)
	{
		TArray<UK2Node_DynamicCast*> CastsToRemove;
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (UK2Node_DynamicCast* CastNode = Cast<UK2Node_DynamicCast>(Node))
			{
				if (CastNode->TargetType == BPClass)
				{
					CastsToRemove.Add(CastNode);
				}
			}
		}

		if (CastsToRemove.Num() > 0)
		{
			Graph->Modify();
		}
		for (UK2Node_DynamicCast* CastNode : CastsToRemove)
		{
			CastNode->Modify();

			// Reroute: connect input object source to all output "As X" targets
			UEdGraphPin* SourcePin = CastNode->GetCastSourcePin();
			UEdGraphPin* ResultPin = CastNode->GetCastResultPin();
			if (SourcePin && ResultPin)
			{
				TArray<UEdGraphPin*> SourceLinks = SourcePin->LinkedTo;
				TArray<UEdGraphPin*> ResultLinks = ResultPin->LinkedTo;
				for (UEdGraphPin* Origin : SourceLinks)
				{
					for (UEdGraphPin* Target : ResultLinks)
					{
						Origin->MakeLinkTo(Target);
					}
				}
			}

			// Reroute exec pins (copy arrays first to avoid iterator invalidation)
			UEdGraphPin* ExecIn = CastNode->FindPin(UEdGraphSchema_K2::PN_Execute);
			UEdGraphPin* ExecOut = CastNode->FindPin(UEdGraphSchema_K2::PN_Then);
			if (ExecIn && ExecOut)
			{
				TArray<UEdGraphPin*> InLinks = ExecIn->LinkedTo;
				TArray<UEdGraphPin*> OutLinks = ExecOut->LinkedTo;
				for (UEdGraphPin* In : InLinks)
				{
					for (UEdGraphPin* Out : OutLinks)
					{
						In->MakeLinkTo(Out);
					}
				}
			}

			CastNode->BreakAllNodeLinks();
			Graph->RemoveNode(CastNode);
			bFixed = true;
		}
	}
	return bFixed;
}

bool FBPDoctorFixes::FixDebugNodes(UBlueprint* BP)
{
	bool bFixed = false;

	static const TArray<FName> DebugFunctions = {
		FName("PrintString"), FName("PrintText"), FName("PrintWarning"),
		FName("DrawDebugLine"), FName("DrawDebugBox"), FName("DrawDebugSphere"),
		FName("DrawDebugPoint"), FName("DrawDebugArrow"), FName("DrawDebugString"),
		FName("DrawDebugCapsule"), FName("DrawDebugCylinder"),
	};

	TArray<UEdGraph*> AllGraphs;
	AllGraphs.Append(BP->UbergraphPages);
	AllGraphs.Append(BP->FunctionGraphs);
	AllGraphs.Append(BP->MacroGraphs);

	for (UEdGraph* Graph : AllGraphs)
	{
		TArray<UEdGraphNode*> NodesToRemove;
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (UK2Node_CallFunction* Call = Cast<UK2Node_CallFunction>(Node))
			{
				FName FuncName = Call->FunctionReference.GetMemberName();
				if (DebugFunctions.Contains(FuncName))
				{
					NodesToRemove.Add(Node);
				}
			}
		}

		if (NodesToRemove.Num() > 0)
		{
			Graph->Modify();
		}
		for (UEdGraphNode* Node : NodesToRemove)
		{
			Node->Modify();
			UEdGraphPin* ExecIn = Node->FindPin(UEdGraphSchema_K2::PN_Execute);
			UEdGraphPin* ExecOut = Node->FindPin(UEdGraphSchema_K2::PN_Then);
			if (ExecIn && ExecOut)
			{
				// Copy arrays before iterating — MakeLinkTo modifies LinkedTo
				TArray<UEdGraphPin*> InLinks = ExecIn->LinkedTo;
				TArray<UEdGraphPin*> OutLinks = ExecOut->LinkedTo;
				for (UEdGraphPin* InLink : InLinks)
				{
					for (UEdGraphPin* OutLink : OutLinks)
					{
						InLink->MakeLinkTo(OutLink);
					}
				}
			}

			Node->BreakAllNodeLinks();
			Graph->RemoveNode(Node);
			bFixed = true;
		}
	}
	return bFixed;
}

bool FBPDoctorFixes::FixConstructHeavy(UBlueprint* BP)
{
	// Moving nodes between graphs requires careful pin reconnection.
	// This is better done manually in the editor.
	return false;
}

bool FBPDoctorFixes::FixOrphanedNode(UBlueprint* BP)
{
	UAnimBlueprint* AnimBP = Cast<UAnimBlueprint>(BP);
	if (!AnimBP) return false;

	bool bFixed = false;

	// Check all graphs that may contain AnimGraph nodes
	TArray<UEdGraph*> GraphsToCheck;
	GraphsToCheck.Append(AnimBP->FunctionGraphs);
	GraphsToCheck.Append(AnimBP->UbergraphPages);

	for (UEdGraph* Graph : GraphsToCheck)
	{
		if (!Graph) continue;

		// Collect AnimGraphNode_Base nodes in THIS graph only (no subgraph recursion —
		// state machine contents are intentionally preserved)
		TArray<UAnimGraphNode_Base*> AnimNodes;
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (UAnimGraphNode_Base* AnimNode = Cast<UAnimGraphNode_Base>(Node))
			{
				AnimNodes.Add(AnimNode);
			}
		}

		if (AnimNodes.Num() <= 3) continue;

		// BFS from Root node through input pins to find all reachable nodes
		TSet<UEdGraphNode*> Reachable;
		TArray<UEdGraphNode*> WorkQueue;

		for (UAnimGraphNode_Base* Node : AnimNodes)
		{
			if (Node->GetClass()->GetName().Contains(TEXT("Root")))
			{
				WorkQueue.Add(Node);
				Reachable.Add(Node);
			}
		}

		if (WorkQueue.Num() == 0) continue;

		while (WorkQueue.Num() > 0)
		{
			UEdGraphNode* Current = WorkQueue.Pop();
			for (UEdGraphPin* Pin : Current->Pins)
			{
				if (Pin->Direction == EGPD_Input)
				{
					for (UEdGraphPin* LinkedPin : Pin->LinkedTo)
					{
						UEdGraphNode* LinkedNode = LinkedPin->GetOwningNode();
						if (!Reachable.Contains(LinkedNode))
						{
							Reachable.Add(LinkedNode);
							WorkQueue.Add(LinkedNode);
						}
					}
				}
			}
		}

		// Delete unreachable AnimGraph nodes
		TArray<UAnimGraphNode_Base*> NodesToDelete;
		for (UAnimGraphNode_Base* Node : AnimNodes)
		{
			if (!Reachable.Contains(Node))
			{
				NodesToDelete.Add(Node);
			}
		}

		if (NodesToDelete.Num() > 0)
		{
			Graph->Modify();
			for (UAnimGraphNode_Base* Node : NodesToDelete)
			{
				Node->Modify();
				Node->BreakAllNodeLinks();
				Graph->RemoveNode(Node);
			}
			bFixed = true;
		}
	}

	return bFixed;
}
